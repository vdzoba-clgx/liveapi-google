#!/usr/bin/env pwsh

# Check if ngrok is running, start if not
if (-not (Get-Process -Name "ngrok" -ErrorAction SilentlyContinue)) {
    if (Test-Path ".\ngrok.exe") {
        Start-Process -FilePath ".\ngrok.exe" -ArgumentList "start", "--config", ".\ngrok.yml", "twiml-app" -WindowStyle Hidden
        Start-Sleep -Seconds 3
    } else {
        Write-Host "ngrok.exe not found. Please download from https://ngrok.com/download" -ForegroundColor Red
        exit 1
    }
}

# Build the application
mvn clean package -DskipTests
if ($LASTEXITCODE -ne 0) {
    Write-Host "Build failed!" -ForegroundColor Red
    exit 1
}

# Set the GOOGLE_API_KEY environment variable
$env:GOOGLE_API_KEY = "AIzaSyDtqELtZjI53o3K9tuyQBGnJ7xHlH0QZq8"

# Start the application
try {
    java "-Dlogging.level.com.cotality.ivra.bots_service=INFO" -jar target\ivra-bots-service-1.0-SNAPSHOT.jar
} catch {
    Write-Host "Error starting application: $_" -ForegroundColor Red
}
