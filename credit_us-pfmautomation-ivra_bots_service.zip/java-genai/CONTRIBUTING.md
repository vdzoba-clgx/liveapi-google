# Contributing

The Google Gen AI SDK will accept contributions in the future.