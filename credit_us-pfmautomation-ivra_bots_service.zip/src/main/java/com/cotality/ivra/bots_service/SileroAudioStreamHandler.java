package com.cotality.ivra.bots_service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;

/**
 * Audio Stream Handler with Silero VAD Integration
 * 
 * This handler integrates with the Silero VAD Python service for accurate
 * voice activity detection and speech boundary detection.
 * 
 * Flow:
 * 1. Receive audio chunks from Twilio
 * 2. Send audio to Silero VAD service for speech detection
 * 3. Buffer audio until speech boundary detected
 * 4. Send complete phrases to STT service
 * 5. Process transcripts and send to AI decision logic
 * 6. Handle AI responses (wait/action/collect.data)
 */
@Component
public class SileroAudioStreamHandler implements WebSocketHandler {

    private static final Logger logger = LoggerFactory.getLogger(SileroAudioStreamHandler.class);
    private final Gson gson = new Gson();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    // Configuration
    private static final int MAX_WAIT_CYCLES = 5;
    private static final long DATA_COLLECTION_TIMEOUT_MS = 45000;
    private static final int MAX_BUFFER_SIZE = 64000;
    private static final int CHUNK_SIZE_16KHZ = 512; // 32ms at 16kHz for Silero VAD
    private static final int SILENCE_CHUNKS_FOR_BOUNDARY = 10; // Increased to ~330ms to reduce frequent triggers
    private static final long MIN_TRANSCRIPT_INTERVAL_MS = 3000; // Minimum 3 seconds between AI calls
    private static final long ACTION_COOLDOWN_MS = 8000; // 8 second cooldown between actions

    // Service endpoints
    private static final String TRANSCRIPTION_URL = "http://127.0.0.1:5000/transcribe";
    private static final String CONTROLLER_ENDPOINT = "http://localhost:8080/outbound/stream-transcription";
    private static final String SILERO_VAD_URL = "http://localhost:8765";

    // Stream states
    enum StreamState {
        STREAMING,       // Actively processing audio
        PAUSED,          // Waiting for Twilio action to complete
        COLLECTING_DATA, // Special 45s data collection mode
        ERROR            // Recovery mode
    }

    // Per-stream data structures
    private final Map<String, StreamState> streamStates = new ConcurrentHashMap<>();
    private final Map<String, StringBuilder> accumulatedTranscripts = new ConcurrentHashMap<>();
    private final Map<String, Integer> waitCycles = new ConcurrentHashMap<>();
    private final Map<String, String> streamInfo = new ConcurrentHashMap<>();
    
    // Audio buffering for VAD processing
    private final Map<String, byte[]> audioBuffers = new ConcurrentHashMap<>();
    private final Map<String, Integer> bufferSizes = new ConcurrentHashMap<>();
    private final Map<String, Integer> chunkCounters = new ConcurrentHashMap<>();
    
    // Silero VAD state tracking
    private final Map<String, Integer> consecutiveSilenceChunks = new ConcurrentHashMap<>();
    private final Map<String, Boolean> hasSpeechInBuffer = new ConcurrentHashMap<>();
    private final Map<String, byte[]> vadChunkBuffer = new ConcurrentHashMap<>();
    private final Map<String, Integer> vadChunkBufferSize = new ConcurrentHashMap<>();
    
    // Data collection timing
    private final Map<String, Long> dataCollectionStartTime = new ConcurrentHashMap<>();
    
    // Action deduplication and timing
    private final Map<String, Long> lastTranscriptTime = new ConcurrentHashMap<>();
    private final Map<String, Long> lastActionTime = new ConcurrentHashMap<>();
    private final Map<String, String> lastActionTaken = new ConcurrentHashMap<>();

    @Override
    public void afterConnectionEstablished(@NonNull WebSocketSession session) throws Exception {
        logger.info("WebSocket connection established: {}", session.getId());
        
        // Extract callSid from URL if available
        if (session.getUri() != null) {
            String query = session.getUri().getQuery();
            if (query != null && !query.isEmpty()) {
                String callSid = extractCallSidFromQuery(query);
                if (callSid != null) {
                    streamInfo.put("session_" + session.getId() + "_callsid", callSid);
                    logger.info("Extracted callSid from URL: {}", callSid);
                }
            }
        }
    }

    @Override
    public void handleMessage(@NonNull WebSocketSession session, @NonNull WebSocketMessage<?> message) throws Exception {
        if (message instanceof TextMessage) {
            String payload = ((TextMessage) message).getPayload();
            JsonObject json = gson.fromJson(payload, JsonObject.class);
            String event = json.get("event").getAsString();

            switch (event) {
                case "connected":
                    handleConnected(json);
                    break;
                case "start":
                    handleStart(session, json);
                    break;
                case "media":
                    handleMedia(json);
                    break;
                case "stop":
                    handleStop(json);
                    break;
                default:
                    logger.debug("Unknown event: {}", event);
            }
        }
    }

    private void handleConnected(JsonObject json) {
        logger.debug("Stream connected");
    }

    private void handleStart(WebSocketSession session, JsonObject json) {
        try {
            if (!json.has("streamSid") || json.get("streamSid").isJsonNull()) {
                logger.error("Missing streamSid in start event");
                return;
            }

            String streamSid = json.get("streamSid").getAsString();
            logger.info("Starting stream with Silero VAD: {}", streamSid);

            // Initialize stream state
            streamStates.put(streamSid, StreamState.STREAMING);
            accumulatedTranscripts.put(streamSid, new StringBuilder());
            waitCycles.put(streamSid, 0);

            // Initialize audio buffering
            audioBuffers.put(streamSid, new byte[MAX_BUFFER_SIZE]);
            bufferSizes.put(streamSid, 0);
            chunkCounters.put(streamSid, 0);
            
            // Initialize Silero VAD state
            consecutiveSilenceChunks.put(streamSid, 0);
            hasSpeechInBuffer.put(streamSid, false);
            vadChunkBuffer.put(streamSid, new byte[CHUNK_SIZE_16KHZ * 2]); // 16-bit PCM
            vadChunkBufferSize.put(streamSid, 0);

            // Store callSid
            String callSid = "unknown";
            if (json.has("callSid") && !json.get("callSid").isJsonNull()) {
                callSid = json.get("callSid").getAsString();
            } else {
                String sessionCallSid = streamInfo.get("session_" + session.getId() + "_callsid");
                if (sessionCallSid != null) {
                    callSid = sessionCallSid;
                    streamInfo.remove("session_" + session.getId() + "_callsid");
                }
            }
            streamInfo.put(streamSid + "_callSid", callSid);

            // Create audio directory
            String dateFolder = java.time.LocalDate.now()
                    .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            java.io.File audioDir = new java.io.File("audio/streams/" + dateFolder);
            if (!audioDir.exists()) {
                audioDir.mkdirs();
            }
            streamInfo.put(streamSid, audioDir.getAbsolutePath());

            // Initialize Silero VAD session
            initializeSileroVADSession(streamSid);

            logger.info("Stream {} initialized with Silero VAD, callSid: {}", streamSid, callSid);

        } catch (Exception e) {
            logger.error("Error starting stream: {}", e.getMessage(), e);
        }
    }

    private void handleMedia(JsonObject json) {
        try {
            if (!json.has("streamSid") || json.get("streamSid").isJsonNull()) {
                return;
            }

            String streamSid = json.get("streamSid").getAsString();
            StreamState state = streamStates.get(streamSid);
            
            // Only process audio in STREAMING and COLLECTING_DATA states
            if (state == null || state == StreamState.PAUSED || state == StreamState.ERROR) {
                return;
            }

            // Check data collection timeout
            if (state == StreamState.COLLECTING_DATA) {
                Long startTime = dataCollectionStartTime.get(streamSid);
                if (startTime != null && (System.currentTimeMillis() - startTime) > DATA_COLLECTION_TIMEOUT_MS) {
                    logger.info("Data collection timeout reached for stream {}, hanging up", streamSid);
                    executeHangup(streamSid);
                    return;
                }
            }

            JsonObject media = json.getAsJsonObject("media");
            if (!media.has("payload") || media.get("payload").isJsonNull()) {
                return;
            }

            String payload = media.get("payload").getAsString();
            byte[] mulawData = Base64.getDecoder().decode(payload);
            byte[] pcmData = convertMulawToPcm(mulawData);

            // Process audio chunk with Silero VAD
            processAudioChunkWithSileroVAD(streamSid, pcmData);

        } catch (Exception e) {
            logger.error("Error processing media: {}", e.getMessage(), e);
        }
    }

    private void handleStop(JsonObject json) {
        try {
            if (!json.has("streamSid") || json.get("streamSid").isJsonNull()) {
                return;
            }

            String streamSid = json.get("streamSid").getAsString();
            logger.info("Stopping stream: {}", streamSid);

            // Cleanup all state for this stream
            streamStates.remove(streamSid);
            accumulatedTranscripts.remove(streamSid);
            waitCycles.remove(streamSid);
            audioBuffers.remove(streamSid);
            bufferSizes.remove(streamSid);
            chunkCounters.remove(streamSid);
            consecutiveSilenceChunks.remove(streamSid);
            hasSpeechInBuffer.remove(streamSid);
            vadChunkBuffer.remove(streamSid);
            vadChunkBufferSize.remove(streamSid);
            dataCollectionStartTime.remove(streamSid);
            streamInfo.remove(streamSid);
            streamInfo.remove(streamSid + "_callSid");

        } catch (Exception e) {
            logger.error("Error stopping stream: {}", e.getMessage(), e);
        }
    }

    /**
     * Initialize Silero VAD session for a stream
     */
    private void initializeSileroVADSession(String streamSid) {
        try {
            JsonObject requestData = new JsonObject();
            requestData.addProperty("session_id", streamSid);
            requestData.addProperty("sample_rate", 16000);
            requestData.addProperty("reset_state", true);

            String requestBody = gson.toJson(requestData);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(SILERO_VAD_URL + "/vad/config"))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .timeout(Duration.ofSeconds(5))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            
            if (response.statusCode() == 200) {
                logger.debug("Silero VAD session initialized for stream: {}", streamSid);
            } else {
                logger.warn("Failed to initialize Silero VAD session for stream {}: {}", streamSid, response.statusCode());
            }

        } catch (Exception e) {
            logger.error("Error initializing Silero VAD session for stream {}: {}", streamSid, e.getMessage(), e);
        }
    }

    /**
     * Process audio chunk using Silero VAD service
     */
    private void processAudioChunkWithSileroVAD(String streamSid, byte[] pcmData) {
        try {
            // Add to VAD chunk buffer
            byte[] vadBuffer = vadChunkBuffer.get(streamSid);
            Integer vadBufferSize = vadChunkBufferSize.get(streamSid);
            
            if (vadBuffer == null || vadBufferSize == null) {
                return;
            }

            // Add incoming PCM data to VAD buffer
            int remainingSpace = vadBuffer.length - vadBufferSize;
            int bytesToCopy = Math.min(pcmData.length, remainingSpace);
            
            System.arraycopy(pcmData, 0, vadBuffer, vadBufferSize, bytesToCopy);
            vadBufferSize += bytesToCopy;
            vadChunkBufferSize.put(streamSid, vadBufferSize);

            // Always add to main audio buffer for transcription
            addToAudioBuffer(streamSid, pcmData);

            // Process VAD when we have enough data (512 samples = 1024 bytes for 16-bit)
            if (vadBufferSize >= CHUNK_SIZE_16KHZ * 2) {
                // Create exact-size chunk for VAD
                byte[] vadChunk = new byte[CHUNK_SIZE_16KHZ * 2];
                System.arraycopy(vadBuffer, 0, vadChunk, 0, vadChunk.length);
                
                // Process with Silero VAD
                processSileroVAD(streamSid, vadChunk);
                
                // Shift remaining data in buffer
                int remainingBytes = vadBufferSize - vadChunk.length;
                if (remainingBytes > 0) {
                    System.arraycopy(vadBuffer, vadChunk.length, vadBuffer, 0, remainingBytes);
                }
                vadChunkBufferSize.put(streamSid, remainingBytes);
            }

            // Handle any remaining PCM data that didn't fit in VAD buffer
            if (bytesToCopy < pcmData.length) {
                byte[] remaining = new byte[pcmData.length - bytesToCopy];
                System.arraycopy(pcmData, bytesToCopy, remaining, 0, remaining.length);
                // Recursively process remaining data
                processAudioChunkWithSileroVAD(streamSid, remaining);
            }

        } catch (Exception e) {
            logger.error("Error processing audio chunk with Silero VAD: {}", e.getMessage(), e);
        }
    }

    /**
     * Send audio chunk to Silero VAD service and handle response
     */
    private void processSileroVAD(String streamSid, byte[] vadChunk) {
        try {
            // Convert PCM to base64 for transmission
            String audioB64 = Base64.getEncoder().encodeToString(vadChunk);

            JsonObject requestData = new JsonObject();
            requestData.addProperty("audio_data", audioB64);
            requestData.addProperty("audio_format", "pcm16");
            requestData.addProperty("sample_rate", 16000);
            requestData.addProperty("session_id", streamSid);
            requestData.addProperty("reset_state", false);

            String requestBody = gson.toJson(requestData);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(SILERO_VAD_URL + "/vad/stream"))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .timeout(Duration.ofSeconds(2))
                    .build();

            // Send asynchronously to avoid blocking audio processing
            CompletableFuture<HttpResponse<String>> futureResponse = httpClient.sendAsync(request,
                    HttpResponse.BodyHandlers.ofString());

            futureResponse.thenAccept(response -> {
                handleSileroVADResponse(streamSid, response);
            }).exceptionally(ex -> {
                logger.error("Silero VAD request failed for stream {}: {}", streamSid, ex.getMessage());
                return null;
            });

        } catch (Exception e) {
            logger.error("Error sending to Silero VAD: {}", e.getMessage(), e);
        }
    }

    /**
     * Handle Silero VAD response and determine speech boundaries
     */
    private void handleSileroVADResponse(String streamSid, HttpResponse<String> response) {
        try {
            if (response.statusCode() != 200) {
                logger.warn("Silero VAD response error for stream {}: {}", streamSid, response.statusCode());
                return;
            }

            JsonObject vadResponse = gson.fromJson(response.body(), JsonObject.class);
            JsonObject vadResult = vadResponse.getAsJsonObject("vad_result");
            
            boolean isSpeech = vadResult.get("is_speech").getAsBoolean();
            double confidence = vadResult.get("confidence").getAsDouble();
            boolean speakingState = vadResult.get("is_speaking_state").getAsBoolean();

            logger.debug("Silero VAD[{}]: speech={}, confidence={:.3f}, speaking={}", 
                        streamSid, isSpeech, confidence, speakingState);

            // Track speech in buffer
            if (isSpeech) {
                hasSpeechInBuffer.put(streamSid, true);
                consecutiveSilenceChunks.put(streamSid, 0);
            } else {
                Integer silenceCount = consecutiveSilenceChunks.getOrDefault(streamSid, 0);
                consecutiveSilenceChunks.put(streamSid, silenceCount + 1);
            }

            // Check for speech boundary (silence after speech)
            Boolean hadSpeech = hasSpeechInBuffer.get(streamSid);
            Integer silenceChunks = consecutiveSilenceChunks.get(streamSid);
            
            if (hadSpeech != null && hadSpeech && 
                silenceChunks != null && silenceChunks >= SILENCE_CHUNKS_FOR_BOUNDARY) {
                
                logger.debug("Speech boundary detected for stream {}", streamSid);
                
                // Reset speech tracking
                hasSpeechInBuffer.put(streamSid, false);
                consecutiveSilenceChunks.put(streamSid, 0);
                
                // Transcribe buffered audio
                transcribeBufferedAudio(streamSid);
            }

        } catch (Exception e) {
            logger.error("Error handling Silero VAD response: {}", e.getMessage(), e);
        }
    }

    /**
     * Add PCM data to main audio buffer
     */
    private void addToAudioBuffer(String streamSid, byte[] pcmData) {
        try {
            byte[] buffer = audioBuffers.get(streamSid);
            Integer currentSize = bufferSizes.get(streamSid);
            
            if (buffer != null && currentSize != null) {
                if (currentSize + pcmData.length < buffer.length) {
                    System.arraycopy(pcmData, 0, buffer, currentSize, pcmData.length);
                    bufferSizes.put(streamSid, currentSize + pcmData.length);
                } else {
                    // Buffer full - transcribe immediately
                    logger.warn("Audio buffer full for stream {}, forcing transcription", streamSid);
                    transcribeBufferedAudio(streamSid);
                }
            }
        } catch (Exception e) {
            logger.error("Error adding to audio buffer: {}", e.getMessage(), e);
        }
    }

    /**
     * Transcribe the buffered audio and send to AI
     */
    private void transcribeBufferedAudio(String streamSid) {
        try {
            byte[] buffer = audioBuffers.get(streamSid);
            Integer size = bufferSizes.get(streamSid);
            
            if (buffer == null || size == null || size == 0) {
                return;
            }

            // Save audio chunk
            String audioFile = saveAudioChunk(streamSid, buffer, size);
            if (audioFile == null) {
                return;
            }

            // Reset buffer
            bufferSizes.put(streamSid, 0);

            // Transcribe asynchronously
            CompletableFuture.runAsync(() -> {
                try {
                    String transcript = transcribeAudio(audioFile);
                    if (transcript != null && !transcript.trim().isEmpty()) {
                        processTranscript(streamSid, transcript.trim());
                    }
                } catch (Exception e) {
                    logger.error("Error in async transcription: {}", e.getMessage(), e);
                }
            });

        } catch (Exception e) {
            logger.error("Error transcribing buffered audio: {}", e.getMessage(), e);
        }
    }

    /**
     * Process new transcript - core state machine logic with deduplication
     */
    private void processTranscript(String streamSid, String newTranscript) {
        try {
            StreamState state = streamStates.get(streamSid);
            if (state != StreamState.STREAMING && state != StreamState.COLLECTING_DATA) {
                logger.debug("Ignoring transcript in state: {}", state);
                return;
            }

            // Check minimum interval between transcript processing
            Long lastTime = lastTranscriptTime.get(streamSid);
            long currentTime = System.currentTimeMillis();
            if (lastTime != null && (currentTime - lastTime) < MIN_TRANSCRIPT_INTERVAL_MS) {
                logger.debug("Skipping transcript processing - too soon after last one ({} ms ago)", 
                            currentTime - lastTime);
                return;
            }

            logger.info("TRANSCRIPT[{}]: \"{}\"", streamSid, newTranscript);

            // Add to accumulated transcript
            StringBuilder accumulated = accumulatedTranscripts.get(streamSid);
            if (accumulated == null) {
                accumulated = new StringBuilder();
                accumulatedTranscripts.put(streamSid, accumulated);
            }

            if (accumulated.length() > 0) {
                accumulated.append(" ");
            }
            accumulated.append(newTranscript);

            // Update last transcript time
            lastTranscriptTime.put(streamSid, currentTime);

            // Send full context to AI
            String fullTranscript = accumulated.toString();
            logger.info("SENDING TO AI[{}]: \"{}\"", streamSid, fullTranscript);
            
            sendToAI(streamSid, fullTranscript);

        } catch (Exception e) {
            logger.error("Error processing transcript: {}", e.getMessage(), e);
        }
    }

    /**
     * Send transcript to AI and handle response with retry logic
     */
    private void sendToAI(String streamSid, String transcript) {
        sendToAIWithRetry(streamSid, transcript, 1);
    }
    
    /**
     * Send transcript to AI with retry logic for timeout handling
     */
    private void sendToAIWithRetry(String streamSid, String transcript, int attempt) {
        try {
            String callSid = streamInfo.getOrDefault(streamSid + "_callSid", "unknown");
            
            String requestBody = String.format("transcription=%s&callSid=%s&streamSid=%s",
                    java.net.URLEncoder.encode(transcript, "UTF-8"),
                    java.net.URLEncoder.encode(callSid, "UTF-8"),
                    java.net.URLEncoder.encode(streamSid, "UTF-8"));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(CONTROLLER_ENDPOINT))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .timeout(Duration.ofSeconds(15)) // Increased timeout
                    .build();

            CompletableFuture<HttpResponse<String>> futureResponse = httpClient.sendAsync(request,
                    HttpResponse.BodyHandlers.ofString());

            futureResponse.thenAccept(response -> {
                if (response.statusCode() == 200) {
                    handleAIResponse(streamSid, response.body());
                } else {
                    logger.error("AI endpoint returned status {}, response: {}", response.statusCode(), response.body());
                    if (attempt < 2) {
                        logger.info("Retrying AI request (attempt {})", attempt + 1);
                        sendToAIWithRetry(streamSid, transcript, attempt + 1);
                    } else {
                        streamStates.put(streamSid, StreamState.ERROR);
                    }
                }
            }).exceptionally(ex -> {
                logger.error("Failed to send to AI (attempt {}): {}", attempt, ex.getMessage());
                if (attempt < 2 && (ex.getCause() instanceof java.net.http.HttpTimeoutException || 
                                   ex.getMessage().contains("timeout"))) {
                    logger.info("Retrying AI request due to timeout (attempt {})", attempt + 1);
                    CompletableFuture.runAsync(() -> {
                        try {
                            Thread.sleep(1000); // Brief delay before retry
                            sendToAIWithRetry(streamSid, transcript, attempt + 1);
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                        }
                    });
                } else {
                    streamStates.put(streamSid, StreamState.ERROR);
                }
                return null;
            });

        } catch (Exception e) {
            logger.error("Error sending to AI (attempt {}): {}", attempt, e.getMessage(), e);
            if (attempt < 2) {
                logger.info("Retrying AI request due to exception (attempt {})", attempt + 1);
                sendToAIWithRetry(streamSid, transcript, attempt + 1);
            } else {
                streamStates.put(streamSid, StreamState.ERROR);
            }
        }
    }

    /**
     * Check if an action is duplicate within the cooldown period
     */
    private boolean isDuplicateAction(String streamSid, String action) {
        String lastAction = lastActionTaken.get(streamSid);
        Long lastTime = lastActionTime.get(streamSid);
        
        if (lastAction == null || lastTime == null) {
            return false; // No previous action recorded
        }
        
        long currentTime = System.currentTimeMillis();
        boolean isSameAction = action.equals(lastAction);
        boolean withinCooldown = (currentTime - lastTime) < ACTION_COOLDOWN_MS;
        
        if (isSameAction && withinCooldown) {
            logger.debug("Duplicate action detected: '{}' within {}ms cooldown", action, ACTION_COOLDOWN_MS);
            return true;
        }
        
        return false;
    }
    
    /**
     * Record an action for deduplication tracking
     */
    private void recordAction(String streamSid, String action) {
        long currentTime = System.currentTimeMillis();
        lastActionTaken.put(streamSid, action);
        lastActionTime.put(streamSid, currentTime);
        logger.debug("Recorded action '{}' at {} for stream {}", action, currentTime, streamSid);
    }

    /**
     * Handle AI response - core logic implementation
     */
    private void handleAIResponse(String streamSid, String responseBody) {
        try {
            String action = extractActionFromResponse(responseBody);
            logger.info("AI ACTION[{}]: {}", streamSid, action);

            // Check for duplicate actions and enforce cooldown period
            if (isDuplicateAction(streamSid, action)) {
                logger.info("Skipping duplicate action '{}' for stream {} (within cooldown period)", action, streamSid);
                return;
            }

            if ("wait".equals(action)) {
                // Continue accumulating - check wait cycle limit
                Integer cycles = waitCycles.getOrDefault(streamSid, 0);
                if (cycles >= MAX_WAIT_CYCLES) {
                    logger.warn("Max wait cycles reached for stream {}, forcing action", streamSid);
                    streamStates.put(streamSid, StreamState.ERROR);
                    return;
                }
                waitCycles.put(streamSid, cycles + 1);
                logger.info("AI said wait (cycle {}/{}), continuing to accumulate", cycles + 1, MAX_WAIT_CYCLES);
                return;
            }

            // Reset wait cycles on non-wait action
            waitCycles.put(streamSid, 0);

            if ("collect.data".equals(action)) {
                // Enter data collection mode
                streamStates.put(streamSid, StreamState.COLLECTING_DATA);
                dataCollectionStartTime.put(streamSid, System.currentTimeMillis());
                logger.info("Entering data collection mode for {} seconds", DATA_COLLECTION_TIMEOUT_MS / 1000);
                
                // Record action for deduplication
                recordAction(streamSid, action);
                return;
            }

            // Any other action - pause streaming, execute action, then resume
            streamStates.put(streamSid, StreamState.PAUSED);
            logger.info("Pausing stream {} to execute action: {}", streamSid, action);

            // Record action for deduplication
            recordAction(streamSid, action);

            // Clear accumulated transcript since we're taking action
            accumulatedTranscripts.put(streamSid, new StringBuilder());

            // Schedule resume (simplified - in real implementation, this would be triggered by Twilio callback)
            CompletableFuture.runAsync(() -> {
                try {
                    Thread.sleep(2000); // Wait for action to complete
                    resumeStreaming(streamSid);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });

        } catch (Exception e) {
            logger.error("Error handling AI response: {}", e.getMessage(), e);
            streamStates.put(streamSid, StreamState.ERROR);
        }
    }

    /**
     * Resume streaming after action completion
     */
    private void resumeStreaming(String streamSid) {
        StreamState currentState = streamStates.get(streamSid);
        if (currentState == StreamState.PAUSED) {
            streamStates.put(streamSid, StreamState.STREAMING);
            logger.info("Resumed streaming for {}", streamSid);
        }
    }

    /**
     * Execute hangup for data collection completion
     */
    private void executeHangup(String streamSid) {
        logger.info("Executing hangup for stream {}", streamSid);
        streamStates.put(streamSid, StreamState.ERROR);
    }

    // Helper methods

    private byte[] convertMulawToPcm(byte[] mulawData) {
        // μ-law to PCM conversion table
        int[] mulawToPcm = {
            -32124, -31100, -30076, -29052, -28028, -27004, -25980, -24956,
            -23932, -22908, -21884, -20860, -19836, -18812, -17788, -16764,
            -15996, -15484, -14972, -14460, -13948, -13436, -12924, -12412,
            -11900, -11388, -10876, -10364, -9852, -9340, -8828, -8316,
            -7932, -7676, -7420, -7164, -6908, -6652, -6396, -6140,
            -5884, -5628, -5372, -5116, -4860, -4604, -4348, -4092,
            -3900, -3772, -3644, -3516, -3388, -3260, -3132, -3004,
            -2876, -2748, -2620, -2492, -2364, -2236, -2108, -1980,
            -1884, -1820, -1756, -1692, -1628, -1564, -1500, -1436,
            -1372, -1308, -1244, -1180, -1116, -1052, -988, -924,
            -876, -844, -812, -780, -748, -716, -684, -652,
            -620, -588, -556, -524, -492, -460, -428, -396,
            -372, -356, -340, -324, -308, -292, -276, -260,
            -244, -228, -212, -196, -180, -164, -148, -132,
            -120, -112, -104, -96, -88, -80, -72, -64,
            -56, -48, -40, -32, -24, -16, -8, 0,
            32124, 31100, 30076, 29052, 28028, 27004, 25980, 24956,
            23932, 22908, 21884, 20860, 19836, 18812, 17788, 16764,
            15996, 15484, 14972, 14460, 13948, 13436, 12924, 12412,
            11900, 11388, 10876, 10364, 9852, 9340, 8828, 8316,
            7932, 7676, 7420, 7164, 6908, 6652, 6396, 6140,
            5884, 5628, 5372, 5116, 4860, 4604, 4348, 4092,
            3900, 3772, 3644, 3516, 3388, 3260, 3132, 3004,
            2876, 2748, 2620, 2492, 2364, 2236, 2108, 1980,
            1884, 1820, 1756, 1692, 1628, 1564, 1500, 1436,
            1372, 1308, 1244, 1180, 1116, 1052, 988, 924,
            876, 844, 812, 780, 748, 716, 684, 652,
            620, 588, 556, 524, 492, 460, 428, 396,
            372, 356, 340, 324, 308, 292, 276, 260,
            244, 228, 212, 196, 180, 164, 148, 132,
            120, 112, 104, 96, 88, 80, 72, 64,
            56, 48, 40, 32, 24, 16, 8, 0
        };

        byte[] pcmData = new byte[mulawData.length * 2];
        for (int i = 0; i < mulawData.length; i++) {
            int mulaw = mulawData[i] & 0xFF;
            short pcm = (short) mulawToPcm[mulaw];
            pcmData[i * 2] = (byte) (pcm & 0xFF);
            pcmData[i * 2 + 1] = (byte) ((pcm >> 8) & 0xFF);
        }
        return pcmData;
    }

    private String saveAudioChunk(String streamSid, byte[] buffer, int size) {
        try {
            String audioDir = streamInfo.get(streamSid);
            Integer chunkNum = chunkCounters.get(streamSid);
            
            if (audioDir == null || chunkNum == null) {
                return null;
            }

            String timestamp = java.time.LocalDateTime.now()
                    .format(java.time.format.DateTimeFormatter.ofPattern("HHmmss_SSS"));
            String filename = String.format("%s/chunk_%03d_%s_%s.wav",
                    audioDir, chunkNum, timestamp, streamSid.substring(0, 8));

            saveAsWav(filename, buffer, size);
            chunkCounters.put(streamSid, chunkNum + 1);
            
            return filename;
        } catch (Exception e) {
            logger.error("Error saving audio chunk: {}", e.getMessage(), e);
            return null;
        }
    }

    private void saveAsWav(String filename, byte[] audioData, int dataLength) throws IOException {
        try (FileOutputStream wavFile = new FileOutputStream(filename)) {
            // Write WAV header for 16kHz, 16-bit, mono
            int totalLength = dataLength + 36;
            int sampleRate = 16000; // Changed to 16kHz for better Silero VAD performance
            short channels = 1;
            short bitsPerSample = 16;

            wavFile.write("RIFF".getBytes());
            wavFile.write(intToBytes(totalLength));
            wavFile.write("WAVE".getBytes());
            wavFile.write("fmt ".getBytes());
            wavFile.write(intToBytes(16));
            wavFile.write(shortToBytes((short) 1));
            wavFile.write(shortToBytes(channels));
            wavFile.write(intToBytes(sampleRate));
            wavFile.write(intToBytes(sampleRate * channels * bitsPerSample / 8));
            wavFile.write(shortToBytes((short) (channels * bitsPerSample / 8)));
            wavFile.write(shortToBytes(bitsPerSample));
            wavFile.write("data".getBytes());
            wavFile.write(intToBytes(dataLength));
            wavFile.write(audioData, 0, dataLength);
        }
    }

    private byte[] intToBytes(int value) {
        return new byte[]{
                (byte) value,
                (byte) (value >> 8),
                (byte) (value >> 16),
                (byte) (value >> 24)
        };
    }

    private byte[] shortToBytes(short value) {
        return new byte[]{
                (byte) value,
                (byte) (value >> 8)
        };
    }

    private String transcribeAudio(String filename) throws Exception {
        if (!Files.exists(Paths.get(filename))) {
            return null;
        }

        byte[] audioBytes = Files.readAllBytes(Paths.get(filename));
        String boundary = "----WebKitFormBoundary" + System.currentTimeMillis();

        StringBuilder bodyBuilder = new StringBuilder();
        bodyBuilder.append("--").append(boundary).append("\r\n");
        bodyBuilder.append("Content-Disposition: form-data; name=\"audio\"; filename=\"")
                .append(Paths.get(filename).getFileName().toString()).append("\"\r\n");
        bodyBuilder.append("Content-Type: audio/wav\r\n\r\n");

        byte[] formPrefix = bodyBuilder.toString().getBytes();
        byte[] formSuffix = ("\r\n--" + boundary + "--\r\n").getBytes();

        byte[] requestBody = new byte[formPrefix.length + audioBytes.length + formSuffix.length];
        System.arraycopy(formPrefix, 0, requestBody, 0, formPrefix.length);
        System.arraycopy(audioBytes, 0, requestBody, formPrefix.length, audioBytes.length);
        System.arraycopy(formSuffix, 0, requestBody, formPrefix.length + audioBytes.length, formSuffix.length);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(TRANSCRIPTION_URL))
                .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                .POST(HttpRequest.BodyPublishers.ofByteArray(requestBody))
                .timeout(Duration.ofSeconds(30))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200) {
            JsonObject jsonResponse = gson.fromJson(response.body(), JsonObject.class);
            if (jsonResponse.get("success").getAsBoolean()) {
                return jsonResponse.get("transcription").getAsString();
            }
        }

        return null;
    }

    private String extractActionFromResponse(String responseBody) {
        if (responseBody == null || responseBody.isEmpty()) {
            return "wait";
        }

        // Extract action from TwiML response
        if (responseBody.contains("<Say") || responseBody.contains("<Play")) {
            return "action";
        }
        
        return "wait";
    }

    private String extractCallSidFromQuery(String query) {
        if (query == null || query.isEmpty()) {
            return null;
        }

        String[] params = query.split("&");
        for (String param : params) {
            String[] keyValue = param.split("=");
            if (keyValue.length == 2 && "callsid".equalsIgnoreCase(keyValue[0])) {
                return keyValue[1];
            }
        }
        return null;
    }

    @Override
    public void handleTransportError(@NonNull WebSocketSession session, @NonNull Throwable exception) throws Exception {
        logger.error("WebSocket transport error: {}", exception.getMessage(), exception);
    }

    @Override
    public void afterConnectionClosed(@NonNull WebSocketSession session, @NonNull CloseStatus closeStatus) throws Exception {
        logger.info("WebSocket connection closed: {} - {}", session.getId(), closeStatus);
    }

    @Override
    public boolean supportsPartialMessages() {
        return false;
    }

    /**
     * Public method to resume streaming (called from controller after action completion)
     */
    public void resumeProcessingForStream(String streamSid) {
        resumeStreaming(streamSid);
    }

    /**
     * Public method to resume streaming with buffer clearing (called from controller after major actions)
     */
    public void resumeProcessingAfterAction(String streamSid) {
        // Clear accumulated transcript for major context changes
        accumulatedTranscripts.put(streamSid, new StringBuilder());
        resumeStreaming(streamSid);
    }
}
