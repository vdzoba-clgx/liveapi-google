package com.cotality.ivra.bots_service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cotality.ivra.bots_service.IVR.IvrController;
import org.springframework.ui.Model;

/**
 * Main controller for handling root URL redirects and common API endpoints
 */
@Controller
public class MainController {
    
    @Autowired
    private IvrController ivrController;

    /**
     * Redirect root URL to the IVR simulation page
     */
    @GetMapping("/")
    public String index(Model model) {
        return ivrController.rootIndex(model);
    }
    
    /**
     * Endpoint for generating TwiML app from the root path
     */
    @PostMapping("/api/twiml/generate")
    @ResponseBody
    public ResponseEntity<?> generateTwiMLApp() {
        return ivrController.generateTwiMLApp();
    }
    
    /**
     * Endpoint for deploying to Twilio from the root path
     */
    @PostMapping("/api/twilio/deploy") 
    @ResponseBody
    public ResponseEntity<String> deployToTwilio() {
        return ivrController.deployToTwilio(null);
    }
    
    /**
     * Endpoint for testing Twilio connection from the root path
     */
    @GetMapping("/api/twilio/test")
    @ResponseBody
    public ResponseEntity<String> testTwilioConnection() {
        return ivrController.testTwilioConnection();
    }
    
    /**
     * Redirect /goals-history to /ivr/goals-history
     */
    @GetMapping("/goals-history")
    public String goalsHistoryRedirect() {
        return "redirect:/ivr/goals-history";
    }
}
