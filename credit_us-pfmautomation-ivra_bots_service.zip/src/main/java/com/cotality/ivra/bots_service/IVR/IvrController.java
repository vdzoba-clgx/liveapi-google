package com.cotality.ivra.bots_service.IVR;

import java.io.IOException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.cotality.ivra.bots_service.MenuLoader;
import com.cotality.ivra.bots_service.NavigationStep;
import com.cotality.ivra.bots_service.TwiMLGeneratorService;
import com.cotality.ivra.bots_service.TwilioService;
import com.cotality.ivra.bots_service.AudioStreamHandler;
import com.cotality.ivra.bots_service.GoogleLiveApiService;
import com.google.gson.JsonObject;

/**
 * Controller for handling IVR voice input requests
 */
@Controller
@RequestMapping("/ivr")
public class IvrController {

    private static final Logger logger = LoggerFactory.getLogger(IvrController.class);

    @Autowired
    private IvrNavigationService navigationService;

    @Autowired
    private IvrSimulationService simulationService;

    @Autowired
    private TwiMLGeneratorService twimlGeneratorService;

    @Autowired
    private AIActionResolver aiActionResolver;

    @Autowired
    private SimulationActionResolver simulationActionResolver;

    @Autowired
    private GoalHistoryService goalHistoryService;

    @Autowired
    private MenuLoader menuLoader;

    @Autowired
    private TwilioService twilioService;

    @Autowired
    private GoogleLiveApiService googleLiveApiService;

    @Autowired
    private AudioStreamHandler audioStreamHandler;

    private final ExecutorService executor = Executors.newCachedThreadPool();

    /**
     * Root index redirect to IVR simulation page
     */
    @GetMapping(value = "/", produces = MediaType.TEXT_HTML_VALUE)
    public String rootIndex(Model model) {
        return index(model);
    }

    /**
     * Display the main IVR simulation page
     */
    @GetMapping("/")
    public String index(Model model) {
        try {
            JsonObject goalsJson = menuLoader.loadGoals();
            model.addAttribute("goals", goalsJson.entrySet());
            return "index";
        } catch (IOException e) {
            model.addAttribute("error", "Could not load available goals: " + e.getMessage());
            return "error";
        }
    }

    /**
     * Handle POST request to start IVR simulation for a specific goal
     * Returns Server-Sent Events stream for real-time output
     */
    @PostMapping(value = "/goal/{goal_text}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter simulateGoal(@PathVariable("goal_text") String goalText) {
        SseEmitter emitter = new SseEmitter(300000L); // 5 minutes timeout
        CompletableFuture.runAsync(() -> {
            try {
                logger.info("Starting simulation for goal: {}", goalText);
                // Find navigation path for the goal
                List<NavigationStep> navigationPath = navigationService.generateNavigationPath(goalText);
                if (navigationPath == null) {
                    logger.warn("Goal '{}' not found in IVR menu structure", goalText);
                    emitter.send(SseEmitter.event()
                            .name("error")
                            .data("Goal '" + goalText + "' not found in IVR menu structure."));
                    emitter.complete();
                    return;
                }
                // Save to goal history
                List<GoalHistoryService.GoalEntry> history = goalHistoryService.loadHistory();
                List<GoalHistoryService.Step> steps = new java.util.ArrayList<>();
                int i = 1;
                for (NavigationStep step : navigationPath) {
                    steps.add(new GoalHistoryService.Step(i++, step.getPrompt(), step.getAction()));
                }
                history.add(new GoalHistoryService.GoalEntry(goalText, steps));
                goalHistoryService.saveHistory(history);
                // Send initial event indicating simulation start
                emitter.send(SseEmitter.event()
                        .name("start")
                        .data("Starting IVR simulation for goal: " + goalText));
                // Execute simulation with callback for real-time output
                simulationService.executeIvrSimulationForWeb(goalText, navigationPath, message -> {
                    try {
                        // Ensure message is not null
                        String safeMessage = message != null ? message : "[Empty message]";
                        emitter.send(SseEmitter.event()
                                .name("message")
                                .data(safeMessage));
                    } catch (IOException e) {
                        // Handle disconnection gracefully
                        emitter.completeWithError(e);
                    }
                });
                // Send completion event
                emitter.send(SseEmitter.event()
                        .name("complete")
                        .data("IVR simulation completed successfully"));

                emitter.complete();
            } catch (Exception e) {
                logger.error("Error during IVR simulation for goal '{}': {}", goalText, e.getMessage(), e);
                try {
                    String errorMessage = e.getMessage();
                    if (errorMessage == null || errorMessage.trim().isEmpty()) {
                        errorMessage = "Unknown error occurred: " + e.getClass().getSimpleName();
                    }
                    emitter.send(SseEmitter.event()
                            .name("error")
                            .data("Error during simulation: " + errorMessage));
                } catch (IOException ioException) {
                    // Ignore if client disconnected
                }
                emitter.completeWithError(e);
            }
        }, executor);

        // Handle client disconnect
        emitter.onCompletion(() -> {
            // Cleanup if needed
        });

        emitter.onTimeout(() -> {
            emitter.complete();
        });

        emitter.onError((ex) -> {
            emitter.complete();
        });

        return emitter;
    }

    /**
     * API endpoint to get available goals
     */
    @GetMapping("/api/goals")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getGoals() {
        try {
            JsonObject goalsJson = menuLoader.loadGoals();
            Map<String, Object> goalsMap = new HashMap<>();
            goalsJson.entrySet().forEach(entry -> goalsMap.put(entry.getKey(), entry.getValue().getAsString()));
            return ResponseEntity.ok(goalsMap);
        } catch (IOException e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Display simulation page for a specific goal or return JSON for API calls
     */
    @GetMapping(value = "/goal/{goal_text}", produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_HTML_VALUE })
    @ResponseBody
    public ResponseEntity<?> goalPage(@PathVariable("goal_text") String goalText,
            @RequestHeader(value = "Accept", defaultValue = "text/html") String acceptHeader,
            Model model) {
        try {
            // If JSON is requested (API call), return navigation path
            if (acceptHeader.contains("application/json") || acceptHeader.contains("*/*")) {
                List<NavigationStep> navigationPath = navigationService.generateNavigationPath(goalText);
                if (navigationPath == null) {
                    Map<String, String> errorResponse = new HashMap<>();
                    errorResponse.put("error", "Goal '" + goalText + "' not found in IVR menu structure");
                    return ResponseEntity.badRequest().body(errorResponse);
                }

                Map<String, Object> response = new HashMap<>();
                response.put("goal", goalText);
                response.put("navigationPath", navigationPath);
                return ResponseEntity.ok(response);
            }

            // Otherwise return HTML view (for web interface)
            JsonObject goalsJson = menuLoader.loadGoals();
            if (goalsJson.has(goalText)) {
                model.addAttribute("goalId", goalText);
                model.addAttribute("goalDescription", goalsJson.get(goalText).getAsString());
                return ResponseEntity.ok("simulation");
            } else {
                model.addAttribute("error", "Goal '" + goalText + "' not found.");
                return ResponseEntity.ok("error");
            }
        } catch (IOException e) {
            if (acceptHeader.contains("application/json") || acceptHeader.contains("*/*")) {
                Map<String, String> errorResponse = new HashMap<>();
                errorResponse.put("error", "Could not load goal information: " + e.getMessage());
                return ResponseEntity.internalServerError().body(errorResponse);
            } else {
                model.addAttribute("error", "Could not load goal information: " + e.getMessage());
                return ResponseEntity.ok("error");
            }
        }
    }

    /**
     * Handle POST request to execute IVR simulation for a specific goal
     * Executes simulation and logs directly to backend console
     */
    @PostMapping("/execute/{goal_text}")
    @ResponseBody
    public ResponseEntity<String> executeGoal(
            @PathVariable("goal_text") String goalText,
            @RequestBody(required = false) Map<String, String> requestBody) {
        try { // Extract execution mode from request body (default to 'bot' if not provided)
            String mode = "bot";
            if (requestBody != null && requestBody.containsKey("mode")) {
                mode = requestBody.get("mode");
            }

            logger.info("Executing simulation for goal: {} with mode: {}", goalText, mode);

            // Find navigation path for the goal
            List<NavigationStep> navigationPath = navigationService.generateNavigationPath(goalText);

            if (navigationPath == null) {
                logger.warn("Goal '{}' not found in IVR menu structure", goalText);
                return ResponseEntity.badRequest().body("Goal '" + goalText + "' not found in IVR menu structure.");
            }
            logger.info("Found navigation path with {} steps for goal: {} (mode: {})", navigationPath.size(), goalText,
                    mode);

            // Save to goal history
            List<GoalHistoryService.GoalEntry> history = goalHistoryService.loadHistory();
            List<GoalHistoryService.Step> steps = new java.util.ArrayList<>();
            int i = 1;
            for (NavigationStep step : navigationPath) {
                steps.add(new GoalHistoryService.Step(i++, step.getPrompt(), step.getAction()));
            }
            history.add(new GoalHistoryService.GoalEntry(goalText, steps));
            goalHistoryService.saveHistory(history); // Execute simulation with appropriate action resolver based on
                                                     // mode
            ActionResolver actionResolver = null;
            switch (mode.toLowerCase()) {
                case "bot":
                    logger.info("Executing goal '{}' in BOT mode using SimulationActionResolver", goalText);
                    actionResolver = simulationActionResolver;
                    break;
                case "autopilot":
                    logger.info("Executing goal '{}' in AUTOPILOT mode using AIActionResolver", goalText);
                    actionResolver = aiActionResolver;
                    break;
                case "autopilot++":
                    logger.info("Executing goal '{}' in AUTOPILOT++ mode using AIActionResolver with enhanced features",
                            goalText);
                    actionResolver = aiActionResolver;
                    break;
                default:
                    logger.warn("Unknown execution mode '{}' for goal '{}', defaulting to BOT mode", mode, goalText);
                    mode = "bot";
                    actionResolver = simulationActionResolver;
                    break;
            }

            simulationService.executeIvrSimulation(goalText, navigationPath, actionResolver);

            logger.info("IVR simulation completed successfully for goal: {} (mode: {})", goalText, mode);
            return ResponseEntity.ok("Simulation executed successfully in " + mode.toUpperCase() + " mode");

        } catch (Exception e) {
            logger.error("Error during IVR simulation for goal '{}': {}", goalText, e.getMessage(), e);
            return ResponseEntity.internalServerError().body("Error during simulation: " + e.getMessage());
        }
    }

    /**
     * Validate IVR navigation for a specific goal by comparing expected vs actual
     * actions
     */
    @PostMapping("/validate/{goal_text}")
    @ResponseBody
    public ResponseEntity<String> validateGoal(@PathVariable("goal_text") String goalText) {
        try {
            logger.info("Validating navigation for goal: {}", goalText);

            // Generate expected navigation path from bofa_ivr_menu.json
            List<NavigationStep> expectedPath = navigationService.generateNavigationPath(goalText);
            if (expectedPath == null) {
                return ResponseEntity.badRequest().body("Goal '" + goalText + "' not found in expected menu structure");
            }

            StringBuilder result = new StringBuilder();
            result.append("🔍 VALIDATION REPORT FOR GOAL: ").append(goalText).append("\n");
            result.append("=".repeat(60)).append("\n\n");

            boolean hasErrors = false;

            // Validate each step in the expected path against actual menu
            for (int i = 0; i < expectedPath.size(); i++) {
                NavigationStep expectedStep = expectedPath.get(i);
                String expectedAction = expectedStep.getAction();
                String prompt = expectedStep.getPrompt();
                String description = expectedStep.getDescription();

                result.append("📍 STEP ").append(i + 1).append(": ").append(description).append("\n");
                result.append("   Prompt: \"").append(prompt).append("\"\n");
                result.append("   Expected Action: ").append(expectedAction).append("\n");

                try {
                    // Get actual action that would be resolved for this prompt
                    String actualAction = simulationActionResolver.resolveAction(prompt, description, goalText);
                    result.append("   Actual Action:   ").append(actualAction).append("\n");

                    // Compare expected vs actual
                    if (!expectedAction.equals(actualAction)) {
                        result.append("   ❌ MISMATCH DETECTED!\n");
                        hasErrors = true;
                    } else {
                        result.append("   ✅ MATCH\n");
                    }

                } catch (Exception e) {
                    result.append("   Actual Action:   ERROR: ").append(e.getMessage()).append("\n");
                    result.append("   ❌ RESOLUTION FAILED!\n");
                    hasErrors = true;
                }

                result.append("\n");
            }

            result.append("=".repeat(60)).append("\n");
            if (hasErrors) {
                result.append("❌ VALIDATION FAILED: Mismatches detected!\n");
                logger.warn("Validation failed for goal '{}'", goalText);
                return ResponseEntity.status(422).body(result.toString());
            } else {
                result.append("✅ VALIDATION PASSED: All actions match expected behavior!\n");
                logger.info("Validation passed for goal '{}'", goalText);
                return ResponseEntity.ok(result.toString());
            }

        } catch (Exception e) {
            logger.error("Error during validation for goal '{}': {}", goalText, e.getMessage(), e);
            return ResponseEntity.internalServerError().body("Error during validation: " + e.getMessage());
        }
    }

    // ==============================
    // TwiML Webhook Endpoints
    // ==============================
    /**
     * TwiML webhook for main menu
     * Redirects to speech menu to simplify voice input handling
     */
    @PostMapping(value = "/twiml/main-menu", produces = MediaType.APPLICATION_XML_VALUE)
    @ResponseBody
    public String twimlMainMenu() {
        try {
            logger.info("Main menu requested, redirecting to speech input menu");
            // Return a redirect to the speech menu
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/ivr/twiml/speech-menu</Redirect></Response>";
        } catch (Exception e) {
            logger.error("Error generating main menu TwiML: {}", e.getMessage(), e);
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Say>Sorry, there was an error. Please try again later.</Say></Response>";
        }
    }

    /**
     * TwiML webhook for status callbacks
     */
    @PostMapping(value = "/twiml/status", produces = MediaType.APPLICATION_XML_VALUE)
    @ResponseBody
    public String twimlStatus(@RequestParam(value = "CallStatus", required = false) String callStatus,
            @RequestParam(value = "CallSid", required = false) String callSid,
            @RequestParam(value = "From", required = false) String from) {
        logger.info("TwiML Status callback - CallStatus: {}, CallSid: {}, From: {}", callStatus, callSid, from);
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response></Response>";
    }

    /**
     * TwiML webhook for submenu input handling
     */
    @PostMapping(value = "/twiml/handle-submenu/{parentDigit}", produces = MediaType.APPLICATION_XML_VALUE)
    @ResponseBody
    public String twimlHandleSubmenu(@PathVariable String parentDigit,
            @RequestParam(value = "Digits", required = false) String digits,
            @RequestParam(value = "From", required = false) String from,
            @RequestParam(value = "CallSid", required = false) String callSid) {
        try {
            logger.info("Handling TwiML submenu input - Parent: {}, Digits: {}, From: {}, CallSid: {}", parentDigit,
                    digits, from, callSid);
            return twimlGeneratorService.generateSubMenuInputHandlerTwiML(parentDigit, digits);
        } catch (Exception e) {
            logger.error("Error handling TwiML submenu input: {}", e.getMessage(), e);
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Say>Sorry, there was an error. Returning to main menu.</Say><Redirect>/twiml/main-menu</Redirect></Response>";
        }
    } // ==============================
    // TwiML Generation Endpoints
    // ==============================

    /**
     * Generate and preview TwiML for the IVR Application
     */
    @PostMapping("/api/twiml/generate")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> generateTwiMLApp() {
        try {
            logger.info("Generating IVR Application TwiML...");

            // Use our method that encapsulates all IVR app generation logic
            Map<String, Object> result = twimlGeneratorService.generateIvrAppTwiML();

            logger.info("TwiML app generation completed successfully");
            return ResponseEntity.ok(result);

        } catch (Exception e) {
            logger.error("Error generating TwiML app: {}", e.getMessage(), e);
            Map<String, Object> error = new HashMap<>();
            error.put("error", "Failed to generate TwiML app: " + e.getMessage());
            return ResponseEntity.internalServerError().body(error);
        }
    }

    /**
     * Generate and deploy TwiML app to Twilio with dynamic menu structure
     */
    @PostMapping("/api/twiml/generate-and-deploy")
    @ResponseBody
    public ResponseEntity<String> generateAndDeployTwiMLApp(
            @RequestParam(value = "webhookUrl", required = false) String webhookUrl) {
        try {
            logger.info("Generating and deploying dynamic TwiML app to Twilio...");

            // First generate TwiML to ensure it works
            String mainMenuTwiML = twimlGeneratorService.generateMainMenuTwiML();
            logger.info("Successfully generated main menu TwiML: {} characters", mainMenuTwiML.length());

            // Validate Twilio configuration
            if (!twilioService.validateConfiguration()) {
                return ResponseEntity.badRequest().body(
                        "Twilio configuration is invalid. Please check your Account SID and Auth Token in application.properties");
            }

            // Test Twilio connection
            if (!twilioService.testConnection()) {
                return ResponseEntity.badRequest().body("Unable to connect to Twilio. Please check your credentials.");
            }

            // Use provided webhook URL or default to localhost
            String baseUrl = (webhookUrl != null && !webhookUrl.trim().isEmpty()) ? webhookUrl
                    : twilioService.getWebhookBaseUrl();

            logger.info("Using webhook base URL: {}", baseUrl);

            // Create or update TwiML application with dynamic menu structure
            String applicationSid = twilioService.createOrUpdateTwiMLApplication(baseUrl);

            String message = String.format(
                    "Successfully generated and deployed dynamic TwiML app to Twilio!\n\n" +
                            "✓ Application SID: %s\n" +
                            "✓ Phone Number: %s\n" +
                            "✓ Main Menu Webhook: %s/twiml/main-menu\n" +
                            "✓ Input Handler: %s/twiml/handle-input\n" +
                            "✓ Submenu Handler: %s/twiml/handle-submenu/{parentDigit}\n" +
                            "✓ Status Callback: %s/twiml/status\n\n" +
                            "The IVR now uses the complete Bank of America menu structure from your JSON configuration!\n"
                            +
                            "Call %s to test the interactive voice response system.",
                    applicationSid,
                    twilioService.getPhoneNumber(),
                    baseUrl, baseUrl, baseUrl, baseUrl,
                    twilioService.getPhoneNumber());

            logger.info("Dynamic TwiML app deployment completed successfully");
            return ResponseEntity.ok(message);

        } catch (Exception e) {
            logger.error("Error generating and deploying TwiML app: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                    .body("Error generating and deploying TwiML app: " + e.getMessage());
        }
    }

    /**
     * Deploy existing TwiML app to Twilio without regenerating, using separate
     * configuration files for inbound and outbound calls
     */
    @PostMapping("/api/twilio/deploy")
    @ResponseBody
    public ResponseEntity<String> deployToTwilio(
            @RequestParam(value = "webhookUrl", required = false) String webhookUrl) {
        try {
            logger.info("Deploying to Twilio with separate inbound and outbound configurations...");

            // Validate Twilio configuration
            if (!twilioService.validateConfiguration()) {
                return ResponseEntity.badRequest().body(
                        "Twilio configuration is invalid. Please check your Account SID and Auth Token in application.properties");
            }

            // Test Twilio connection
            if (!twilioService.testConnection()) {
                return ResponseEntity.badRequest().body("Unable to connect to Twilio. Please check your credentials.");
            }

            // Use provided webhook URL or default to ngrok
            String baseUrl = (webhookUrl != null && !webhookUrl.trim().isEmpty()) ? webhookUrl
                    : twilioService.getWebhookBaseUrl();

            logger.info("Using webhook base URL: {}", baseUrl); 
            // Create or update TwiML applications for both inbound and outbound calls 
            String inboundAppSid = twilioService.createOrUpdateTwiMLApplication(baseUrl, "inbound_calls_twiml.xml");
            String outboundAppSid = twilioService.createOrUpdateTwiMLApplication(baseUrl, "outbound_calls_twiml.xml");
            // We've consolidated to one outbound app, so no need for a separate AI outbound
            // app

            String message = String.format(
                    "Successfully deployed TwiML apps to Twilio!\n\n" +
                            "INBOUND CALLS CONFIGURATION:\n" +
                            "✓ Application SID: %s\n" +
                            "✓ Phone Number: %s\n" +
                            "✓ Main Menu Webhook: %s/twiml/main-menu\n" +
                            "✓ Input Handler: %s/twiml/handle-input\n" +
                            "✓ Submenu Handler: %s/twiml/handle-submenu/{parentDigit}\n" +
                            "✓ Status Callback: %s/twiml/status\n\n" +
                            "OUTBOUND CALLS CONFIGURATION:\n" +
                            "✓ Application SID: %s\n" +
                            "✓ Initial Webhook: %s/outbound/outbound-initial\n" +
                            "✓ AI Process Handler: %s/outbound/outbound-ai-process\n" +
                            "✓ AI Navigation Handler: %s/outbound/outbound-ai-navigate\n\n" +
                            "The IVR is now live and ready to receive/make calls!\n" +
                            "Call %s to test the inbound interactive voice response system.",
                    inboundAppSid,
                    twilioService.getPhoneNumber(),
                    baseUrl, baseUrl, baseUrl, baseUrl,
                    outboundAppSid,
                    baseUrl, baseUrl, baseUrl,
                    twilioService.getPhoneNumber());

            logger.info("TwiML apps deployment completed successfully");
            return ResponseEntity.ok(message);

        } catch (Exception e) {
            logger.error("Error deploying to Twilio: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body("Error deploying to Twilio: " + e.getMessage());
        }
    }

    /**
     * Test Twilio connection and configuration
     */
    @GetMapping("/api/twilio/test")
    @ResponseBody
    public ResponseEntity<String> testTwilioConnection() {
        try {
            logger.info("Testing Twilio connection...");

            // Validate Twilio configuration
            if (!twilioService.validateConfiguration()) {
                return ResponseEntity.badRequest().body(
                        "Twilio configuration is invalid. Please check your Account SID and Auth Token in application.properties");
            }

            // Test Twilio connection
            if (!twilioService.testConnection()) {
                return ResponseEntity.badRequest()
                        .body("Unable to connect to Twilio. Please check your credentials and internet connection.");
            }

            // Get phone number if available
            String phoneNumber = twilioService.getPhoneNumber();

            String message = String.format(
                    "✓ Twilio connection successful!\n" +
                            "✓ Account SID verified\n" +
                            "✓ Auth Token validated\n" +
                            "✓ Phone Number: %s\n" +
                            "✓ Webhook Base URL: %s\n\n" +
                            "Ready to deploy TwiML applications!",
                    phoneNumber != null ? phoneNumber : "No phone number configured",
                    twilioService.getWebhookBaseUrl());

            logger.info("Twilio connection test completed successfully");
            return ResponseEntity.ok(message);

        } catch (Exception e) {
            logger.error("Error testing Twilio connection: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body("Error testing Twilio connection: " + e.getMessage());
        }
    }

    /**
     * API endpoint to get goal history
     */
    @GetMapping("/goal-history")
    @ResponseBody
    public List<GoalHistoryService.GoalEntry> getGoalHistory() {
        return goalHistoryService.loadHistory();
    }

    /**
     * API endpoint to clear goal history
     */
    @DeleteMapping("/goal-history")
    @ResponseBody
    public void clearGoalHistory() {
        goalHistoryService.saveHistory(new java.util.ArrayList<>());
    }

    /**
     * Display the goal history page
     */
    @GetMapping("/goals-history")
    public String goalHistoryPage() {
        return "goal_history";
    }

    // ==============================
    // Voice Input Handling Endpoints
    // ==============================

    /**
     * TwiML webhook for speech input menu
     * This endpoint generates TwiML to prompt the user for speech input
     */
    @PostMapping(value = "/twiml/speech-menu", produces = MediaType.APPLICATION_XML_VALUE)
    @ResponseBody
    public String speechInputMenu() {
        try {
            logger.info("Generating speech input menu for IVR");
            return twimlGeneratorService.generateSpeechInputTwiML();
        } catch (Exception e) {
            logger.error("Error generating speech input menu: {}", e.getMessage(), e);
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Say>Sorry, there was an error. Please try again later.</Say></Response>";
        }
    }

    /**
     * TwiML webhook for handling speech input
     * This endpoint processes the speech input from the user and generates an
     * appropriate response
     */
    @PostMapping(value = "/twiml/handle-speech", produces = MediaType.APPLICATION_XML_VALUE)
    @ResponseBody
    public String handleSpeechInput(@RequestParam(value = "SpeechResult", required = false) String speechResult) {
        logger.info("Received speech input in IVR: {}", speechResult);
        try {
            return twimlGeneratorService.generateIvrSpeechResponseTwiML(speechResult);
        } catch (Exception e) {
            logger.error("Error handling speech input: {}", e.getMessage(), e);
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Say>Sorry, there was an error processing your speech. Please try again.</Say><Redirect>/twiml/speech-menu</Redirect></Response>";
        }
    }

    /**
     * TwiML webhook for speech input menu in IVR
     */
    @PostMapping(value = "/twiml/ivr-speech-menu", produces = MediaType.APPLICATION_XML_VALUE)
    @ResponseBody
    public String ivrSpeechMenu() {
        try {
            logger.info("Generating IVR speech input menu");
            return twimlGeneratorService.generateIvrSpeechInputTwiML();
        } catch (Exception e) {
            logger.error("Error generating IVR speech menu: {}", e.getMessage(), e);
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Say>Sorry, there was an error. Please try again later.</Say></Response>";
        }
    }

    /**
     * TwiML webhook for handling speech input in IVR
     */
    @PostMapping(value = "/twiml/ivr-handle-speech", produces = MediaType.APPLICATION_XML_VALUE)
    @ResponseBody
    public String handleIvrSpeechInput(@RequestParam(value = "SpeechResult", required = false) String speechResult) {
        logger.info("Received IVR speech input: {}", speechResult);
        try {
            return twimlGeneratorService.generateIvrSpeechResponseTwiML(speechResult);
        } catch (Exception e) {
            logger.error("Error handling IVR speech input: {}", e.getMessage(), e);
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Say>Sorry, there was an error processing your speech. Please try again.</Say><Redirect>/twiml/ivr-speech-menu</Redirect></Response>";
        }
    }

    /**
     * Make an AI-powered outbound call to a specified phone number with a goal
     * 
     * @param phoneNumber The phone number to call (in E.164 format, e.g.,
     *                    +12345678901)
     * @param goal        The goal to achieve (e.g., "account_balance_inquiry")
     * @return Status of the outbound call initiation
     */
    @PostMapping("/ai-outbound-call")
    public ResponseEntity<String> makeAiOutboundCall(
            @RequestParam("phone") String phoneNumber,
            @RequestParam(value = "goal", required = false, defaultValue = "account_balance_inquiry") String goal) {
        logger.info("Request to make AI-powered outbound call to {} with goal {}", phoneNumber, goal);

        try {
            // Validate phone number format
            if (!phoneNumber.startsWith("+")) {
                return ResponseEntity.badRequest().body("Phone number must be in E.164 format (e.g., +12345678901)");
            }

            // Make the outbound call
            String callSid = twilioService.makeAiOutboundCall(phoneNumber, goal);

            // Note: The AudioStreamHandler will receive the stream when the call connects
            // and we'll need to set the goal at that point. For now, this is handled
            // in the webhook flow when the media stream starts.
            
            logger.info("Initiated AI-powered outbound call with SID: {} for goal: {}", callSid, goal);
            return ResponseEntity.ok("Initiated AI-powered outbound call with SID: " + callSid + " for goal: " + goal);

        } catch (Exception e) {
            logger.error("Error making AI-powered outbound call: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                    .body("Error making AI-powered outbound call: " + e.getMessage());
        }
    }
    
    /**
     * Set goal for a specific stream (called when stream starts)
     */
    @PostMapping("/api/set-goal/{streamSid}")
    @ResponseBody
    public ResponseEntity<String> setGoalForStream(
            @PathVariable("streamSid") String streamSid,
            @RequestParam("goal") String goal) {
        try {
            googleLiveApiService.setGoalForStream(streamSid, goal);
            logger.info("Set goal '{}' for stream {}", goal, streamSid);
            return ResponseEntity.ok("Goal set successfully");
        } catch (Exception e) {
            logger.error("Error setting goal for stream {}: {}", streamSid, e.getMessage(), e);
            return ResponseEntity.internalServerError().body("Error setting goal: " + e.getMessage());
        }
    } // We've consolidated the AI outbound functionality into the standard deployment
      // endpoint
    // Use the /api/twilio/deploy endpoint instead
}
