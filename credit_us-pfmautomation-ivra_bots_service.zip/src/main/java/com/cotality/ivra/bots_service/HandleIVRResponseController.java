package com.cotality.ivra.bots_service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;

import com.twilio.twiml.VoiceResponse;
import com.twilio.twiml.voice.Say;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Call;
import com.twilio.type.Twiml;

import jakarta.servlet.http.HttpServletRequest;

import com.twilio.twiml.voice.Redirect;

import com.cotality.ivra.bots_service.AI.ChatHistoryService;
import com.cotality.ivra.bots_service.AI.ChatHistoryService.Message;
import com.cotality.ivra.bots_service.IVR.AIActionResolver;

import java.util.List;
import java.util.ArrayList;
import java.io.UnsupportedEncodingException;

/**
 * Controller for handling Twilio webhook requests
 */
@RestController
public class HandleIVRResponseController {

    private static final Logger logger = LoggerFactory.getLogger(HandleIVRResponseController.class);
    @Autowired
    private TwiMLGeneratorService twiMLGeneratorService;

    @Autowired
    private AIActionResolver aiActionResolver;

    @Autowired
    private ChatHistoryService chatHistoryService;

    @Autowired
    private TwilioService twilioService;
    // private final Map<String, String> streamToCallSidMap = new HashMap<>();

    // Store call context (single call only)
    private String callContext = "start";
    private String callGoal = "account_balance_inquiry";
    private int callStep = 0;
    private final List<String> callResponses = new ArrayList<>();

    // Store the current call's CallSid for the audio stream to use
    private static String currentCallSid = null;

    /**
     * Set the current call's CallSid - static method that can be called from
     * anywhere
     * 
     * @param callSid The CallSid to store
     */
    public static void setCurrentCallSid(String callSid) {
        if (callSid != null && !callSid.isEmpty()) {
            currentCallSid = callSid;
            LoggerFactory.getLogger(HandleIVRResponseController.class)
                    .info("Stored current call SID: {}", callSid);
        }
    }

    /**
     * Get the current call's CallSid
     * 
     * @return The current CallSid or null if not set
     */
    public static String getCurrentCallSid() {
        return currentCallSid;
    }

    /**
     * Get the current call's goal
     * 
     * @return The current call goal
     */
    public String getCurrentCallGoal() {
        return callGoal;
    }
    
    private static HandleIVRResponseController instance;
    
    public HandleIVRResponseController() {
        instance = this;
    }
    
    public static HandleIVRResponseController getInstance() {
        return instance;
    }

    /**
     * Initial endpoint for outbound calls that serves TwiML to properly capture IVR
     * speech
     */
    @PostMapping(value = "/outbound/outbound-initial", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleOutboundInitial(@RequestParam(value = "goal", required = false) String goal,
            @RequestParam(value = "CallSid", required = false) String callSid) {
        logger.info("Starting outbound call with goal: {}, CallSid: {}", goal, callSid);
        try { // Initialize call context and tracking
            callContext = "start";
            callGoal = goal != null ? goal : "account_balance_inquiry";
            callStep = 0;
            callResponses.clear();

            // Store the callSid for this call (static method)
            if (callSid != null && !callSid.isEmpty()) {
                setCurrentCallSid(callSid);
                logger.info("Stored callSid for current call: {}", callSid);
            } else {
                logger.warn("No CallSid available for this call");
            }

            // Log the start of the call in AI chat history
            List<Message> messages = new ArrayList<>();
            messages.add(new Message("user", "Starting outbound call with goal: " + callGoal));
            chatHistoryService.saveHistory(messages); // Return TwiML to stream audio and gather speech from IVR
                                                      // system// Create a stream URL that includes the callSid as a
                                                      // parameter
            String streamUrl = "wss://" + twilioService.getWebhookBaseUrl().replace("https://", "") + "/ws/audio-stream";
            if (callSid != null && !callSid.isEmpty()) {
                streamUrl += "?callsid=" + callSid;
            }

            // Use absolute HTTPS URLs for PCI compliance
            String baseUrl = twilioService.getWebhookBaseUrl();
            String actionUrl = baseUrl + "/outbound/outbound-ai-process";
            String redirectUrl = baseUrl + "/outbound/outbound-ai-navigate";

            String twimlResponse = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                    "<Response>" +
                    "<Start><Stream url=\"" + streamUrl + "\" /></Start>" +
                    "<Gather action=\"" + actionUrl + "\" input=\"dtmf speech\" language=\"en-US\" method=\"POST\" timeout=\"60\">"
                    +
                    "</Gather>" +
                    "<Redirect>" + redirectUrl + "</Redirect>" +
                    "</Response>";

            logger.info("Generated initial TwiML with streaming and absolute URLs: {}", twimlResponse);
            return twimlResponse;
        } catch (Exception e) {
            logger.error("Error starting outbound call: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles outbound AI-powered call initiation
     */
    @PostMapping(value = "/outbound/outbound-ai-start", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleOutboundAiStart(@RequestParam(value = "goal", required = false) String goal) {
        logger.info("Starting AI-powered outbound call with goal: {}", goal);
        try {
            // Initialize call context and tracking
            callContext = "start";
            callGoal = goal != null ? goal : "account_balance_inquiry";
            callStep = 0;
            callResponses.clear();

            // Log the start of the call in AI chat history
            List<Message> messages = new ArrayList<>();
            messages.add(new Message("user", "Starting outbound call with goal: " + callGoal));
            chatHistoryService.saveHistory(messages);
            
            // Redirect to the navigation handler using absolute HTTPS URL for PCI compliance
            String baseUrl = twilioService.getWebhookBaseUrl();
            String redirectUrl = baseUrl + "/outbound/outbound-ai-navigate";
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>" + redirectUrl + "</Redirect></Response>";
        } catch (Exception e) {
            logger.error("Error starting AI-powered outbound call: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles the AI navigation of IVR system
     */
    @PostMapping(value = "/outbound/outbound-ai-navigate", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleOutboundAiNavigate(@RequestParam(value = "SpeechResult", required = false) String speechResult,
            HttpServletRequest request) {
        // logger.info("URL:{} and query string: {}", request.getRequestURL(),
        // request.getQueryString());
        // logger.info("handleOutboundAiNavigate - AI navigating IVR. Speech result:
        // {}", speechResult);
        try {
            // Get current call context and step
            String context = callContext;
            int step = callStep;
            String goal = callGoal;

            // Get the IVR prompt from the actual speech received
            String ivrPrompt = speechResult;
            if (ivrPrompt == null || ivrPrompt.isEmpty()) {
                // Use generic context with step information
                String stepContext = getContextForStep(step);
                logger.info("No speech result available at step {}. Using generic context: {}", step, stepContext);
                // If no speech is available, we'll rely on the AI to determine action based on
                // context
                ivrPrompt = "No speech detected. " + stepContext;
            } else {
                logger.info("Using received speech as IVR prompt: {}", ivrPrompt);
            }

            // Update call history
            List<Message> messages = chatHistoryService.loadHistory();
            messages.add(new Message("user", "Current IVR prompt: " + ivrPrompt));
            String action = aiActionResolver.resolveUsingAI(ivrPrompt, context, goal);
            messages.add(new Message("ai", "Selected action: " + action));
            chatHistoryService.saveHistory(messages);

            // Update call context
            updateCallContext(action, step);

            // Generate TwiML based on AI-determined action
            VoiceResponse voiceResponse = generateNavigationTwiML(action);

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error during AI IVR navigation: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Processes user input during AI navigation
     */
    @PostMapping(value = "/outbound/outbound-ai-process", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleOutboundAiProcess(@RequestParam(value = "Digits", required = false) String digits,
            @RequestParam(value = "SpeechResult", required = false) String speechResult) {
        logger.info("handleOutboundAiProcess. Processing user input during AI navigation - Digits: {}, Speech: {}",
                digits, speechResult);
        try {
            // Record user input in call responses
            String input = speechResult != null ? speechResult : (digits != null ? digits : "");
            if (!input.isEmpty()) {
                callResponses.add(input);

                // Record in AI chat history
                List<Message> messages = chatHistoryService.loadHistory();
                messages.add(new Message("user", "User input: " + input));
                chatHistoryService.saveHistory(messages);
            }

            // Continue navigation and pass the speech result to the navigation endpoint
            // Use absolute HTTPS URL for PCI compliance
            String baseUrl = twilioService.getWebhookBaseUrl();
            String redirectUrl = baseUrl + "/outbound/outbound-ai-navigate";

            if (speechResult != null) {
                try {
                    redirectUrl += "?SpeechResult=" + java.net.URLEncoder.encode(speechResult, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    logger.warn("Failed to encode speech result: {}", e.getMessage());
                }
            }
            
            VoiceResponse.Builder responseBuilder = new VoiceResponse.Builder();
            responseBuilder.redirect(new Redirect.Builder(redirectUrl).build());
            String responseString = responseBuilder.build().toXml();
            // logger.info("Redirecting to: {}", redirectUrl);
            return responseString;

        } catch (Exception e) {
            logger.error("Error processing user input during AI navigation: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles transcriptions from the streaming audio service
     * This endpoint is called by AudioStreamHandler when there's enough transcribed
     * text
     * It centralizes all AI/decision logic for processing real-time transcriptions
     */
    @PostMapping(value = "/outbound/stream-transcription", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleStreamingTranscription(@RequestParam(value = "transcription") String transcription,
            @RequestParam(value = "streamSid") String streamSid,
            @RequestParam(value = "callSid", required = false) String callSid) {
        logger.info("Handling streaming transcription - Stream SID: {}, Call SID: {}, Text: \"{}\"",
                streamSid, callSid, transcription);

        try {
            if (transcription == null || transcription.trim().isEmpty()) {
                logger.warn("Empty transcription received, ignoring");
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response></Response>";
            }

            // Use the AI to determine an action based on the transcription
            String context = callContext;
            String goal = callGoal;

            // Update call history
            List<Message> messages = chatHistoryService.loadHistory();
            messages.add(new Message("user", "Streaming transcription: \"" + transcription + "\""));

            // Determine action using AI
            String action = aiActionResolver.resolveUsingAI(transcription, context, goal);
            messages.add(new Message("ai", "Selected action from streaming: \"" + action + "\""));
            chatHistoryService.saveHistory(messages);

            // Trim the action to handle any whitespace issues
            action = action != null ? action.trim() : "";
            
            logger.info("Streaming AI determined action: \"{}\"", action);

            // If action is wait, just return an empty response (no action needed)
            if ("wait".equals(action)) {
                logger.debug("Wait action determined - allowing <Gather> to continue");
                // For wait actions, we should NOT clear transcriptions - they should accumulate
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response></Response>";
            }

            // For non-wait actions, we need to update the context and send instructions to
            // Twilio
            logger.info("Non-wait action detected: \"{}\" - will interrupt current <Gather>", action);

            // Update call context for non-wait actions
            updateCallContext(action, callStep);

            // Generate TwiML based on AI-determined action
            VoiceResponse voiceResponse = generateNavigationTwiML(action); // Check if we have a valid callSid
            boolean hasValidCallSid = callSid != null && !callSid.isEmpty() && !callSid.equals("unknown");

            // Log detailed information about the callSid
            if (hasValidCallSid) {
                logger.info("Using CallSid: {} to update call with action: {}", callSid, action);
            } else {
                logger.warn("Invalid CallSid received: '{}'. Cannot update call with action: {}", callSid, action);
                // We'll still return the TwiML so AudioStreamHandler can reset transcription
            }

            // If we have a valid callSid, update the call with new TwiML
            if (hasValidCallSid) {
                try {
                    // Initialize Twilio with credentials from TwilioService
                    String accountSid = twilioService.getAccountSid();
                    String authToken = twilioService.getAuthToken();

                    // Check if we have valid credentials
                    if (accountSid == null || accountSid.isEmpty() ||
                            authToken == null || authToken.isEmpty() ||
                            accountSid.equals("YOUR_TWILIO_ACCOUNT_SID_HERE")) {
                        logger.error("Invalid Twilio credentials: accountSid={}, authToken={}...",
                                accountSid,
                                authToken != null && authToken.length() > 4 ? authToken.substring(0, 4) + "..."
                                        : "null");
                        throw new IllegalStateException("Invalid Twilio credentials");
                    }

                    logger.info("Initializing Twilio with accountSid: {}", accountSid);
                    Twilio.init(accountSid, authToken);

                    // Create Twiml object with the generated response
                    Twiml twiml = new Twiml(voiceResponse.toXml());

                    // Update the call with the new TwiML - this interrupts the current <Gather>
                    logger.info("Sending Twilio API request to update call {} with new TwiML", callSid);
                    Call.updater(callSid)
                            .setTwiml(twiml)
                            .update();

                    logger.info("Successfully updated call {} with action \"{}\" - <Gather> interrupted",
                            callSid, action);

                    // Add a confirmation message to the chat history
                    messages = chatHistoryService.loadHistory();
                    messages.add(new Message("system", "Executed action \"" + action +
                            "\" based on streaming transcription"));
                    chatHistoryService.saveHistory(messages);

                    // Signal to AudioStreamHandler that transcription should be reset
                    // This is done by returning a non-empty response

                } catch (Exception e) {
                    logger.error("Failed to update call with Twilio API: {}", e.getMessage(), e);
                }
            } else {
                logger.warn("No valid callSid available to update call. Cannot execute action: \"{}\"", action);
            }

            // Return the TwiML regardless (for debugging/logging purposes)
            // AudioStreamHandler will detect this non-empty response and reset its
            // transcript buffer
            return voiceResponse.toXml();

        } catch (Exception e) {
            logger.error("Error processing streaming transcription: {}", e.getMessage(), e);
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response></Response>";
        }
    }

    /**
     * Helper method to generate TwiML based on AI action
     */
    private VoiceResponse generateNavigationTwiML(String action) {
        if (action == null || action.isEmpty()) {
            action = "wait";
        }
        VoiceResponse.Builder responseBuilder = new VoiceResponse.Builder();
        if (action.startsWith("press.last_4_ssn")) {
            logger.info("Executing DTMF action to enter SSN: ****");

            // Send the SSN digits using Twilio's native SendDigits with # terminator if needed
            playDtmfDigits(responseBuilder, "0373");

        } else if (action.startsWith("press.")) {
            String digits = action.substring("press.".length());
            logger.info("Executing DTMF action to press: {}", digits);

            // Send DTMF tones using Twilio's native functionality
            playDtmfDigits(responseBuilder, digits);

        } else if (action.equals("wait")) {
            logger.info("Executing wait action");
        } else if (action.startsWith("say.")) {
            String speech = action.substring("say.".length());
            logger.info("Executing speech action: {}", speech);
            responseBuilder.say(new Say.Builder(speech).build());
        } else if (action.equals("collect.data")) {
            logger.info("Executing collect.data and hangup action");
            responseBuilder.hangup(new com.twilio.twiml.voice.Hangup.Builder().build());
            VoiceResponse response = responseBuilder.build();
            logger.debug("Generated TwiML for hangup: {}", response.toXml());
            return response;
        } // Log the action taken before redirecting logger.info("Action {} completed.
          // Setting up speech gathering for next step.", action);

        // Increased timeout to allow streaming-based actions to work
        // This gives more time for audio streaming and transcription before Twilio's
        // gather timeout
        int timeout = 60;

        // Don't start stream again - it should be started only once at the beginning of
        // the call
        // Use absolute HTTPS URLs for PCI compliance
        String baseUrl = twilioService.getWebhookBaseUrl();
        String actionUrl = baseUrl + "/outbound/outbound-ai-process";
        String redirectUrl = baseUrl + "/outbound/outbound-ai-navigate";
        
        responseBuilder.gather(new com.twilio.twiml.voice.Gather.Builder()
                .action(actionUrl)
                .inputs(com.twilio.twiml.voice.Gather.Input.SPEECH)
                .language(com.twilio.twiml.voice.Gather.Language.EN_US)
                .timeout(timeout)
                .build());// Fallback redirect in case there's no speech detected
        responseBuilder.redirect(new Redirect.Builder(redirectUrl).build());

        VoiceResponse response = responseBuilder.build();
        logger.debug("Generated TwiML for action '{}': {}", action, response.toXml());
        return response;
    }

    /**
     * Helper method to update call context based on AI action
     */
    private void updateCallContext(String action, int currentStep) {
        // Update the context based on the action
        callContext = action;

        // Special handling for SSN entry - we'll need to advance past authentication
        if (action.equals("press.last_4_ssn")) {
            logger.info("SSN entry detected at step {}. Moving to next menu phase", currentStep);
            // Advance steps - let the AI handle determining where we are based on context
            callStep = currentStep + 2;
        } else {
            // Normal progression - just increment the step counter
            callStep = currentStep + 1;
        }
    }

    /**
     * Helper method to get a generic context based on the current step
     */    private String getContextForStep(int step) {
        // This is a much more flexible approach that doesn't rely on exact IVR prompts
        // It just provides minimal contextual information about where we are in the flow
        return "Currently at step " + step + " of the IVR flow";
    }
    
    // The getDtmfAudioUrl method was removed in favor of using Twilio's native SendDigits functionality
    
    /**
     * Helper method to send DTMF digits using Twilio's native SendDigits functionality.
     * This sends actual DTMF tones that the IVR system can recognize, rather than audio recordings.
     */
    private void playDtmfDigits(VoiceResponse.Builder responseBuilder, String digits) {
        logger.info("Sending DTMF digits using Twilio's native functionality: {}", digits);
        
        try {
            // Format the digits for Twilio's SendDigits
            // Add proper timing between digits with appropriate pauses
            StringBuilder formattedDigits = new StringBuilder();
            for (int i = 0; i < digits.length(); i++) {
                formattedDigits.append(digits.charAt(i));
                // Add a small pause between digits (w for 0.5 second pause)
                // Only add pause if it's NOT the last digit
                if (i < digits.length() - 1) {
                    formattedDigits.append("w");
                }
            }
            
            // For single digits, add extra wait time to ensure proper playback
            // Single digits may need more time for audio buffer processing
            if (digits.length() == 1) {
                formattedDigits.append("ww"); // Add 2 more 'w' for total of 1.5 seconds
                logger.info("Added extra wait time for single digit DTMF: {}", digits);
            }
            
            // Use Twilio's native SendDigits for reliable DTMF tone generation
            // This sends the actual DTMF tones rather than playing audio files
            responseBuilder.play(new com.twilio.twiml.voice.Play.Builder().digits(formattedDigits.toString()).build());
            
            // Add a longer pause after all digits to allow IVR system to process
            responseBuilder.pause(new com.twilio.twiml.voice.Pause.Builder().length(2).build());
            
            logger.info("Successfully added {} DTMF digits using SendDigits: {}", 
                      digits.length(), formattedDigits.toString());
        } catch (Exception e) {
            logger.error("Error adding DTMF digits: {}", e.getMessage(), e);
        }
    }

    /**
     * Endpoint to monitor audio streaming status
     */
    @GetMapping(value = "/api/audio/status", produces = MediaType.APPLICATION_JSON_VALUE)
    public String getStreamingStatus() {
        try {
            java.io.File baseDir = new java.io.File("audio/streams");
            if (!baseDir.exists()) {
                return "{\"status\":\"no_audio_folder\",\"chunks\":[]}";
            }

            // Count total chunk files across all date folders
            int totalChunks = 0;
            StringBuilder folderInfo = new StringBuilder("[");
            boolean first = true;

            java.io.File[] dateFolders = baseDir.listFiles(java.io.File::isDirectory);
            if (dateFolders != null) {
                for (java.io.File dateFolder : dateFolders) {
                    java.io.File[] chunks = dateFolder
                            .listFiles((dir, name) -> name.startsWith("chunk_") && name.endsWith(".wav"));
                    int chunkCount = chunks != null ? chunks.length : 0;
                    totalChunks += chunkCount;

                    if (!first)
                        folderInfo.append(",");
                    folderInfo.append("{\"date\":\"").append(dateFolder.getName())
                            .append("\",\"chunks\":").append(chunkCount).append("}");
                    first = false;
                }
            }
            folderInfo.append("]");

            return String.format("{\"status\":\"active\",\"total_chunks\":%d,\"folders\":%s,\"base_path\":\"%s\"}",
                    totalChunks, folderInfo.toString(), baseDir.getAbsolutePath());
        } catch (Exception e) {
            logger.error("Error checking streaming status: {}", e.getMessage(), e);
            return "{\"status\":\"error\",\"message\":\"" + e.getMessage() + "\"}";
        }
    }

    /**
     * Debug endpoint to check buffer status
     */
    @GetMapping(value = "/api/audio/buffers", produces = MediaType.APPLICATION_JSON_VALUE)
    public String getBufferStatus() {
        try {
            // This requires access to the AudioStreamHandler - let's add a simple status
            // check
            java.io.File baseDir = new java.io.File("audio/streams");
            String today = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            java.io.File todayDir = new java.io.File(baseDir, today);

            boolean hasTodayFolder = todayDir.exists();
            int chunkCount = 0;

            if (hasTodayFolder) {
                java.io.File[] chunks = todayDir
                        .listFiles((dir, name) -> name.startsWith("chunk_") && name.endsWith(".wav"));
                chunkCount = chunks != null ? chunks.length : 0;
            }

            return String.format("{\"today_folder_exists\":%b,\"today_chunks\":%d,\"folder_path\":\"%s\"}",
                    hasTodayFolder, chunkCount, todayDir.getAbsolutePath());
        } catch (Exception e) {
            logger.error("Error checking buffer status: {}", e.getMessage(), e);
            return "{\"error\":\"" + e.getMessage() + "\"}";
        }
    }

    /**
     * Health check endpoint for WebSocket streaming
     */
    @GetMapping(value = "/ws/audio-stream/health", produces = MediaType.APPLICATION_JSON_VALUE)
    public String getWebSocketHealth() {
        try {
            return "{\"status\":\"websocket_ready\",\"endpoint\":\"/ws/audio-stream\",\"note\":\"Use WebSocket connection, not HTTP\"}";
        } catch (Exception e) {
            logger.error("Error checking WebSocket health: {}", e.getMessage(), e);
            return "{\"status\":\"error\",\"message\":\"" + e.getMessage() + "\"}";
        }
    }

    /**
     * Health check endpoint for the application
     */
    @GetMapping(value = "/api/health", produces = MediaType.APPLICATION_JSON_VALUE)
    public String getHealth() {
        try {
            return "{\"status\":\"up\"}";
        } catch (Exception e) {
            logger.error("Error checking health: {}", e.getMessage(), e);
            return "{\"status\":\"error\",\"message\":\"" + e.getMessage() + "\"}";
        }
    }


    /**
     * Direct method to process actions from Google Live API
     * Called directly by AudioStreamHandler
     */
    public String processGoogleLiveApiAction(String streamSid, String action, String transcription) {
        logger.info("Processing Google Live API action - Stream SID: {}, Action: {}, Transcription: \"{}\"",
                streamSid, action, transcription);
        
        try {
            if (action == null || action.trim().isEmpty()) {
                logger.warn("Empty action received, ignoring");
                return "empty_action";
            }
            
            // Update call history
            List<Message> messages = chatHistoryService.loadHistory();
            messages.add(new Message("user", "Google Live API transcription: \"" + transcription + "\""));
            messages.add(new Message("ai", "Google Live API action: \"" + action + "\""));
            chatHistoryService.saveHistory(messages);
            
            // Trim the action to handle any whitespace issues
            action = action.trim();
            
            logger.info("Processing Google Live API action: \"{}\"", action);
            
            // If action is wait, just return success (no action needed)
            if ("wait".equals(action)) {
                logger.debug("Wait action determined - allowing call to continue");
                return "wait_action_processed";
            }
            
            // For non-wait actions, update the context and send instructions to Twilio
            logger.info("Non-wait action detected: \"{}\" - will update call", action);
            
            // Update call context for non-wait actions
            updateCallContext(action, callStep);
            
            // Generate TwiML based on AI-determined action
            VoiceResponse voiceResponse = generateNavigationTwiML(action);
            
            // Get current callSid to update the call
            String currentCallSid = getCurrentCallSid();
            
            if (currentCallSid != null && !currentCallSid.isEmpty() && !currentCallSid.equals("unknown")) {
                logger.info("Using CallSid: {} to update call with action: {}", currentCallSid, action);
                
                // Update the call with new TwiML
                String twimlString = voiceResponse.toXml();
                logger.debug("Generated TwiML for action '{}': {}", action, twimlString);
                
                try {
                    Call.updater(currentCallSid)
                            .setTwiml(new Twiml(twimlString))
                            .update();
                    
                    logger.info("Successfully updated call {} with action: {}", currentCallSid, action);
                    return "action_processed_successfully";
                } catch (Exception e) {
                    logger.error("Error updating call {} with action {}: {}", currentCallSid, action, e.getMessage());
                    return "error_updating_call";
                }
            } else {
                logger.warn("Invalid CallSid: '{}'. Cannot update call with action: {}", currentCallSid, action);
                return "invalid_call_sid";
            }
            
        } catch (Exception e) {
            logger.error("Error processing Google Live API action: {}", e.getMessage(), e);
            return "error_processing_action";
        }
    }
}