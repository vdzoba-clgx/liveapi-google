package com.cotality.ivra.bots_service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/**
 * Service for managing Google Live API interactions and goal storage
 */
@Service
public class GoogleLiveApiService {

    private static final Logger logger = LoggerFactory.getLogger(GoogleLiveApiService.class);

    @Value("${google_api_key}")
    private String googleApiKey;

    // Store goals per stream/call
    private final Map<String, String> streamGoals = new ConcurrentHashMap<>();
    
    // Store prompt template
    private String promptTemplate;

    /**
     * Set the goal for a specific stream/call
     */
    public void setGoalForStream(String streamSid, String goal) {
        streamGoals.put(streamSid, goal);
        logger.info("Set goal '{}' for stream {}", goal, streamSid);
    }

    /**
     * Get the goal for a specific stream/call
     */
    public String getGoalForStream(String streamSid) {
        return streamGoals.get(streamSid);
    }

    /**
     * Remove goal when stream/call ends
     */
    public void removeGoalForStream(String streamSid) {
        String goal = streamGoals.remove(streamSid);
        if (goal != null) {
            logger.info("Removed goal '{}' for stream {}", goal, streamSid);
        }
    }

    /**
     * Generate system instruction for Google Live API
     */
    public String generateSystemInstruction(String goal) throws IOException {
        if (promptTemplate == null) {
            loadPromptTemplate();
        }
        
        // Replace placeholder with actual goal
        String instruction = promptTemplate.replace("{GOAL_DESCRIPTION}", goal);
        
        logger.debug("Generated system instruction for goal '{}': {}", goal, instruction);
        return instruction;
    }

    /**
     * Generate Google Live API setup message JSON
     */
    public String generateGoogleLiveApiConfig(String goal) throws IOException {
        // Generate system instruction for the goal
        String systemInstruction = generateSystemInstruction(goal);
        
        // Create Google Live API setup message with system instruction
        String config = String.format("""
            {
              "setup": {
                "model": "models/gemini-live-2.5-flash-preview-native-audio",
                "systemInstruction": {
                  "parts": [
                    {
                      "text": "%s"
                    }
                  ]
                }
              }
            }""", systemInstruction.replace("\"", "\\\""));
            
        logger.info("Generated Google Live API setup message for goal '{}'. Message length: {} characters", goal, config.length());
        logger.debug("Full setup message: {}", config);
        return config;
    }

    /**
     * Load prompt template from resources
     */
    private void loadPromptTemplate() throws IOException {
        try {
            ClassPathResource resource = new ClassPathResource("prompt_template.txt");
            promptTemplate = resource.getContentAsString(StandardCharsets.UTF_8);
            logger.info("Loaded prompt template: {} characters", promptTemplate.length());
        } catch (IOException e) {
            logger.error("Failed to load prompt template: {}", e.getMessage(), e);
            throw e;
        }
    }

    /**
     * Get Google API key
     */
    public String getGoogleApiKey() {
        return googleApiKey;
    }
}
