package com.cotality.ivra.bots_service.IVR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.google.gson.JsonObject;
import com.google.gson.JsonElement;
import com.cotality.ivra.bots_service.MenuLoader;
import com.cotality.ivra.bots_service.NavigationStep;
import com.google.gson.JsonArray;

/**
 * Service class responsible for finding navigation paths through the IVR menu structure.
 * Handles the logic for traversing the menu hierarchy to locate specific goals.
 */
@Service
public class IvrNavigationService {
    private JsonObject ivrMenu;
    
    @Autowired
    MenuLoader menuLoader; // Made package-private for testing
    
    /**
     * Initialize the service with IVR menu data
     */
    public void initializeMenu() throws IOException {
        if (ivrMenu == null) {
            ivrMenu = menuLoader.loadIvrMenu();
        }
    }      
    
    /**
     * Recursively search for a goal in the menu structure
     * @param menuOption the current menu option to search
     * @param targetGoal the goal to find
     * @param keyToPress the key that needs to be pressed to reach this menu option
     * @param currentPath the current navigation path
     * @return List of NavigationStep objects if goal is found, null otherwise
     */    private List<NavigationStep> searchForGoal(JsonObject menuOption, String targetGoal, String keyToPress, List<NavigationStep> currentPath) {
        if (menuOption == null) {
            return null;
        }        // Check if this option has a direct goal match
        if (menuOption.has("goal") && menuOption.get("goal").getAsString().equals(targetGoal)) {
            // Found the goal! Add the navigation step to press the key, then the final goal step
            List<NavigationStep> completePath = new ArrayList<>(currentPath);
            String description = menuOption.has("description") ? menuOption.get("description").getAsString() : null;
            
            // If no description in menu option, try to get it from goals.json
            if (description == null || "Unknown".equals(description)) {
                try {
                    JsonObject goals = menuLoader.loadGoals();
                    if (goals.has(targetGoal)) {
                        description = goals.get(targetGoal).getAsString();
                    }
                } catch (IOException e) {
                    // Fallback to unknown if goals can't be loaded
                }
                if (description == null) {
                    description = "Unknown";
                }
            }
            
            String prompt = menuOption.has("prompt") ? menuOption.get("prompt").getAsString() : description;
            String action = menuOption.has("action") ? menuOption.get("action").getAsString() : "collect.data";
            
            // Add the navigation step to press the key to reach this goal
            if (keyToPress != null && !keyToPress.isEmpty()) {
                // Find the parent menu prompt by looking at the last step in currentPath
                String parentPrompt = "Menu selection";
                if (!currentPath.isEmpty()) {
                    parentPrompt = currentPath.get(currentPath.size() - 1).getPrompt();
                }
                completePath.add(new NavigationStep(
                    "Navigate to " + description,
                    parentPrompt,
                    "press." + keyToPress
                ));
            }
            
            // Add the final step with the goal action
            completePath.add(new NavigationStep(
                description,
                prompt,
                action
            ));
            return completePath;
        }// If this option has a submenu, search it
        if (menuOption.has("subMenu")) {
            // First add step to navigate to this menu
            List<NavigationStep> pathWithNavigation = new ArrayList<>(currentPath);
            String description = menuOption.has("description") ? menuOption.get("description").getAsString() : "Unknown";
            
            // Find the parent menu prompt
            String parentPrompt = "Menu selection";
            if (!currentPath.isEmpty()) {
                parentPrompt = currentPath.get(currentPath.size() - 1).getPrompt();
            }
            
            pathWithNavigation.add(new NavigationStep(
                "Navigate to " + description,
                parentPrompt,
                "press." + keyToPress
            ));
            
            JsonObject subMenu = menuOption.getAsJsonObject("subMenu");
            if (subMenu != null) {
                for (String subKey : subMenu.keySet()) {
                    JsonElement subElement = subMenu.get(subKey);
                    if (subElement != null && subElement.isJsonObject()) {
                        JsonObject subOption = subElement.getAsJsonObject();
                        List<NavigationStep> foundPath = searchForGoal(subOption, targetGoal, subKey, pathWithNavigation);
                        if (foundPath != null) {
                            return foundPath;
                        }
                    }
                }
            }
        }        // If this option has subOptions, search them
        if (menuOption.has("subOptions")) {
            JsonObject subOptions = menuOption.getAsJsonObject("subOptions");
            if (subOptions != null) {
                // Create a modified path that includes this menu item's prompt as the last context
                List<NavigationStep> pathWithContext = new ArrayList<>(currentPath);
                String thisMenuPrompt = menuOption.has("prompt") ? menuOption.get("prompt").getAsString() : "Menu selection";
                
                // Add a temporary context step that will be used as parent prompt for goals in subOptions
                pathWithContext.add(new NavigationStep(
                    "Menu context",
                    thisMenuPrompt,
                    "context"
                ));
                
                for (String subKey : subOptions.keySet()) {
                    JsonElement subElement = subOptions.get(subKey);
                    if (subElement != null && subElement.isJsonObject()) {
                        JsonObject subOption = subElement.getAsJsonObject();
                        List<NavigationStep> foundPath = searchForGoal(subOption, targetGoal, subKey, pathWithContext);
                        if (foundPath != null) {
                            // Remove the temporary context step before returning
                            for (int i = foundPath.size() - 1; i >= 0; i--) {
                                if (foundPath.get(i).getAction().equals("context")) {
                                    foundPath.remove(i);
                                    break;
                                }
                            }
                            return foundPath;
                        }
                    }
                }
            }
        }
        
        return null; // Goal not found in this branch
    }
      /**
     * Generate navigation path to reach a specific goal using configurable flow system
     * @param targetGoal the goal to reach (e.g., "account_balance_inquiry")
     * @return List of NavigationStep objects representing the path, or null if goal not found
     */
    public List<NavigationStep> generateNavigationPathWithConfigurableFlow(String targetGoal) throws IOException {
        initializeMenu();
        
        // Validate the IVR menu structure
        JsonObject ivrSystem = ivrMenu.getAsJsonObject("ivrSystem");
        if (ivrSystem == null) {
            throw new IOException("Invalid IVR menu structure: missing 'ivrSystem'");
        }
        
        List<NavigationStep> path = new ArrayList<>();
        
        // Check if flow configuration exists, use it if available
        if (ivrSystem.has("flowConfiguration")) {
            JsonObject flowConfig = ivrSystem.getAsJsonObject("flowConfiguration");
            JsonArray sequence = flowConfig.getAsJsonArray("sequence");
            JsonObject stepDefinitions = ivrSystem.getAsJsonObject("stepDefinitions");
              if (sequence != null && stepDefinitions != null) {
                // Process steps according to configured flow
                for (int i = 0; i < sequence.size(); i++) {
                    JsonObject stepConfig = sequence.get(i).getAsJsonObject();
                    String stepId = stepConfig.get("stepId").getAsString();
                    boolean required = stepConfig.has("required") ? stepConfig.get("required").getAsBoolean() : true;                    // Only process required steps or all steps if not specified
                    if (required && stepDefinitions.has(stepId)) {
                        JsonObject stepDef = stepDefinitions.getAsJsonObject(stepId);
                        String prompt = stepDef.has("prompt") ? stepDef.get("prompt").getAsString() : "";
                        String action;
                        
                        // Handle dynamic action resolution for navigation menus
                        if (!stepDef.has("action")) {
                            if ("mainMenu".equals(stepId) || "navigation".equals(stepDef.get("type").getAsString())) {
                                // For navigation steps without explicit action, determine dynamically based on goal
                                action = findNavigationActionForGoal(stepDef, targetGoal);
                            } else {
                                throw new IOException("Invalid IVR menu structure: step '" + stepId + "' missing 'action' field");
                            }
                        } else {
                            action = stepDef.get("action").getAsString();
                        }
                        
                        String description = stepConfig.has("description") ? stepConfig.get("description").getAsString() : stepId;
                        
                        path.add(new NavigationStep(description, prompt, action));
                          // If this is the main menu step, search for the target goal
                        if ("mainMenu".equals(stepId) || "navigation".equals(stepDef.get("type").getAsString())) {
                            if (stepDef.has("options")) {
                                JsonObject options = stepDef.getAsJsonObject("options");
                                for (String optionKey : options.keySet()) {
                                    JsonObject option = options.getAsJsonObject(optionKey);
                                    // For mainMenu navigation, we've already added the navigation step above,
                                    // so we need to search without adding another navigation step for the same level
                                    List<NavigationStep> foundPath = searchForGoalWithoutInitialNavigation(option, targetGoal, optionKey, path);
                                    if (foundPath != null) {
                                        return foundPath;
                                    }
                                }
                            }
                        }
                    }
                }
                
            }            
        }

        return path; // Return the configured flow path
    }
    
      /**
     * Primary method to generate navigation path - uses configurable flow system
     * @param targetGoal the goal to reach (e.g., "account_balance_inquiry")
     * @return List of NavigationStep objects representing the path, or null if goal not found
     */
    public List<NavigationStep> generateNavigationPath(String targetGoal) throws IOException {
        return generateNavigationPathWithConfigurableFlow(targetGoal);
    }
      /**
     * Advanced method to create completely custom flows with different step types
     * This allows different banks to define entirely different IVR flows
     * @param flowName the name of the flow configuration to use
     * @param targetGoal the goal to reach
     * @return List of NavigationStep objects representing the path
     */
    public List<NavigationStep> generateCustomFlow(String flowName, String targetGoal) throws IOException {
        initializeMenu();
        
        JsonObject ivrSystem = ivrMenu.getAsJsonObject("ivrSystem");
        if (ivrSystem == null) {
            throw new IOException("Invalid IVR menu structure: missing 'ivrSystem'");
        }
        
        // Look for named flow configurations (e.g., "bofa_flow", "chase_flow", etc.)
        if (ivrSystem.has("flowConfigurations")) {
            JsonObject flowConfigs = ivrSystem.getAsJsonObject("flowConfigurations");
            if (flowConfigs.has(flowName)) {
                JsonObject namedFlow = flowConfigs.getAsJsonObject(flowName);
                // Process this specific flow configuration
                return processCustomFlowConfiguration(namedFlow, targetGoal);
            }
        }
        
        // Fallback to default flow
        return generateNavigationPathWithConfigurableFlow(targetGoal);
    }
    
    private List<NavigationStep> processCustomFlowConfiguration(JsonObject flowConfig, String targetGoal) {
        // Implementation for processing custom flow configurations
        // This could support conditional steps, branching, etc.
        return new ArrayList<>(); // Placeholder for now
    }
    
    /**
     * Find the navigation action (press.X) needed to reach a specific goal from a navigation menu.
     * This analyzes the menu options to determine which key to press.
     */
    public String findNavigationActionForGoal(JsonObject navigationMenu, String targetGoal) {
        if (!navigationMenu.has("options")) {
            return "wait"; // Fallback if no options available
        }
        JsonObject options = navigationMenu.getAsJsonObject("options");
        // Search through each option to find which one leads to the target goal
        for (String optionKey : options.keySet()) {
            JsonElement element = options.get(optionKey);
            if (element.isJsonObject()) {
                JsonObject option = element.getAsJsonObject();
                // Check if this option contains the target goal
                if (containsGoalInOption(option, targetGoal)) {
                    return "press." + optionKey;
                }
            }
        }
        // If no specific option found, default to wait
        return "wait";
    }
    
    /**
     * Recursively check if a menu option contains the target goal.
     */
    private boolean containsGoalInOption(JsonObject option, String targetGoal) {
        // Direct goal check
        if (option.has("goal") && option.get("goal").getAsString().equals(targetGoal)) {
            return true;
        }
        
        // Check in subMenu
        if (option.has("subMenu")) {
            JsonObject subMenu = option.getAsJsonObject("subMenu");
            for (String subKey : subMenu.keySet()) {
                JsonElement subElement = subMenu.get(subKey);
                if (subElement.isJsonObject()) {
                    if (containsGoalInOption(subElement.getAsJsonObject(), targetGoal)) {
                        return true;
                    }
                }
            }
        }
        
        // Check in subOptions
        if (option.has("subOptions")) {
            JsonObject subOptions = option.getAsJsonObject("subOptions");
            for (String subKey : subOptions.keySet()) {
                JsonElement subElement = subOptions.get(subKey);
                if (subElement.isJsonObject()) {
                    if (containsGoalInOption(subElement.getAsJsonObject(), targetGoal)) {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }
    
    /**
     * Search for a goal without adding an initial navigation step (used when already at correct menu level)
     * @param menuOption the current menu option to search
     * @param targetGoal the goal to find
     * @param keyToPress the key that would be pressed to reach this menu option
     * @param currentPath the current navigation path
     * @return List of NavigationStep objects if goal is found, null otherwise
     */
    private List<NavigationStep> searchForGoalWithoutInitialNavigation(JsonObject menuOption, String targetGoal, String keyToPress, List<NavigationStep> currentPath) {
        if (menuOption == null) {
            return null;
        }
        
        // Check if this option has a direct goal match
        if (menuOption.has("goal") && menuOption.get("goal").getAsString().equals(targetGoal)) {
            // Found the goal! Don't add navigation step since we're already at the right menu level
            List<NavigationStep> completePath = new ArrayList<>(currentPath);
            String description = menuOption.has("description") ? menuOption.get("description").getAsString() : null;
            
            // If no description in menu option, try to get it from goals.json
            if (description == null || "Unknown".equals(description)) {
                try {
                    JsonObject goals = menuLoader.loadGoals();
                    if (goals.has(targetGoal)) {
                        description = goals.get(targetGoal).getAsString();
                    }
                } catch (IOException e) {
                    // Fallback to unknown if goals can't be loaded
                }
                if (description == null) {
                    description = "Unknown";
                }
            }
            
            String prompt = menuOption.has("prompt") ? menuOption.get("prompt").getAsString() : description;
            String action = menuOption.has("action") ? menuOption.get("action").getAsString() : "collect.data";
            
            // Add the final step with the goal action
            completePath.add(new NavigationStep(
                description,
                prompt,
                action
            ));
            return completePath;
        }
          // If this option has a submenu, search it WITHOUT adding another navigation step
        // (since we're already at the correct menu level when this method is called)
        if (menuOption.has("subMenu")) {
            JsonObject subMenu = menuOption.getAsJsonObject("subMenu");
            if (subMenu != null) {
                for (String subKey : subMenu.keySet()) {
                    JsonElement subElement = subMenu.get(subKey);
                    if (subElement != null && subElement.isJsonObject()) {
                        JsonObject subOption = subElement.getAsJsonObject();
                        // Search directly in submenu without adding navigation step since we're already there
                        List<NavigationStep> foundPath = searchForGoal(subOption, targetGoal, subKey, currentPath);
                        if (foundPath != null) {
                            return foundPath;
                        }
                    }
                }
            }
        }
        
        // If this option has subOptions, search them
        if (menuOption.has("subOptions")) {
            JsonObject subOptions = menuOption.getAsJsonObject("subOptions");
            if (subOptions != null) {
                // Create a modified path that includes this menu item's prompt as the last context
                List<NavigationStep> pathWithContext = new ArrayList<>(currentPath);
                String thisMenuPrompt = menuOption.has("prompt") ? menuOption.get("prompt").getAsString() : "Menu selection";
                
                // Add a temporary context step that will be used as parent prompt for goals in subOptions
                pathWithContext.add(new NavigationStep(
                    "Menu context",
                    thisMenuPrompt,
                    "context"
                ));
                
                for (String subKey : subOptions.keySet()) {
                    JsonElement subElement = subOptions.get(subKey);
                    if (subElement != null && subElement.isJsonObject()) {
                        JsonObject subOption = subElement.getAsJsonObject();
                        List<NavigationStep> foundPath = searchForGoal(subOption, targetGoal, subKey, pathWithContext);
                        if (foundPath != null) {
                            // Remove the temporary context step before returning
                            for (int i = foundPath.size() - 1; i >= 0; i--) {
                                if (foundPath.get(i).getAction().equals("context")) {
                                    foundPath.remove(i);
                                    break;
                                }
                            }
                            return foundPath;
                        }
                    }
                }
            }
        }
        
        return null; // Goal not found in this branch
    }
      /**
     * Get the correct action for a given prompt in the context of reaching a specific goal.
     * This method provides a unified action resolution that can be used by both navigation path generation
     * and action resolvers to ensure consistency.
     * 
     * @param prompt the IVR prompt text
     * @param description the step description (context)
     * @param targetGoal the goal being pursued
     * @return the correct action (e.g., "press.1", "wait", "collect.data") or null if not found
     */    public String resolveActionForPromptAndGoal(String prompt, String description, String targetGoal) {
        try {
            initializeMenu();
            
            if (prompt == null || targetGoal == null) {
                return null;
            }
            
            // Get the navigation path for this goal
            List<NavigationStep> navigationPath = generateNavigationPath(targetGoal);
            if (navigationPath == null || navigationPath.isEmpty()) {
                return null;
            }
            
            // Find the step that matches this prompt
            for (NavigationStep step : navigationPath) {
                if (step.getPrompt() != null && step.getPrompt().equals(prompt)) {
                    return step.getAction();
                }
                
                // Also try matching by description if provided
                if (description != null && step.getDescription() != null && 
                    step.getDescription().equals(description)) {
                    return step.getAction();
                }
            }
              // If we couldn't find an exact match, try to determine the action based on menu structure
            JsonObject ivrSystem = ivrMenu.getAsJsonObject("ivrSystem");
            if (ivrSystem != null && ivrSystem.has("stepDefinitions")) {
                JsonObject stepDefinitions = ivrSystem.getAsJsonObject("stepDefinitions");
                for (String stepId : stepDefinitions.keySet()) {
                    JsonObject stepDef = stepDefinitions.getAsJsonObject(stepId);
                    if (stepDef.has("prompt") && prompt.equals(stepDef.get("prompt").getAsString())) {
                        // If this is a navigation menu, determine the correct action for the target goal
                        if (stepDef.has("options") && !stepDef.has("action")) {
                            String action = findNavigationActionForGoal(stepDef, targetGoal);
                            return action;
                        }
                        // If this step has a direct action, return it
                        if (stepDef.has("action")) {
                            String action = stepDef.get("action").getAsString();
                            return action;
                        }
                    }
                }
            }
            
            return null;
              } catch (Exception e) {
            // Return null on any error to allow fallback mechanisms
            return null;
        }
    }
}
