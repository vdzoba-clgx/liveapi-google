package com.cotality.ivra.bots_service.stt;

public class TranscriptionResult {
    private final String transcription;
    private final long processingTimeMs;
    private final double audioDurationSeconds;
    private final boolean success;
    private final String errorMessage;
    private final long timestamp;

    // Constructor for successful transcription
    public TranscriptionResult(String transcription, long processingTimeMs, double audioDurationSeconds,
            boolean success) {
        this.transcription = transcription;
        this.processingTimeMs = processingTimeMs;
        this.audioDurationSeconds = audioDurationSeconds;
        this.success = success;
        this.errorMessage = null;
        this.timestamp = System.currentTimeMillis();
    }

    // Constructor for failed transcription
    public TranscriptionResult(String transcription, long processingTimeMs, double audioDurationSeconds,
            boolean success, String errorMessage) {
        this.transcription = transcription;
        this.processingTimeMs = processingTimeMs;
        this.audioDurationSeconds = audioDurationSeconds;
        this.success = success;
        this.errorMessage = errorMessage;
        this.timestamp = System.currentTimeMillis();
    }

    public String getTranscription() {
        return transcription;
    }

    public long getProcessingTimeMs() {
        return processingTimeMs;
    }

    public double getAudioDurationSeconds() {
        return audioDurationSeconds;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public double getRealTimeFactor() {
        return audioDurationSeconds > 0 ? (processingTimeMs / 1000.0) / audioDurationSeconds : 0;
    }

    @Override
    public String toString() {
        return String.format(
                "TranscriptionResult{transcription='%s', processingTime=%dms, audioDuration=%.2fs, RTF=%.3f, success=%s%s}",
                transcription, processingTimeMs, audioDurationSeconds, getRealTimeFactor(), success,
                errorMessage != null ? ", error='" + errorMessage + "'" : "");
    }
}
