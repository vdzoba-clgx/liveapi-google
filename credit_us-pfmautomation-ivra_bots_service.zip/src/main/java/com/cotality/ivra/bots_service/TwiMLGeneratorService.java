package com.cotality.ivra.bots_service;

import com.twilio.twiml.TwiMLException;
import com.twilio.twiml.VoiceResponse;
import com.twilio.twiml.voice.Gather;
import com.twilio.twiml.voice.Say;
import com.twilio.twiml.voice.Hangup;
import com.twilio.twiml.voice.Redirect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Service for generating TwiML responses for the Twilio IVR application
 */
@Service
public class TwiMLGeneratorService {

    private static final Logger logger = LoggerFactory.getLogger(TwiMLGeneratorService.class);    /**
     * Generate TwiML to capture user speech input
     * 
     * @return TwiML XML string
     */
    public String generateSpeechInputTwiML() {
        try {
            String welcomeMessage = "Welcome to the IVR Service. Please say something to begin.";
            // Build gather with speech input, configured for the IVR application
            Gather gather = new Gather.Builder()
                    .inputs(Gather.Input.SPEECH)
                    .language(Gather.Language.EN_US)
                    .timeout(5) // Give the user a bit more time to speak
                    .action("/twiml/ivr-handle-speech")
                    .method(com.twilio.http.HttpMethod.POST)
                    .say(new Say.Builder(welcomeMessage).build())
                    .build();
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(gather)
                    .say(new Say.Builder("I didn't hear anything. Please try again.").build())
                    .redirect(new Redirect.Builder("/twiml/ivr-main-menu").build())
                    .build();

            return voiceResponse.toXml();
        } catch (TwiMLException e) {
            logger.error("Error generating speech input TwiML: {}", e.getMessage(), e);
            return generateErrorTwiML();
        }
    }

    /**
     * Generate TwiML for error handling
     * 
     * @return TwiML XML string
     */
    public String generateErrorTwiML() {
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .say(new Say.Builder("Sorry, an error occurred. Please try your call again later.").build())
                    .hangup(new Hangup.Builder().build())
                    .build();

            return voiceResponse.toXml();
        } catch (TwiMLException e) {
            logger.error("Error generating error TwiML: {}", e.getMessage(), e);
            // Fallback to simple string if even the error handler fails
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Say>System error occurred.</Say><Hangup/></Response>";
        }
    }

    /**
     * Generate TwiML to capture user speech input specifically for the IVR workflow
     * 
     * @return TwiML XML string
     */
    public String generateIvrSpeechInputTwiML() {
        try {
            String welcomeMessage = "Welcome to the IVR Voice Assistant. Please state your request or goal.";
            // Build gather with speech input, configured for IVR application
            Gather gather = new Gather.Builder()
                    .inputs(Gather.Input.SPEECH)
                    .language(Gather.Language.EN_US)
                    .timeout(5) // Give the user a bit more time to speak
                    .action("/twiml/ivr-handle-speech")
                    .method(com.twilio.http.HttpMethod.POST)
                    .say(new Say.Builder(welcomeMessage).build())
                    .build();
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(gather)
                    .say(new Say.Builder("I didn't hear anything. Please try again.").build())
                    .redirect(new Redirect.Builder("/twiml/ivr-speech-menu").build())
                    .build();

            return voiceResponse.toXml();
        } catch (TwiMLException e) {
            logger.error("Error generating IVR speech input TwiML: {}", e.getMessage(), e);
            return generateErrorTwiML();
        }
    }

    /**
     * Generate TwiML to respond to user speech in the IVR context
     * This can be enhanced to interpret user goals and provide appropriate
     * navigation
     * 
     * @param speechResult The transcribed speech from Twilio
     * @return TwiML XML string
     */
    public String generateIvrSpeechResponseTwiML(String speechResult) {
        try {
            String responseMessage;

            if (speechResult == null || speechResult.trim().isEmpty()) {
                responseMessage = "I didn't hear anything. Please try again.";
            } else {
                responseMessage = "I heard you say: " + speechResult + ". Processing your request.";
                // This is where you could add logic to interpret the speech as a goal
                // and generate appropriate navigation steps
            }

            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .say(new Say.Builder(responseMessage).build())
                    .redirect(new Redirect.Builder("/twiml/ivr-speech-menu").build())
                    .build();

            return voiceResponse.toXml();
        } catch (TwiMLException e) {
            logger.error("Error generating IVR speech response TwiML: {}", e.getMessage(), e);
            return generateErrorTwiML();
        }
    }

    /**
     * Generate TwiML for the main menu of the IVR system
     * 
     * @return TwiML XML string
     */
    public String generateMainMenuTwiML() {
        try {
            String welcomeMessage = "Welcome to the Bank of America automated phone system. "
                    + "Please listen carefully as our menu options have changed.";

            // Build gather for main menu options
            Gather gather = new Gather.Builder()
                    .numDigits(1)
                    .timeout(5)
                    .action("/twiml/handle-input")
                    .method(com.twilio.http.HttpMethod.POST)
                    .say(new Say.Builder(welcomeMessage).build())
                    .build();

            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(gather)
                    .say(new Say.Builder("We didn't receive any input. Goodbye.").build())
                    .hangup(new Hangup.Builder().build())
                    .build();

            return voiceResponse.toXml();
        } catch (TwiMLException e) {
            logger.error("Error generating main menu TwiML: {}", e.getMessage(), e);
            return generateErrorTwiML();
        }
    }    /**
     * Generate TwiML for handling input selections
     * 
     * @param digits The digits entered by the user
     * @return TwiML XML string
     */
    public String generateInputHandlerTwiML(String digits) {
        try {
            String responseMessage;
            switch (digits) {
                case "1":
                    responseMessage = "You selected option 1, Banking.";
                    break;
                case "2":
                    responseMessage = "You selected option 2, Credit Cards.";
                    break;
                case "3":
                    responseMessage = "You selected option 3, Loans.";
                    break;
                case "4":
                    responseMessage = "You selected option 4, Customer Service.";
                    break;
                default:
                    responseMessage = "Invalid selection. Please try again.";
                    break;
            }

            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .say(new Say.Builder(responseMessage).build())
                    .redirect(new Redirect.Builder("/twiml/ivr-main-menu").build())
                    .build();

            return voiceResponse.toXml();
        } catch (TwiMLException e) {
            logger.error("Error generating input handler TwiML: {}", e.getMessage(), e);
            return generateErrorTwiML();
        }
    }    /**
     * Generate TwiML for submenu input handling
     * 
     * @param parentDigit The digit that led to this submenu
     * @param digits      The digits entered by the user in this submenu
     * @return TwiML XML string
     */
    public String generateSubMenuInputHandlerTwiML(String parentDigit, String digits) {
        try {
            String responseMessage = "You selected submenu " + parentDigit + ", option " + digits + ".";

            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .say(new Say.Builder(responseMessage).build())
                    .redirect(new Redirect.Builder("/twiml/ivr-main-menu").build())
                    .build();

            return voiceResponse.toXml();
        } catch (TwiMLException e) {
            logger.error("Error generating submenu input handler TwiML: {}", e.getMessage(), e);
            return generateErrorTwiML();
        }
    }

    /**
     * Generate TwiML for when a goal is achieved
     * 
     * @param goalId The ID of the achieved goal
     * @return TwiML XML string
     */
    public String generateGoalAchievedTwiML(String goalId) {
        try {
            String goalMessage = "Your request to " + goalId.replace("_", " ") + " has been processed successfully.";

            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .say(new Say.Builder(goalMessage).build())
                    .say(new Say.Builder("Thank you for using our automated system. Goodbye.").build())
                    .hangup(new Hangup.Builder().build())
                    .build();

            return voiceResponse.toXml();
        } catch (TwiMLException e) {
            logger.error("Error generating goal achieved TwiML: {}", e.getMessage(), e);
            return generateErrorTwiML();
        }
    }    /**
     * Generate a complete IVR Application TwiML structure, combining all
     * components
     * 
     * @return Map with all TwiML components and metadata
     */
    public Map<String, Object> generateIvrAppTwiML() {
        Map<String, Object> result = new HashMap<>();

        try {
            // Generate main menu/input speech TwiML
            String mainMenuTwiML = generateSpeechInputTwiML();
            result.put("mainMenuTwiML", mainMenuTwiML);

            // Generate error TwiML
            String errorTwiML = generateErrorTwiML();
            result.put("errorTwiML", errorTwiML);

            // Add metadata
            result.put("generatedAt", java.time.Instant.now().toString());
            result.put("description", "TwiML generated for IVR Application");

            // Add webhook endpoints
            Map<String, String> webhooks = new HashMap<>();
            webhooks.put("ivrMainMenu", "/twiml/ivr-main-menu");
            webhooks.put("handleSpeech", "/twiml/handle-speech");
            webhooks.put("errorHandler", "/twiml/error");
            result.put("webhookEndpoints", webhooks);

            return result;
        } catch (Exception e) {
            logger.error("Error generating IVR App TwiML: {}", e.getMessage(), e);
            result.put("error", "Failed to generate IVR App TwiML: " + e.getMessage());
            return result;
        }
    }

    /**
     * Generate TwiML for responding to user speech input
     * This is a wrapper for the IVR speech response to maintain backwards compatibility
     * 
     * @param speechResult The transcribed speech from Twilio
     * @return TwiML XML string
     */
    public String generateEchoResponseTwiML(String speechResult) {
        // Delegate to the IVR speech response generator
        return generateIvrSpeechResponseTwiML(speechResult);
    }
}
