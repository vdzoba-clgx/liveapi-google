package com.cotality.ivra.bots_service.IVR;

import java.util.List;
import java.util.function.Consumer;
import org.springframework.stereotype.Service;

import com.cotality.ivra.bots_service.NavigationStep;

/**
 * Service class responsible for executing IVR call simulations.
 * Handles the step-by-step execution of navigation sequences with realistic
 * timing and user interaction.
 */
@Service
public class IvrSimulationService {
    /**
     * Execute a complete IVR simulation based on the provided navigation path for
     * web interface
     * 
     * @param goal           the target goal being pursued
     * @param navigationPath the sequence of steps to execute
     * @param outputConsumer callback function to handle output messages
     */
    public void executeIvrSimulationForWeb(String goal, List<NavigationStep> navigationPath,
            Consumer<String> outputConsumer) {
        executeIvrSimulationForWeb(goal, navigationPath, outputConsumer, null);
    }

    /**
     * Execute a complete IVR simulation based on the provided navigation path for
     * web interface with action resolver
     * 
     * @param goal           the target goal being pursued
     * @param navigationPath the sequence of steps to execute
     * @param outputConsumer callback function to handle output messages
     * @param actionResolver the action resolver to use for dynamic action
     *                       determination (can be null for static execution)
     */
    public void executeIvrSimulationForWeb(String goal, List<NavigationStep> navigationPath,
            Consumer<String> outputConsumer, ActionResolver actionResolver) {
        String goalTitle = "Bank of America " + goal.replace("_", " ").toUpperCase() + " Sequence";
        String goalDescription = "Auto-generated step-by-step IVR navigation sequence to reach " + goal;

        // Display resolver information if provided
        String resolverInfo = actionResolver != null ? " (using " + actionResolver.getResolverName() + ")"
                : " (static execution)";

        outputConsumer.accept("=".repeat(60));
        outputConsumer.accept("STARTING IVR SIMULATION");
        outputConsumer.accept("=".repeat(60));
        outputConsumer.accept("Goal: " + goalTitle);
        outputConsumer.accept("Description: " + goalDescription + resolverInfo);
        outputConsumer.accept("Total Steps: " + navigationPath.size());
        outputConsumer.accept("=".repeat(60));
        outputConsumer.accept("");
        outputConsumer.accept("📞 Dialing Bank of America...");
        sleep(1000);
        int currentStepIndex = 0;
        for (NavigationStep step : navigationPath) {
            currentStepIndex++;
            if (!executeStepForWeb(step, currentStepIndex, outputConsumer, actionResolver, goal)) {
                outputConsumer.accept("");
                outputConsumer.accept("❌ IVR simulation terminated due to mismatch or error.");
                outputConsumer.accept("🔚 IVR simulation completed with FAILURE.");
                return;
            }

            if (currentStepIndex == navigationPath.size()) {
                outputConsumer.accept("");
                outputConsumer.accept("✅ GOAL ACHIEVED SUCCESSFULLY!");
                outputConsumer.accept("=".repeat(60));
                break;
            }
        }

        outputConsumer.accept("");
        outputConsumer.accept("🔚 IVR simulation completed.");
    }

    /*
     * Execute a single step in the IVR simulation for web interface with action
     * resolver
     * 
     * @param step the navigation step to execute
     * 
     * @param stepNumber the current step number
     * 
     * @param outputConsumer callback function to handle output messages
     * 
     * @param actionResolver the action resolver to use for dynamic action
     * determination (can be null)
     * 
     * @param goal the target goal being pursued
     * 
     * @return true if the step executed successfully, false otherwise
     */
    private boolean executeStepForWeb(NavigationStep step, int stepNumber, Consumer<String> outputConsumer,
            ActionResolver actionResolver, String goal) {
        outputConsumer.accept("");
        outputConsumer.accept("-".repeat(50));
        String description = step.getDescription() != null ? step.getDescription() : "Unknown step";
        String prompt = step.getPrompt() != null ? step.getPrompt() : "No prompt available";
        String action = step.getAction() != null ? step.getAction() : null;
        // Store the expected action from the navigation path
        String expectedAction = action;

        // Use action resolver to determine action if provided
        if (actionResolver != null) {
            try {
                String resolvedAction = actionResolver.resolveAction(prompt, description, goal);
                if (resolvedAction != null && !resolvedAction.trim().isEmpty()) {
                    outputConsumer.accept(
                            "🤖 Action resolved by " + actionResolver.getResolverName() + ": " + resolvedAction);
                    // VALIDATION: Compare expected vs actual action
                    if (expectedAction != null && !expectedAction.trim().isEmpty()) {
                        if (!expectedAction.equals(resolvedAction)) {
                            String errorMessage = String.format(
                                    "🚨 MISMATCH DETECTED: Expected action '%s' but actual menu requires '%s' for step: %s",
                                    expectedAction, resolvedAction, description);
                            outputConsumer.accept(errorMessage);
                            outputConsumer.accept(
                                    "❌ GOAL EXECUTION FAILED: Mismatch between expected and actual menu structure");
                            outputConsumer.accept("=".repeat(60));
                            return false; // Return false to indicate failure without throwing exception
                        } else {
                            outputConsumer.accept("✅ Action validation passed: Expected and actual actions match ("
                                    + expectedAction + ")");
                        }
                    }

                    action = resolvedAction;
                } else {
                    outputConsumer
                            .accept("❌ Action resolver returned null or empty action for prompt: '" + prompt + "'");
                    outputConsumer.accept("❌ GOAL EXECUTION FAILED: Unable to resolve action");
                    outputConsumer.accept("=".repeat(60));
                    return false;
                }
            } catch (Exception e) {
                outputConsumer.accept("❌ Action resolver failed: " + e.getMessage());
                outputConsumer.accept("❌ GOAL EXECUTION FAILED: Action resolution error");
                outputConsumer.accept("=".repeat(60));
                return false;
            }
        } else if (action == null || action.trim().isEmpty()) {
            // No action resolver and no predefined action - this is an error
            outputConsumer.accept("❌ No action resolver provided and no predefined action available");
            outputConsumer.accept("❌ GOAL EXECUTION FAILED: Missing action definition");
            outputConsumer.accept("=".repeat(60));
            return false;
        }

        outputConsumer.accept("STEP " + stepNumber + ": " + description);
        outputConsumer.accept("-".repeat(50));

        outputConsumer.accept("🔊 IVR Says: \"" + prompt + "\"");
        sleep(1500);

        return executeActionForWeb(action, outputConsumer);
    }

    /**
     * Execute a specific action during the IVR simulation for web interface
     * 
     * @param action         the action to execute
     * @param outputConsumer callback function to handle output messages
     * @return true if the action executed successfully, false otherwise
     */
    private boolean executeActionForWeb(String action, Consumer<String> outputConsumer) {
        if (action == null || action.trim().isEmpty()) {
            outputConsumer.accept("❌ Error: Null or empty action");
            throw new RuntimeException("Action is null or empty - cannot execute simulation step");
        }
        switch (action.toLowerCase()) {
            case "wait":
                outputConsumer.accept("⏳ Action: Waiting...");
                sleep(1000);
                return true;
            case "listen":
                outputConsumer.accept("👂 Action: Listening to response...");
                sleep(2000);
                return true;
            case "press.0":
            case "press.1":
            case "press.2":
            case "press.3":
            case "press.4":
            case "press.5":
            case "press.6":
            case "press.7":
            case "press.8":
            case "press.9":
            case "press.*":
            case "press.#":
                outputConsumer.accept("📱 Action: Pressing " + action.substring(action.indexOf('.') + 1));
                sleep(500);
                return true;
            case "press.last_4_ssn":
                return handleSSNEntryForWeb(outputConsumer);
            case "say.card_number":
                return handleCardNumberEntryForWeb(outputConsumer);
            case "connect.representative":
                outputConsumer.accept("🔗 Connecting to a representative...");
                sleep(1000);
                return true;
            case "repeat":
                outputConsumer.accept("🔁 Action: Repeating menu options...");
                sleep(1000);
                return true;
            case "return":
                outputConsumer.accept("↩️ Action: Returning to previous menu...");
                sleep(1000);
                return true;
            case "collect.data":
                outputConsumer.accept("📊 Action: Collecting data for further processing...");
                sleep(1000);
                return true;
            default:
                outputConsumer.accept("❌ Error: Unknown action '" + action + "'");
                throw new RuntimeException(
                        "Unknown or unimplemented action: '" + action + "'. Action execution failed.");
        }
    }

    /**
     * Handle Social Security Number entry simulation for web interface
     * 
     * @param outputConsumer callback function to handle output messages
     * @return true if SSN entry completed successfully
     */
    private boolean handleSSNEntryForWeb(Consumer<String> outputConsumer) {
        String format = "4 digits followed by #";

        outputConsumer.accept("🔐 Action: Entering last 4 digits of SSN");
        outputConsumer.accept("   Format: " + format);

        StringBuilder enteringDisplay = new StringBuilder("   Entering: ");
        for (int i = 0; i < 4; i++) {
            enteringDisplay.append("*");
            outputConsumer.accept(enteringDisplay.toString());
            sleep(300);
        }
        enteringDisplay.append("#");
        outputConsumer.accept(enteringDisplay.toString());
        sleep(800); // Longer pause to simulate IVR processing time

        return true;
    }

    /**
     * Handle card number entry simulation for web interface
     * 
     * @param outputConsumer callback function to handle output messages
     * @return true if card number entry completed successfully
     */
    private boolean handleCardNumberEntryForWeb(Consumer<String> outputConsumer) {
        String format = "16 digits followed by #";

        outputConsumer.accept("💳 Action: Entering card number");
        outputConsumer.accept("   Format: " + format);

        StringBuilder enteringDisplay = new StringBuilder("   Entering: ");
        for (int i = 0; i < 16; i++) {
            enteringDisplay.append("*");
            outputConsumer.accept(enteringDisplay.toString());
            sleep(150);
        }
        enteringDisplay.append("#");
        outputConsumer.accept(enteringDisplay.toString());
        sleep(500);

        return true;
    }

    /**
     * Sleep for the specified number of milliseconds
     * 
     * @param milliseconds the number of milliseconds to sleep
     */
    private void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * 
     * /**
     * Execute IVR simulation with action resolver support. Prints output to
     * System.out.
     * 
     * @param goal           the target goal being pursued
     * @param navigationPath the sequence of steps to execute
     * @param actionResolver the action resolver to use for dynamic action
     *                       determination
     */
    public void executeIvrSimulation(String goal, List<NavigationStep> navigationPath, ActionResolver actionResolver) {
        executeIvrSimulationForWeb(goal, navigationPath, System.out::println, actionResolver);
    }
}
