package com.cotality.ivra.bots_service.AI;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class GenAiService implements InitializingBean {
    @Value("${genai.center.client.id}")
    private String clientId;
    @Value("${genai.center.client.secret}")
    private String clientSecret;
    @Value("${genai.center.base.url}")
    private String baseUrl;
    @Value("${genai.center.template.id}")
    private String templateId;
    @Value("${genai.center.llm.orchestration.url}")
    private String orchestrationUrl;

    private final AtomicReference<String> token = new AtomicReference<>(null);
    private final RestTemplate restTemplate = new RestTemplate();

    @Override
    public void afterPropertiesSet() {
        // Token will be lazily generated on first use
    }

    @SuppressWarnings("rawtypes")
    private String fetchToken() {
        // Use HTTP Basic Auth and query param as required by GenAI Center
        String url = baseUrl + "/edgemicro-auth/token?grant_type=client_credentials";
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(clientId, clientSecret);
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity<String> entity = new HttpEntity<>("", headers); // No body needed
        try {
            ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.POST, entity, Map.class);
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                Object accessToken = response.getBody().get("access_token");
                if (accessToken != null) return accessToken.toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public String getToken() {
        if (token.get() == null) {
            String t = fetchToken();
            token.set(t != null ? t : "token-error");
        }
        return token.get();
    }

    public String getTemplateId() {
        return templateId;
    }

    @SuppressWarnings("rawtypes")
    public String chatWithModel(String prompt) {
        // Use the v2 chat endpoint and request structure from Postman
        String url = orchestrationUrl + "/genaicenter/v2/chat/";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(getToken());
        Map<String, Object> body = new HashMap<>();
        body.put("user_id", "IVR-USER");
        // Compose messages array as required by GenAI Center
        Map<String, Object> message = new HashMap<>();
        message.put("role", "user");
        message.put("prompt_id", templateId); // Use templateId as prompt_id
        // Compose content as a list of objects
        Map<String, Object> contentItem = new HashMap<>();
        contentItem.put("content_type", "text");
        contentItem.put("text", prompt);
        contentItem.put("prompt_var", "context");
        message.put("content", java.util.Collections.singletonList(contentItem));
        body.put("messages", java.util.Collections.singletonList(message));
        body.put("source_id", "ivr-bot");
        body.put("app_prompt_only", false);
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);
        try {
            ResponseEntity<Map> response = restTemplate.postForEntity(url, entity, Map.class);
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                // The response format has 'return_text' as the model reply
                Object returnText = response.getBody().get("return_text");
                if (returnText != null) return returnText.toString();
            }
            return "[AI] No response from model.";
        } catch (Exception e) {
            return "[AI] Error: " + e.getMessage();
        }
    }
}
