package com.cotality.ivra.bots_service;

import com.cotality.ivra.bots_service.IVR.IvrNavigationService;
import com.cotality.ivra.bots_service.IVR.IvrSimulationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;

@SpringBootApplication
public class App implements CommandLineRunner {
    
    @Autowired
    private IvrNavigationService navigationService;
    
    @Autowired
    private MenuLoader menuLoader;
    
    @Autowired
    private IvrSimulationService simulationService;
    
    public static void main(String[] args) {
        SpringApplication.run(App.class, args);
    }
    
    @Override
    public void run(String... args) throws Exception {
        System.out.println("Bank of America IVR Automation Bot Service");
    }
}