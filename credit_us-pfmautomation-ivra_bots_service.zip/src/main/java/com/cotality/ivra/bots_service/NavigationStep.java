package com.cotality.ivra.bots_service;

/**
 * Represents a single step in the IVR navigation sequence.
 * Contains the description, prompt, action, and menu key for each step.
 */
public class NavigationStep {
    private final String description;
    private final String prompt;
    private String action;
    private final String menuKey; // which button to press (1, 2, etc)
    
    public NavigationStep(String description, String prompt, String action, String menuKey) {
        this.description = description;
        this.prompt = prompt;
        this.action = action;
        this.menuKey = menuKey;
    }
    
    public NavigationStep(String description, String prompt, String action) {
        this(description, prompt, action, null);
    }
    
    public String getDescription() {
        return description;
    }
    
    public String getPrompt() {
        return prompt;
    }
    
    public String getAction() {
        return action;
    }
    public void setAction(String action) {
        this.action = action;
    }
    
    public String getMenuKey() {
        return menuKey;
    }
    
    @Override
    public String toString() {
        return String.format("NavigationStep{description='%s', action='%s', menuKey='%s'}", 
                           description, action, menuKey);
    }
}
