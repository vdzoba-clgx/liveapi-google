package com.cotality.ivra.bots_service.IVR;

/**
 * Interface for resolving actions based on IVR prompts.
 * This allows different strategies for determining what action to take
 * when the IVR system presents a prompt to the user.
 */
public interface ActionResolver {
      /**
     * Resolve the appropriate action based on an IVR prompt.
     * 
     * @param prompt The message from the IVR system
     * @param context Additional context about the current state
     * @return The action to execute (e.g., "press.1", "wait", "press.last_4_ssn")
     */
    String resolveAction(String prompt, String context);
    
    /**
     * Resolve the appropriate action based on an IVR prompt with goal awareness.
     * 
     * @param prompt The message from the IVR system
     * @param context Additional context about the current state
     * @param targetGoal The goal we're trying to reach (e.g., "account_balance_inquiry")
     * @return The action to execute (e.g., "press.1", "wait", "press.last_4_ssn")
     */
    default String resolveAction(String prompt, String context, String targetGoal) {
        // Default implementation falls back to original method for backward compatibility
        return resolveAction(prompt, context);
    }
    
    /**
     * Get the name of this resolver implementation.
     * 
     * @return The resolver name for identification
     */
    String getResolverName();
}