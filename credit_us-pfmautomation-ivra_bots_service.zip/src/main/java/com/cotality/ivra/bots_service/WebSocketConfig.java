package com.cotality.ivra.bots_service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

/**
 * WebSocket configuration for audio streaming
 */
@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    @Autowired
    private AudioStreamHandler audioStreamHandler;
    
    @Autowired
    private SimpleAudioStreamHandler simpleAudioStreamHandler;
    
    @Autowired
    private SileroAudioStreamHandler sileroAudioStreamHandler;

    @Override
    public void registerWebSocketHandlers(@NonNull WebSocketHandlerRegistry registry) {
        // Legacy handler for backward compatibility
        registry.addHandler(audioStreamHandler, "/ws/audio-stream")
                .setAllowedOrigins("*"); // Allow Twilio to connect
                
        // Simplified state machine handler 
        registry.addHandler(simpleAudioStreamHandler, "/ws/simple-audio-stream")
                .setAllowedOrigins("*"); // Allow Twilio to connect
                
        // Silero VAD-powered handler
        registry.addHandler(sileroAudioStreamHandler, "/ws/silero-audio-stream")
                .setAllowedOrigins("*"); // Allow Twilio to connect
    }
}
