package com.cotality.ivra.bots_service.AI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
public class AiController {
    @Autowired
    private GenAiService genAiService;
    @Autowired
    private ChatHistoryService chatHistoryService;

    @GetMapping("/ai")
    public String aiChatPage(Model model) {
        model.addAttribute("history", chatHistoryService.loadHistory());
        return "ai_chat";
    }

    @PostMapping("/ai/send")
    @ResponseBody
    public List<ChatHistoryService.Message> sendMessage(@RequestParam("message") String message) {
        List<ChatHistoryService.Message> history = chatHistoryService.loadHistory();
        history.add(new ChatHistoryService.Message("user", message));
        String aiResponse = genAiService.chatWithModel(message);
        history.add(new ChatHistoryService.Message("ai", aiResponse));
        chatHistoryService.saveHistory(history);
        return history;
    }

    @GetMapping("/ai/history")
    @ResponseBody
    public List<ChatHistoryService.Message> getHistory() {
        return chatHistoryService.loadHistory();
    }

    @DeleteMapping("/ai/history")
    @ResponseBody
    public void clearHistory() {
        chatHistoryService.saveHistory(new java.util.ArrayList<>());
    }
}
