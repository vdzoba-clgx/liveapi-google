package com.cotality.ivra.bots_service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.genai.AsyncSession;
import com.google.genai.Client;
import com.google.genai.types.Blob;
import com.google.genai.types.LiveConnectConfig;
import com.google.genai.types.LiveSendRealtimeInputParameters;
import com.google.genai.types.LiveServerMessage;
import com.google.genai.types.Modality;
import com.google.genai.types.SpeechConfig;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;


/**
 * Handles WebSocket connections for streaming Twilio audio to the Google Live API
 * Architecture: Twilio Audio → AudioStreamHandler → Google Live API → Action Response
 */
@Component
public class AudioStreamHandler implements WebSocketHandler {

  private static final Logger logger = LoggerFactory.getLogger(AudioStreamHandler.class);

  @Autowired private GoogleLiveApiService googleLiveApiService;

  @Autowired private HandleIVRResponseController handleIVRResponseController;

  @Value("${google_api_key}")
  private String googleApiKey;

  // Store stream information
  private final Map<String, String> streamInfo = new ConcurrentHashMap<>();

  // Google GenAI Live API sessions per stream
  private final Map<String, AsyncSession> liveSessions = new ConcurrentHashMap<>();

  @Override
  public void afterConnectionEstablished(WebSocketSession session) throws Exception {
    logger.info("WebSocket connection established: {}", session.getId());
  }

  @Override
  public void handleMessage(WebSocketSession session, WebSocketMessage<?> message) throws Exception {
    String payload = message.getPayload().toString();
    JsonObject json = JsonParser.parseString(payload).getAsJsonObject();
    String eventType = json.get("event").getAsString();

    logger.debug("Processing event type '{}' for session {}", eventType, session.getId());

    switch (eventType) {
      case "connected":
        handleConnected(session, json);
        break;
      case "start":
        handleStart(session, json);
        break;
      case "media":
        handleMedia(session, json);
        break;
      case "stop":
        handleStop(session, json);
        break;
      default:
        logger.warn("Unknown event type: {}", eventType);
    }
  }

  private void handleConnected(WebSocketSession session, JsonObject json) {
    logger.info("Twilio Media Stream connected: {}", session.getId());
  }

  private void handleStart(WebSocketSession session, JsonObject json) {
    try {
      String streamSid = json.get("streamSid").getAsString();
      String callSid = json.get("start").getAsJsonObject().get("callSid").getAsString();

      logger.info("Starting media stream: streamSid={}, callSid={}", streamSid, callSid);

      streamInfo.put(session.getId(), streamSid);
      streamToCallSidMapping.put(streamSid, callSid); // Store the mapping

      String goal = googleLiveApiService.getGoalForStream(streamSid);
      if (goal == null || goal.trim().isEmpty()) {
        goal = handleIVRResponseController.getCurrentCallGoal();
        if (goal == null || goal.trim().isEmpty()) {
          logger.warn("No goal set for stream {}, using default", streamSid);
          goal = "Navigate through the IVR system to reach a human representative";
        }
      }
      logger.info("Using goal '{}' for stream {}", goal, streamSid);

      initializeGoogleLiveApi(streamSid, goal);

    } catch (Exception e) {
      logger.error("Error handling start event", e);
    }
  }

  private void handleMedia(WebSocketSession session, JsonObject json) {
    try {
      String streamSid = streamInfo.get(session.getId());
      if (streamSid == null) {
        logger.warn("No streamSid found for session {}", session.getId());
        return;
      }

      String payload = json.get("media").getAsJsonObject().get("payload").getAsString();
      byte[] audioData = Base64.getDecoder().decode(payload);

      logger.debug("Streaming {} bytes of audio to Google Live API for stream {}", audioData.length, streamSid);
      streamAudioToGoogle(streamSid, audioData);

    } catch (Exception e) {
      logger.error("Error handling media event", e);
    }
  }

  private void handleStop(WebSocketSession session, JsonObject json) {
    try {
      String streamSid = streamInfo.get(session.getId());
      if (streamSid != null) {
        logger.info("Stopping media stream: {}", streamSid);

        closeGoogleLiveApi(streamSid);

        googleLiveApiService.removeGoalForStream(streamSid);

        streamInfo.remove(session.getId());
      }
    } catch (Exception e) {
      logger.error("Error handling stop event", e);
    }
  }

  @Override
  public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
    logger.error("Transport error on session {}: {}", session.getId(), exception.getMessage());
    afterConnectionClosed(session, CloseStatus.SERVER_ERROR);
  }

  @Override
  public void afterConnectionClosed(WebSocketSession session, CloseStatus closeStatus) throws Exception {
    logger.info("WebSocket connection closed: {} with status {}", session.getId(), closeStatus);
    String streamSid = streamInfo.get(session.getId());
    if (streamSid != null) {
      handleStop(session, null); // Ensure cleanup if not already stopped
    }
  }

  @Override
  public boolean supportsPartialMessages() {
    return false;
  }

  // --- Google Live API Integration ---

  private void initializeGoogleLiveApi(String streamSid, String goal) {
    try {
      logger.info("Initializing Google Live API for stream {} with goal: {}", streamSid, goal);
      System.setProperty("GOOGLE_API_KEY", googleApiKey);
      Client client = new Client();
      String modelId = "gemini-2.0-flash-live-001";

      LiveConnectConfig config =
          LiveConnectConfig.builder()
              .responseModalities(Modality.Known.TEXT)
              .speechConfig(SpeechConfig.builder().languageCode("en-US").build())
              .build();

      CompletableFuture<AsyncSession> sessionFuture = client.async.live.connect(modelId, config);

      sessionFuture.whenComplete(
          (session, throwable) -> {
            if (throwable != null) {
              logger.error(
                  "Failed to initialize Google Live API for stream {}", streamSid, throwable);
            } else {
              liveSessions.put(streamSid, session);
              logger.info("Google Live API session initialized for stream {}", streamSid);

              // Send a very specific system instruction
              String systemInstruction = String.format(
                  "You are an AI assistant navigating a Bank of America IVR phone system to achieve this goal: %s. " +
                  "Listen to the live audio and respond IMMEDIATELY when you hear IVR prompts. " +
                  "Respond with ONLY ONE of these exact actions: " +
                  "'0' - to speak with representative, " +
                  "'1' - for option 1, " +
                  "'2' - for option 2, " +
                  "'*' - for alternative authentication, " +
                  "'1234' - when asked for last 4 SSN digits. " +
                  "Examples: " +
                  "If you hear 'Please enter the last 4 digits of your Social Security Number' → respond '1234' " +
                  "If you hear 'Press 1 for account balance' and goal is account balance → respond '1' " +
                  "If you hear 'Press 0 to speak with representative' and need help → respond '0' " +
                  "Respond immediately with just the action, nothing else.",
                  goal);
              
              session.sendRealtimeInput(
                  LiveSendRealtimeInputParameters.builder().text(systemInstruction).build());

              session.receive(response -> handleGoogleResponse(streamSid, response));
            }
          });

    } catch (Exception e) {
      logger.error("Failed to initialize Google Live API for stream {}", streamSid, e);
    }
  }

  private void streamAudioToGoogle(String streamSid, byte[] audioData) {
    AsyncSession session = liveSessions.get(streamSid);
    if (session != null) {
      try {
        logger.debug("Sending {} bytes of audio to Google Live API for stream {}", audioData.length, streamSid);
        session.sendRealtimeInput(
            LiveSendRealtimeInputParameters.builder()
                .media(Blob.builder().mimeType("audio/pcm").data(audioData).build())
                .build());
      } catch (Exception e) {
        logger.error("Error streaming audio to Google for stream {}: {}", streamSid, e.getMessage());
      }
    } else {
      // Only log warning occasionally to avoid spam
      if (Math.random() < 0.1) { // Log 10% of the time
        logger.warn("No Google Live API session found for stream {} - session may still be initializing", streamSid);
      }
    }
  }

  private void handleGoogleResponse(String streamSid, LiveServerMessage response) {
    response
        .serverContent()
        .ifPresent(
            content -> {
              if (content.turnComplete().orElse(false)) {
                logger.info("Google Live API turn complete for streamSid: {}", streamSid);
              } else {
                content.modelTurn().stream()
                    .flatMap(modelTurn -> modelTurn.parts().stream())
                    .flatMap(java.util.Collection::stream)
                    .forEach(
                        part -> {
                          part.text()
                              .ifPresent(
                                  text -> {
                                    logger.info(
                                        "Google Live API response for streamSid: {}: '{}'",
                                        streamSid,
                                        text);
                                    
                                    // Process each response chunk immediately
                                    processGoogleResponse(streamSid, text.trim());
                                  });
                        });
              }
            });
  }

  private void processGoogleResponse(String streamSid, String responseText) {
    if (responseText.isEmpty()) {
      return;
    }
    
    logger.info("Processing Google response for streamSid {}: '{}'", streamSid, responseText);
    
    // Extract actionable instructions from the response
    String action = extractActionFromResponse(responseText);
    if (action != null && !"wait".equals(action)) {
      logger.info("Extracted action for streamSid {}: '{}'", streamSid, action);
      sendActionToTwilio(streamSid, action);
    } else if ("wait".equals(action)) {
      logger.info("Google Live API suggests waiting for stream {}", streamSid);
    } else {
      logger.debug("No actionable response from Google Live API: '{}'", responseText);
    }
  }

  private String extractActionFromResponse(String responseText) {
    String cleanResponse = responseText.replaceAll("\\s+", " ").trim();
    logger.debug("Extracting action from response: '{}'", cleanResponse);
    
    // Look for exact responses first
    if (cleanResponse.equals("wait")) return "wait";
    if (cleanResponse.equals("0")) return "0";
    if (cleanResponse.equals("1")) return "1";
    if (cleanResponse.equals("2")) return "2";
    if (cleanResponse.equals("*")) return "*";
    if (cleanResponse.matches("\\d{4}")) return cleanResponse; // SSN digits
    if (cleanResponse.matches("\\d")) return cleanResponse; // Single digit
    
    // Look for common patterns in longer responses
    String lowerResponse = cleanResponse.toLowerCase();
    if (lowerResponse.contains("press 0") || lowerResponse.contains("speak with representative")) return "0";
    if (lowerResponse.contains("press 1")) return "1";
    if (lowerResponse.contains("press 2")) return "2";
    if (lowerResponse.contains("press *") || lowerResponse.contains("star key")) return "*";
    if (lowerResponse.contains("1234")) return "1234";
    
    return null; // No clear action found
  }

  private void sendActionToTwilio(String streamSid, String action) {
    try {
      String callSid = getCallSidForStream(streamSid);
      if (callSid == null) {
        logger.warn("No call SID found for stream {}", streamSid);
        return;
      }
      
      logger.info("Sending action '{}' to Twilio for stream {}", action, streamSid);
      handleIVRResponseController.processGoogleLiveApiAction(streamSid, action, "Google Live API decision: " + action);
      
    } catch (Exception e) {
      logger.error("Error sending action to Twilio for stream {}: {}", streamSid, e.getMessage());
    }
  }

  private String getCallSidForStream(String streamSid) {
    return streamToCallSidMapping.get(streamSid);
  }

  // Store mapping between streamSid and callSid
  private final Map<String, String> streamToCallSidMapping = new ConcurrentHashMap<>();

  private void closeGoogleLiveApi(String streamSid) {
    AsyncSession session = liveSessions.remove(streamSid);
    if (session != null) {
      try {
        session.close();
        logger.info("Google Live API session closed for stream {}", streamSid);
      } catch (Exception e) {
        logger.error(
            "Error closing Google Live API session for stream {}: {}", streamSid, e.getMessage());
      }
    }
    // Clean up mappings
    streamToCallSidMapping.remove(streamSid);
  }
}
