package com.cotality.ivra.bots_service.IVR;

import com.cotality.ivra.bots_service.MenuLoader;
import com.cotality.ivra.bots_service.NavigationStep;
import com.google.gson.JsonObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

@Service
public class IvrValidationService {
    
    @Autowired
    private MenuLoader menuLoader;
    
    @Autowired
    private IvrNavigationService navigationService;
    
    @Autowired
    private SimulationActionResolver simulationActionResolver;
    
    @Value("${bofa_ivr_menu_actual}")
    private String actualMenuFileName;
    
    private JsonObject actualMenuData;
    
    private void loadActualMenuData() throws IOException {
        if (actualMenuData == null) {
            String actualMenuContent = menuLoader.loadJsonFromResources(actualMenuFileName);
            com.google.gson.Gson gson = new com.google.gson.Gson();
            actualMenuData = gson.fromJson(actualMenuContent, JsonObject.class);
        }
    }
    
    public ValidationResult validateGoalNavigation(String goalName) throws IOException, ValidationException {
        List<NavigationStep> expectedPath = navigationService.generateNavigationPath(goalName);
        if (expectedPath == null) {
            throw new ValidationException("Goal '" + goalName + "' not found in expected menu structure");
        }
        
        loadActualMenuData();
        
        ValidationResult result = new ValidationResult(goalName);
        
        for (int i = 0; i < expectedPath.size(); i++) {
            NavigationStep expectedStep = expectedPath.get(i);
            String expectedAction = expectedStep.getAction();
            String prompt = expectedStep.getPrompt();
            String description = expectedStep.getDescription();
            
            try {
                String actualAction = simulationActionResolver.resolveAction(prompt, description, goalName);
                
                if (!expectedAction.equals(actualAction)) {
                    ActionMismatch mismatch = new ActionMismatch(
                        i + 1,
                        description,
                        prompt,
                        expectedAction,
                        actualAction
                    );
                    result.addMismatch(mismatch);
                }
                
            } catch (Exception e) {
                ActionMismatch mismatch = new ActionMismatch(
                    i + 1,
                    description,
                    prompt,
                    expectedAction,
                    "ERROR: " + e.getMessage()
                );
                result.addMismatch(mismatch);
            }
        }
        
        if (result.hasCriticalMismatches()) {
            throw new ValidationException(result.getValidationSummary());
        }
        
        return result;
    }
    
    public static class ValidationException extends Exception {
        public ValidationException(String message) {
            super(message);
        }
    }
    
    public static class ValidationResult {
        private final String goalName;
        private final List<ActionMismatch> mismatches;
        
        public ValidationResult(String goalName) {
            this.goalName = goalName;
            this.mismatches = new java.util.ArrayList<>();
        }
        
        public void addMismatch(ActionMismatch mismatch) {
            mismatches.add(mismatch);
        }
        
        public boolean hasMismatches() {
            return !mismatches.isEmpty();
        }
        
        public boolean hasCriticalMismatches() {
            return hasMismatches();
        }
        
        public List<ActionMismatch> getMismatches() {
            return mismatches;
        }
        
        public String getValidationSummary() {
            if (!hasMismatches()) {
                return "✅ Validation PASSED: Goal '" + goalName + "' - No mismatches found";
            }
            
            StringBuilder summary = new StringBuilder();
            summary.append("❌ Validation FAILED: Goal '").append(goalName).append("'\n");
            summary.append("Found ").append(mismatches.size()).append(" mismatch(es):\n\n");
            
            for (ActionMismatch mismatch : mismatches) {
                summary.append(mismatch.toString()).append("\n");
            }
            
            return summary.toString();
        }
    }
    
    public static class ActionMismatch {
        private final int stepNumber;
        private final String description;
        private final String prompt;
        private final String expectedAction;
        private final String actualAction;
        
        public ActionMismatch(int stepNumber, String description, String prompt, 
                            String expectedAction, String actualAction) {
            this.stepNumber = stepNumber;
            this.description = description;
            this.prompt = prompt;
            this.expectedAction = expectedAction;
            this.actualAction = actualAction;
        }
        
        public int getStepNumber() { return stepNumber; }
        public String getDescription() { return description; }
        public String getPrompt() { return prompt; }
        public String getExpectedAction() { return expectedAction; }
        public String getActualAction() { return actualAction; }
        
        @Override
        public String toString() {
            return String.format(
                "📍 STEP %d: %s\n" +
                "   Prompt: \"%s\"\n" +
                "   Expected: %s\n" +
                "   Actual:   %s\n" +
                "   ❌ MISMATCH DETECTED!",
                stepNumber, description, prompt, expectedAction, actualAction
            );
        }
    }
}
