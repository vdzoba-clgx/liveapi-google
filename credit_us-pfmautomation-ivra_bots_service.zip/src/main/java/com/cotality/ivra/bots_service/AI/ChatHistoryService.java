package com.cotality.ivra.bots_service.AI;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.InitializingBean;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@Service
public class ChatHistoryService implements InitializingBean {
    private static final String HISTORY_FILE = "ai_chat_history.json";
    private final Gson gson = new Gson();

    @Override
    public void afterPropertiesSet() {
        cleanUpOnStartup();
    }

    public void cleanUpOnStartup() {
        try {
            Files.deleteIfExists(Paths.get(HISTORY_FILE));
        } catch (IOException ignored) {}
    }

    public synchronized void saveHistory(List<Message> history) {
        try (FileWriter writer = new FileWriter(HISTORY_FILE)) {
            gson.toJson(history, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized List<Message> loadHistory() {
        try {
            File file = new File(HISTORY_FILE);
            if (!file.exists()) return new ArrayList<>();
            String json = new String(Files.readAllBytes(file.toPath()));
            return gson.fromJson(json, new TypeToken<List<Message>>(){}.getType());
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    public static class Message {
        public String role; // "user" or "ai"
        public String content;
        public Message(String role, String content) {
            this.role = role;
            this.content = content;
        }
    }
}
