package com.cotality.ivra.bots_service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;

/**
 * Simplified Audio Stream Handler with clean state machine logic
 * 
 * Flow:
 * 1. Start streaming
 * 2. Detect silence/phrase boundary → send to STT
 * 3. Get transcript → send to AI
 * 4. If AI says "wait" → continue accumulating, add to context, send again
 * 5. If AI says action → pause streaming, execute action, resume streaming
 * 6. If AI says "collect.data" → continue streaming for configurable time, then hang up
 */
@Component
public class SimpleAudioStreamHandler implements WebSocketHandler {

    private static final Logger logger = LoggerFactory.getLogger(SimpleAudioStreamHandler.class);
    private final Gson gson = new Gson();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    // Configuration - No hardcoding!
    private static final int MIN_TRANSCRIPT_LENGTH = 10;
    private static final long SILENCE_THRESHOLD_MS = 1500;  // When to send to STT
    private static final int MAX_WAIT_CYCLES = 5;           // Prevent infinite wait loops
    private static final long DATA_COLLECTION_TIMEOUT_MS = 45000; // Configurable collection time
    private static final double SPEECH_ENERGY_THRESHOLD = 300.0;
    private static final int SILENCE_FRAMES_THRESHOLD = 75; // ~1.5 seconds
    private static final int MAX_BUFFER_SIZE = 64000;

    // Service endpoints
    private static final String TRANSCRIPTION_URL = "http://127.0.0.1:5000/transcribe";
    private static final String CONTROLLER_ENDPOINT = "http://localhost:8080/outbound/stream-transcription";

    // Stream states
    enum StreamState {
        STREAMING,       // Actively processing audio
        PAUSED,          // Waiting for Twilio action to complete
        COLLECTING_DATA, // Special 45s data collection mode
        ERROR            // Recovery mode
    }

    // Per-stream data structures
    private final Map<String, StreamState> streamStates = new ConcurrentHashMap<>();
    private final Map<String, StringBuilder> accumulatedTranscripts = new ConcurrentHashMap<>();
    private final Map<String, Integer> waitCycles = new ConcurrentHashMap<>();
    private final Map<String, String> streamInfo = new ConcurrentHashMap<>();
    
    // Audio buffering
    private final Map<String, byte[]> audioBuffers = new ConcurrentHashMap<>();
    private final Map<String, Integer> bufferSizes = new ConcurrentHashMap<>();
    private final Map<String, Integer> chunkCounters = new ConcurrentHashMap<>();
    
    // Simple VAD
    private final Map<String, Integer> silenceFrames = new ConcurrentHashMap<>();
    private final Map<String, Boolean> hasSpeech = new ConcurrentHashMap<>();
    
    // Data collection timing
    private final Map<String, Long> dataCollectionStartTime = new ConcurrentHashMap<>();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        logger.info("WebSocket connection established: {}", session.getId());
        
        // Extract callSid from URL if available
        if (session.getUri() != null) {
            String query = session.getUri().getQuery();
            if (query != null && !query.isEmpty()) {
                String callSid = extractCallSidFromQuery(query);
                if (callSid != null) {
                    streamInfo.put("session_" + session.getId() + "_callsid", callSid);
                    logger.info("Extracted callSid from URL: {}", callSid);
                }
            }
        }
    }

    @Override
    public void handleMessage(WebSocketSession session, WebSocketMessage<?> message) throws Exception {
        if (message instanceof TextMessage) {
            String payload = ((TextMessage) message).getPayload();
            JsonObject json = gson.fromJson(payload, JsonObject.class);
            String event = json.get("event").getAsString();

            switch (event) {
                case "connected":
                    handleConnected(json);
                    break;
                case "start":
                    handleStart(session, json);
                    break;
                case "media":
                    handleMedia(json);
                    break;
                case "stop":
                    handleStop(json);
                    break;
                default:
                    logger.debug("Unknown event: {}", event);
            }
        }
    }

    private void handleConnected(JsonObject json) {
        logger.debug("Stream connected");
    }

    private void handleStart(WebSocketSession session, JsonObject json) {
        try {
            if (!json.has("streamSid") || json.get("streamSid").isJsonNull()) {
                logger.error("Missing streamSid in start event");
                return;
            }

            String streamSid = json.get("streamSid").getAsString();
            logger.info("Starting stream: {}", streamSid);

            // Initialize stream state
            streamStates.put(streamSid, StreamState.STREAMING);
            accumulatedTranscripts.put(streamSid, new StringBuilder());
            waitCycles.put(streamSid, 0);

            // Initialize audio buffering
            audioBuffers.put(streamSid, new byte[MAX_BUFFER_SIZE]);
            bufferSizes.put(streamSid, 0);
            chunkCounters.put(streamSid, 0);
            silenceFrames.put(streamSid, 0);
            hasSpeech.put(streamSid, false);

            // Store callSid
            String callSid = "unknown";
            if (json.has("callSid") && !json.get("callSid").isJsonNull()) {
                callSid = json.get("callSid").getAsString();
            } else {
                String sessionCallSid = streamInfo.get("session_" + session.getId() + "_callsid");
                if (sessionCallSid != null) {
                    callSid = sessionCallSid;
                    streamInfo.remove("session_" + session.getId() + "_callsid");
                }
            }
            streamInfo.put(streamSid + "_callSid", callSid);

            // Create audio directory
            String dateFolder = java.time.LocalDate.now()
                    .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            java.io.File audioDir = new java.io.File("audio/streams/" + dateFolder);
            if (!audioDir.exists()) {
                audioDir.mkdirs();
            }
            streamInfo.put(streamSid, audioDir.getAbsolutePath());

            logger.info("Stream {} initialized in STREAMING state with callSid: {}", streamSid, callSid);

        } catch (Exception e) {
            logger.error("Error starting stream: {}", e.getMessage(), e);
        }
    }

    private void handleMedia(JsonObject json) {
        try {
            if (!json.has("streamSid") || json.get("streamSid").isJsonNull()) {
                return;
            }

            String streamSid = json.get("streamSid").getAsString();
            StreamState state = streamStates.get(streamSid);
            
            // Only process audio in STREAMING and COLLECTING_DATA states
            if (state == null || state == StreamState.PAUSED || state == StreamState.ERROR) {
                return;
            }

            // Check data collection timeout
            if (state == StreamState.COLLECTING_DATA) {
                Long startTime = dataCollectionStartTime.get(streamSid);
                if (startTime != null && (System.currentTimeMillis() - startTime) > DATA_COLLECTION_TIMEOUT_MS) {
                    logger.info("Data collection timeout reached for stream {}, hanging up", streamSid);
                    executeHangup(streamSid);
                    return;
                }
            }

            JsonObject media = json.getAsJsonObject("media");
            if (!media.has("payload") || media.get("payload").isJsonNull()) {
                return;
            }

            String payload = media.get("payload").getAsString();
            byte[] mulawData = Base64.getDecoder().decode(payload);
            byte[] pcmData = convertMulawToPcm(mulawData);

            // Simple VAD and buffering
            boolean shouldTranscribe = processAudioChunk(streamSid, pcmData);
            
            if (shouldTranscribe) {
                transcribeBufferedAudio(streamSid);
            }

        } catch (Exception e) {
            logger.error("Error processing media: {}", e.getMessage(), e);
        }
    }

    private void handleStop(JsonObject json) {
        try {
            if (!json.has("streamSid") || json.get("streamSid").isJsonNull()) {
                return;
            }

            String streamSid = json.get("streamSid").getAsString();
            logger.info("Stopping stream: {}", streamSid);

            // Cleanup all state for this stream
            streamStates.remove(streamSid);
            accumulatedTranscripts.remove(streamSid);
            waitCycles.remove(streamSid);
            audioBuffers.remove(streamSid);
            bufferSizes.remove(streamSid);
            chunkCounters.remove(streamSid);
            silenceFrames.remove(streamSid);
            hasSpeech.remove(streamSid);
            dataCollectionStartTime.remove(streamSid);
            streamInfo.remove(streamSid);
            streamInfo.remove(streamSid + "_callSid");

        } catch (Exception e) {
            logger.error("Error stopping stream: {}", e.getMessage(), e);
        }
    }

    /**
     * Simple VAD and audio buffering
     * Returns true when we should transcribe the accumulated audio
     */
    private boolean processAudioChunk(String streamSid, byte[] pcmData) {
        try {
            // Calculate energy for simple VAD
            double energy = calculateAudioEnergy(pcmData);
            boolean isSpeech = energy > SPEECH_ENERGY_THRESHOLD;
            
            // Update speech state
            if (isSpeech) {
                hasSpeech.put(streamSid, true);
                silenceFrames.put(streamSid, 0);
            } else {
                int currentSilence = silenceFrames.getOrDefault(streamSid, 0);
                silenceFrames.put(streamSid, currentSilence + 1);
            }

            // Add to buffer
            byte[] buffer = audioBuffers.get(streamSid);
            Integer currentSize = bufferSizes.get(streamSid);
            
            if (buffer != null && currentSize != null) {
                if (currentSize + pcmData.length < buffer.length) {
                    System.arraycopy(pcmData, 0, buffer, currentSize, pcmData.length);
                    bufferSizes.put(streamSid, currentSize + pcmData.length);
                } else {
                    // Buffer full - transcribe immediately
                    return true;
                }
            }

            // Transcribe when we detect end of speech (silence after speech)
            Boolean hadSpeech = hasSpeech.get(streamSid);
            Integer silence = silenceFrames.get(streamSid);
            
            if (hadSpeech != null && hadSpeech && 
                silence != null && silence >= SILENCE_FRAMES_THRESHOLD) {
                
                // Reset for next phrase
                hasSpeech.put(streamSid, false);
                silenceFrames.put(streamSid, 0);
                return true;
            }

            return false;

        } catch (Exception e) {
            logger.error("Error processing audio chunk: {}", e.getMessage(), e);
            return false;
        }
    }

    /**
     * Transcribe the buffered audio and send to AI
     */
    private void transcribeBufferedAudio(String streamSid) {
        try {
            byte[] buffer = audioBuffers.get(streamSid);
            Integer size = bufferSizes.get(streamSid);
            
            if (buffer == null || size == null || size == 0) {
                return;
            }

            // Save audio chunk
            String audioFile = saveAudioChunk(streamSid, buffer, size);
            if (audioFile == null) {
                return;
            }

            // Reset buffer
            bufferSizes.put(streamSid, 0);

            // Transcribe asynchronously
            CompletableFuture.runAsync(() -> {
                try {
                    String transcript = transcribeAudio(audioFile);
                    if (transcript != null && !transcript.trim().isEmpty()) {
                        processTranscript(streamSid, transcript.trim());
                    }
                } catch (Exception e) {
                    logger.error("Error in async transcription: {}", e.getMessage(), e);
                }
            });

        } catch (Exception e) {
            logger.error("Error transcribing buffered audio: {}", e.getMessage(), e);
        }
    }

    /**
     * Process new transcript - core state machine logic
     */
    private void processTranscript(String streamSid, String newTranscript) {
        try {
            StreamState state = streamStates.get(streamSid);
            if (state != StreamState.STREAMING && state != StreamState.COLLECTING_DATA) {
                logger.debug("Ignoring transcript in state: {}", state);
                return;
            }

            logger.info("TRANSCRIPT[{}]: \"{}\"", streamSid, newTranscript);

            // Add to accumulated transcript
            StringBuilder accumulated = accumulatedTranscripts.get(streamSid);
            if (accumulated == null) {
                accumulated = new StringBuilder();
                accumulatedTranscripts.put(streamSid, accumulated);
            }

            if (accumulated.length() > 0) {
                accumulated.append(" ");
            }
            accumulated.append(newTranscript);

            // Send full context to AI
            String fullTranscript = accumulated.toString();
            logger.info("SENDING TO AI[{}]: \"{}\"", streamSid, fullTranscript);
            
            sendToAI(streamSid, fullTranscript);

        } catch (Exception e) {
            logger.error("Error processing transcript: {}", e.getMessage(), e);
        }
    }

    /**
     * Send transcript to AI and handle response
     */
    private void sendToAI(String streamSid, String transcript) {
        try {
            String callSid = streamInfo.getOrDefault(streamSid + "_callSid", "unknown");
            
            String requestBody = String.format("transcription=%s&callSid=%s&streamSid=%s",
                    java.net.URLEncoder.encode(transcript, "UTF-8"),
                    java.net.URLEncoder.encode(callSid, "UTF-8"),
                    java.net.URLEncoder.encode(streamSid, "UTF-8"));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(CONTROLLER_ENDPOINT))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .timeout(Duration.ofSeconds(10))
                    .build();

            CompletableFuture<HttpResponse<String>> futureResponse = httpClient.sendAsync(request,
                    HttpResponse.BodyHandlers.ofString());

            futureResponse.thenAccept(response -> {
                handleAIResponse(streamSid, response.body());
            }).exceptionally(ex -> {
                logger.error("Failed to send to AI: {}", ex.getMessage(), ex);
                streamStates.put(streamSid, StreamState.ERROR);
                return null;
            });

        } catch (Exception e) {
            logger.error("Error sending to AI: {}", e.getMessage(), e);
            streamStates.put(streamSid, StreamState.ERROR);
        }
    }

    /**
     * Handle AI response - core logic implementation
     */
    private void handleAIResponse(String streamSid, String responseBody) {
        try {
            String action = extractActionFromResponse(responseBody);
            logger.info("AI ACTION[{}]: {}", streamSid, action);

            if ("wait".equals(action)) {
                // Continue accumulating - check wait cycle limit
                Integer cycles = waitCycles.getOrDefault(streamSid, 0);
                if (cycles >= MAX_WAIT_CYCLES) {
                    logger.warn("Max wait cycles reached for stream {}, forcing action", streamSid);
                    streamStates.put(streamSid, StreamState.ERROR);
                    return;
                }
                waitCycles.put(streamSid, cycles + 1);
                logger.info("AI said wait (cycle {}/{}), continuing to accumulate", cycles + 1, MAX_WAIT_CYCLES);
                // Stay in current state, continue processing
                return;
            }

            // Reset wait cycles on non-wait action
            waitCycles.put(streamSid, 0);

            if ("collect.data".equals(action)) {
                // Enter data collection mode
                streamStates.put(streamSid, StreamState.COLLECTING_DATA);
                dataCollectionStartTime.put(streamSid, System.currentTimeMillis());
                logger.info("Entering data collection mode for {} seconds", DATA_COLLECTION_TIMEOUT_MS / 1000);
                return;
            }

            // Any other action - pause streaming, execute action, then resume
            streamStates.put(streamSid, StreamState.PAUSED);
            logger.info("Pausing stream {} to execute action: {}", streamSid, action);

            // Clear accumulated transcript since we're taking action
            accumulatedTranscripts.put(streamSid, new StringBuilder());

            // Execute action via Twilio (existing TwiML logic handles this)
            // The response body should contain the TwiML for the action
            // After Twilio processes it, we'll resume streaming

            // Schedule resume (simplified - in real implementation, this would be triggered by Twilio callback)
            CompletableFuture.runAsync(() -> {
                try {
                    Thread.sleep(2000); // Wait for action to complete
                    resumeStreaming(streamSid);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });

        } catch (Exception e) {
            logger.error("Error handling AI response: {}", e.getMessage(), e);
            streamStates.put(streamSid, StreamState.ERROR);
        }
    }

    /**
     * Resume streaming after action completion
     */
    private void resumeStreaming(String streamSid) {
        StreamState currentState = streamStates.get(streamSid);
        if (currentState == StreamState.PAUSED) {
            streamStates.put(streamSid, StreamState.STREAMING);
            logger.info("Resumed streaming for {}", streamSid);
        }
    }

    /**
     * Execute hangup for data collection completion
     */
    private void executeHangup(String streamSid) {
        logger.info("Executing hangup for stream {}", streamSid);
        // Implementation would send hangup TwiML to Twilio
        streamStates.put(streamSid, StreamState.ERROR); // Will be cleaned up in handleStop
    }

    // Helper methods (simplified versions of original implementations)

    private byte[] convertMulawToPcm(byte[] mulawData) {
        // Simplified μ-law to PCM conversion
        byte[] pcmData = new byte[mulawData.length * 2];
        for (int i = 0; i < mulawData.length; i++) {
            int mulaw = mulawData[i] & 0xFF;
            short pcm = (short) ((mulaw - 128) * 256); // Simplified conversion
            pcmData[i * 2] = (byte) (pcm & 0xFF);
            pcmData[i * 2 + 1] = (byte) ((pcm >> 8) & 0xFF);
        }
        return pcmData;
    }

    private double calculateAudioEnergy(byte[] pcmData) {
        if (pcmData.length < 2) return 0.0;
        
        long sumSquares = 0;
        int sampleCount = pcmData.length / 2;
        
        for (int i = 0; i < pcmData.length - 1; i += 2) {
            short sample = (short) ((pcmData[i + 1] << 8) | (pcmData[i] & 0xFF));
            sumSquares += (long) sample * sample;
        }
        
        return Math.sqrt((double) sumSquares / sampleCount);
    }

    private String saveAudioChunk(String streamSid, byte[] buffer, int size) {
        try {
            String audioDir = streamInfo.get(streamSid);
            Integer chunkNum = chunkCounters.get(streamSid);
            
            if (audioDir == null || chunkNum == null) {
                return null;
            }

            String timestamp = java.time.LocalDateTime.now()
                    .format(java.time.format.DateTimeFormatter.ofPattern("HHmmss_SSS"));
            String filename = String.format("%s/chunk_%03d_%s_%s.wav",
                    audioDir, chunkNum, timestamp, streamSid.substring(0, 8));

            saveAsWav(filename, buffer, size);
            chunkCounters.put(streamSid, chunkNum + 1);
            
            return filename;
        } catch (Exception e) {
            logger.error("Error saving audio chunk: {}", e.getMessage(), e);
            return null;
        }
    }

    private void saveAsWav(String filename, byte[] audioData, int dataLength) throws IOException {
        try (FileOutputStream wavFile = new FileOutputStream(filename)) {
            // Write simplified WAV header
            int totalLength = dataLength + 36;
            int sampleRate = 8000;
            short channels = 1;
            short bitsPerSample = 16;

            wavFile.write("RIFF".getBytes());
            wavFile.write(intToBytes(totalLength));
            wavFile.write("WAVE".getBytes());
            wavFile.write("fmt ".getBytes());
            wavFile.write(intToBytes(16));
            wavFile.write(shortToBytes((short) 1));
            wavFile.write(shortToBytes(channels));
            wavFile.write(intToBytes(sampleRate));
            wavFile.write(intToBytes(sampleRate * channels * bitsPerSample / 8));
            wavFile.write(shortToBytes((short) (channels * bitsPerSample / 8)));
            wavFile.write(shortToBytes(bitsPerSample));
            wavFile.write("data".getBytes());
            wavFile.write(intToBytes(dataLength));
            wavFile.write(audioData, 0, dataLength);
        }
    }

    private byte[] intToBytes(int value) {
        return new byte[]{
                (byte) value,
                (byte) (value >> 8),
                (byte) (value >> 16),
                (byte) (value >> 24)
        };
    }

    private byte[] shortToBytes(short value) {
        return new byte[]{
                (byte) value,
                (byte) (value >> 8)
        };
    }

    private String transcribeAudio(String filename) throws Exception {
        if (!Files.exists(Paths.get(filename))) {
            return null;
        }

        byte[] audioBytes = Files.readAllBytes(Paths.get(filename));
        String boundary = "----WebKitFormBoundary" + System.currentTimeMillis();

        StringBuilder bodyBuilder = new StringBuilder();
        bodyBuilder.append("--").append(boundary).append("\r\n");
        bodyBuilder.append("Content-Disposition: form-data; name=\"audio\"; filename=\"")
                .append(Paths.get(filename).getFileName().toString()).append("\"\r\n");
        bodyBuilder.append("Content-Type: audio/wav\r\n\r\n");

        byte[] formPrefix = bodyBuilder.toString().getBytes();
        byte[] formSuffix = ("\r\n--" + boundary + "--\r\n").getBytes();

        byte[] requestBody = new byte[formPrefix.length + audioBytes.length + formSuffix.length];
        System.arraycopy(formPrefix, 0, requestBody, 0, formPrefix.length);
        System.arraycopy(audioBytes, 0, requestBody, formPrefix.length, audioBytes.length);
        System.arraycopy(formSuffix, 0, requestBody, formPrefix.length + audioBytes.length, formSuffix.length);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(TRANSCRIPTION_URL))
                .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                .POST(HttpRequest.BodyPublishers.ofByteArray(requestBody))
                .timeout(Duration.ofSeconds(30))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 200) {
            JsonObject jsonResponse = gson.fromJson(response.body(), JsonObject.class);
            if (jsonResponse.get("success").getAsBoolean()) {
                return jsonResponse.get("transcription").getAsString();
            }
        }

        return null;
    }

    private String extractActionFromResponse(String responseBody) {
        if (responseBody == null || responseBody.isEmpty()) {
            return "wait";
        }

        // Extract action from TwiML response - simplified
        if (responseBody.contains("<Say") || responseBody.contains("<Play")) {
            return "action";
        }
        
        return "wait";
    }

    private String extractCallSidFromQuery(String query) {
        if (query == null || query.isEmpty()) {
            return null;
        }

        String[] params = query.split("&");
        for (String param : params) {
            String[] keyValue = param.split("=");
            if (keyValue.length == 2 && "callsid".equalsIgnoreCase(keyValue[0])) {
                return keyValue[1];
            }
        }
        return null;
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
        logger.error("WebSocket transport error: {}", exception.getMessage(), exception);
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus closeStatus) throws Exception {
        logger.info("WebSocket connection closed: {} - {}", session.getId(), closeStatus);
        // Cleanup will happen in handleStop when Twilio sends stop event
    }

    @Override
    public boolean supportsPartialMessages() {
        return false;
    }

    /**
     * Public method to resume streaming (called from controller after action completion)
     */
    public void resumeProcessingForStream(String streamSid) {
        resumeStreaming(streamSid);
    }

    /**
     * Public method to resume streaming with buffer clearing (called from controller after major actions)
     */
    public void resumeProcessingAfterAction(String streamSid) {
        // Clear accumulated transcript for major context changes
        accumulatedTranscripts.put(streamSid, new StringBuilder());
        resumeStreaming(streamSid);
    }
}
