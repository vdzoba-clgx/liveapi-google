package com.cotality.ivra.bots_service;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller to serve static resources like DTMF audio files
 */
@RestController
public class StaticResourceController {

    /**
     * Serves DTMF audio files from the classpath
     */
    @GetMapping("/dtmf/{filename}")
    public ResponseEntity<Resource> getDtmfAudio(@PathVariable String filename) {
        try {
            // Load the audio file from classpath resources
            Resource resource = new ClassPathResource("dtmf/" + filename);
            
            if (!resource.exists()) {
                return ResponseEntity.notFound().build();
            }

            // Set appropriate headers for audio file
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_TYPE, "audio/wav");
            headers.add(HttpHeaders.CACHE_CONTROL, "max-age=3600"); // Cache for 1 hour
            
            return new ResponseEntity<>(resource, headers, HttpStatus.OK);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
