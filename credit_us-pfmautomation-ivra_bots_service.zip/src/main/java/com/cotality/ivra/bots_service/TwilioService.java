package com.cotality.ivra.bots_service;

import com.twilio.Twilio;
import com.twilio.http.HttpMethod;
import com.twilio.rest.api.v2010.account.Application;
import com.twilio.rest.api.v2010.account.IncomingPhoneNumber;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;

/**
 * Service for interacting with Twilio API
 */
@Service
public class TwilioService {

    private static final Logger logger = LoggerFactory.getLogger(TwilioService.class);

    @Value("${twilio.account.sid:YOUR_TWILIO_ACCOUNT_SID_HERE}")
    private String accountSid;

    @Value("${twilio.auth.token:YOUR_TWILIO_AUTH_TOKEN_HERE}")
    private String authToken;

    @Value("${twilio.phone.number:+1234567890}")
    private String phoneNumber;
    @Value("${server.port:8080}")
    private String serverPort;

    /**
     * Initialize Twilio client
     */
    private void initializeTwilio() {
        if (!validateConfiguration()) {
            throw new RuntimeException(
                    "Twilio configuration is invalid. Please check your Account SID and Auth Token.");
        }

        logger.info("Initializing Twilio with Account SID: {}", accountSid);
        logger.info("Using auth token ending with: ...{}",
                authToken.length() > 4 ? authToken.substring(authToken.length() - 4) : "****");
        logger.info("Phone number configured: {}", phoneNumber);

        Twilio.init(accountSid, authToken);
        logger.info("Twilio client initialized successfully");
    }

    /**
     * Create or update TwiML application in Twilio using default configuration
     * 
     * @param webhookBaseUrl The base URL for webhooks (e.g.,
     *                       https://your-domain.com)
     * @return Application SID
     */
    public String createOrUpdateTwiMLApplication(String webhookBaseUrl) {
        // Default to inbound calls configuration
        return createOrUpdateTwiMLApplication(webhookBaseUrl, "inbound_calls_twiml.xml", false);
    }

    /**
     * Create or update TwiML application in Twilio with specified configuration
     * file
     * 
     * @param webhookBaseUrl The base URL for webhooks (e.g.,
     *                       https://your-domain.com)
     * @param configFile     The configuration file to use
     * @return Application SID
     */
    public String createOrUpdateTwiMLApplication(String webhookBaseUrl, String configFile) {
        return createOrUpdateTwiMLApplication(webhookBaseUrl, configFile, false);
    }

    /**
     * Create or update TwiML application in Twilio with specified configuration
     * file
     * 
     * @param webhookBaseUrl    The base URL for webhooks (e.g.,
     *                          https://your-domain.com)
     * @param configFile        The configuration file to use
     * @param attachPhoneNumber Whether to attach the phone number to this
     *                          application
     * @return Application SID
     */
    public String createOrUpdateTwiMLApplication(String webhookBaseUrl, String configFile, boolean attachPhoneNumber) {
        try {
            initializeTwilio();

            // Generate the voice URL based on the configuration file
            String voiceUrl;
            if (configFile.contains("outbound")) {
                // For outbound calls, use the outbound-initial endpoint
                voiceUrl = webhookBaseUrl + "/outbound/outbound-initial";
            } else {
                // For inbound calls, use the default ivr-main-menu endpoint
                voiceUrl = webhookBaseUrl + "/twiml/ivr-main-menu";
            }

            String statusCallbackUrl = webhookBaseUrl + "/twiml/status"; // Set application name based on config file
            String appName = configFile.replace("_twiml.xml", "").replace(".xml", "");
            if (configFile.contains("outbound")) {
                appName = "IVRA Outbound Calls";
            } else {
                appName = "IVRA Inbound Calls";
            }

            logger.info("Creating/updating TwiML application '{}' with voice URL: {} ({})",
                    appName, voiceUrl, configFile.contains("outbound") ? "Outbound Calls" : "Inbound Calls");

            // Check if application already exists
            Application existingApp = findExistingApplication(appName);
            Application app;

            if (existingApp != null) {
                // Update existing application
                app = Application.updater(existingApp.getSid())
                        .setVoiceUrl(URI.create(voiceUrl))
                        .setVoiceMethod(HttpMethod.POST)
                        .setStatusCallback(URI.create(statusCallbackUrl))
                        .setStatusCallbackMethod(HttpMethod.POST)
                        .update();
                logger.info("Updated existing application: {} (SID: {})", app.getFriendlyName(), app.getSid());
            } else {
                // Create new application
                app = Application.creator()
                        .setFriendlyName(appName)
                        .setVoiceUrl(URI.create(voiceUrl))
                        .setVoiceMethod(HttpMethod.POST)
                        .setStatusCallback(URI.create(statusCallbackUrl))
                        .setStatusCallbackMethod(HttpMethod.POST)
                        .create();
                logger.info("Created new application: {} (SID: {})", app.getFriendlyName(), app.getSid());
            }

            // Attach phone number if requested
            if (attachPhoneNumber) {
                updatePhoneNumberApplication(app.getSid(), voiceUrl);
            }

            return app.getSid();

        } catch (Exception e) {
            logger.error("Error creating/updating TwiML application: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to create/update TwiML application: " + e.getMessage(), e);
        }
    }

    /**
     * Find existing TwiML application by name
     * 
     * @param appName The application name to search for
     * @return Application if found, null otherwise
     */
    private Application findExistingApplication(String appName) {
        try {
            logger.info("Searching for existing application with name: {}", appName);

            // Read all applications and search for matching name
            for (Application app : Application.reader().read()) {
                if (appName.equals(app.getFriendlyName())) {
                    logger.info("Found matching application: {} (SID: {})", app.getFriendlyName(), app.getSid());
                    return app;
                }
            }

            logger.info("No application found with name: {}", appName);
            return null;

        } catch (Exception e) {
            logger.error("Error searching for existing application: {}", e.getMessage(), e);
            return null;
        }
    }

    /**
     * Update phone number to use the TwiML application
     * 
     * @param applicationSid The application SID
     * @param voiceUrl       The voice webhook URL
     */
    private void updatePhoneNumberApplication(String applicationSid, String voiceUrl) {
        try {
            logger.info("Updating phone number {} to use application {}", phoneNumber, applicationSid);

            // Find the phone number and update it
            for (IncomingPhoneNumber number : IncomingPhoneNumber.reader().read()) {
                if (phoneNumber.equals(number.getPhoneNumber().toString())) {
                    IncomingPhoneNumber.updater(number.getSid())
                            .setVoiceApplicationSid(applicationSid)
                            .setVoiceUrl(URI.create(voiceUrl))
                            .setVoiceMethod(HttpMethod.POST)
                            .update();

                    logger.info("Successfully updated phone number {} to use application {}", phoneNumber,
                            applicationSid);
                    return;
                }
            }

            logger.warn("Phone number {} not found in account", phoneNumber);

        } catch (Exception e) {
            logger.error("Error updating phone number: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to update phone number: " + e.getMessage(), e);
        }
    }

    /**
     * Test Twilio connection
     * 
     * @return true if connection is successful
     */
    public boolean testConnection() {
        try {
            initializeTwilio();

            // Try to read account information to test connection
            com.twilio.rest.api.v2010.Account account = com.twilio.rest.api.v2010.Account.fetcher(accountSid).fetch();
            logger.info("Twilio connection successful. Account status: {}", account.getStatus());
            return true;

        } catch (Exception e) {
            logger.error("Twilio connection failed: {}", e.getMessage(), e);
            return false;
        }
    }

    /**
     * Get application webhook URL based on current server configuration
     * 
     * @return The webhook base URL
     */
    public String getWebhookBaseUrl() {
        // Use ngrok domain for webhook callbacks
        // For production, this should be your actual production domain
        return "https://hagfish-evolving-rationally.ngrok-free.app";
    }

    /**
     * Validate Twilio configuration
     * 
     * @return true if configuration is valid
     */
    public boolean validateConfiguration() {
        logger.info("Validating Twilio configuration...");
        logger.info("Account SID: {}", accountSid);
        logger.info("Phone Number: {}", phoneNumber);

        if (accountSid == null || accountSid.trim().isEmpty() || accountSid.equals("YOUR_TWILIO_ACCOUNT_SID_HERE")) {
            logger.error("Twilio Account SID is not configured. Current value: {}", accountSid);
            return false;
        }

        if (authToken == null || authToken.trim().isEmpty() || authToken.equals("YOUR_TWILIO_AUTH_TOKEN_HERE")) {
            logger.error("Twilio Auth Token is not configured");
            return false;
        }

        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
            logger.error("Twilio phone number is not configured. Current value: {}", phoneNumber);
            return false;
        }

        logger.info("Twilio configuration is valid");
        return true;
    }

    /**
     * Get the configured phone number
     * 
     * @return The Twilio phone number
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Get the Twilio Account SID
     * @return The Twilio Account SID
     */
    public String getAccountSid() {
        return accountSid;
    }

    /**
     * Get the Twilio Auth Token
     * @return The Twilio Auth Token
     */
    public String getAuthToken() {
        return authToken;
    }

    /**
     * Make an AI-powered outbound call to a specified phone number with a specific
     * goal
     * 
     * @param toPhoneNumber The phone number to call
     * @param goal          The goal to achieve (e.g., "account_balance_inquiry")
     * @return The SID of the initiated call
     */
    public String makeAiOutboundCall(String toPhoneNumber, String goal) {
        try {
            initializeTwilio();            String webhookBaseUrl = getWebhookBaseUrl();            // Use the initial outbound endpoint with a goal parameter
            String callUrl = webhookBaseUrl + "/outbound/outbound-initial?goal=" + goal;

            logger.info("Making AI-powered outbound call from {} to {} with goal {} using webhook URL: {}",
                    phoneNumber, toPhoneNumber, goal, callUrl);

            com.twilio.rest.api.v2010.account.Call call = com.twilio.rest.api.v2010.account.Call.creator(
                    new com.twilio.type.PhoneNumber(toPhoneNumber), // To
                    new com.twilio.type.PhoneNumber(phoneNumber), // From
                    URI.create(callUrl)) // TwiML URL
                    .create();

            logger.info("Initiated AI-powered outbound call SID: {}", call.getSid());
            return call.getSid();

        } catch (Exception e) {
            logger.error("Error making AI-powered outbound call: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to make AI-powered outbound call: " + e.getMessage(), e);
        }
    }
    // AI outbound method removed as we're consolidating to one outbound app
}
