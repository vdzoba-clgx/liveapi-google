package com.cotality.ivra.bots_service.IVR;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.InitializingBean;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@Service
public class GoalHistoryService implements InitializingBean {
    private static final String HISTORY_FILE = "goal_history.json";
    private final Gson gson = new Gson();    @Override
    public void afterPropertiesSet() {
        // Make sure the history file exists
        try {
            File file = new File(HISTORY_FILE);
            if (!file.exists()) {
                file.createNewFile();
                saveHistory(new ArrayList<>());
            }
        } catch (IOException ignored) {}
    }

    public synchronized void saveHistory(List<GoalEntry> history) {
        try (FileWriter writer = new FileWriter(HISTORY_FILE)) {
            gson.toJson(history, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }    public synchronized List<GoalEntry> loadHistory() {
        try {
            File file = new File(HISTORY_FILE);
            if (!file.exists() || file.length() == 0) {
                return new ArrayList<>();
            }
            String json = new String(Files.readAllBytes(file.toPath()));
            if (json.trim().isEmpty()) {
                return new ArrayList<>();
            }
            List<GoalEntry> history = gson.fromJson(json, new TypeToken<List<GoalEntry>>(){}.getType());
            return history != null ? history : new ArrayList<>();
        } catch (Exception e) {
            e.printStackTrace(); // Log the exception for debugging
            return new ArrayList<>();
        }
    }

    public static class GoalEntry {
        public String goal;
        public List<Step> steps;
        public GoalEntry(String goal, List<Step> steps) {
            this.goal = goal;
            this.steps = steps;
        }
    }
    public static class Step {
        public int stepNumber;
        public String prompt;
        public String expectedAction;
        public Step(int stepNumber, String prompt, String expectedAction) {
            this.stepNumber = stepNumber;
            this.prompt = prompt;
            this.expectedAction = expectedAction;
        }
    }
}
