package com.cotality.ivra.bots_service.IVR;

/**
 * Interface for resolving actions based on IVR prompts and context.
 * This allows different implementations for determining what action to take
 * when the IVR system presents a prompt to the user.
 */
public interface IActionResolver {
    
    /**
     * Resolve the appropriate action to take based on the IVR prompt and current context.
     * 
     * @param prompt The prompt/message from the IVR system
     * @param context Additional context about the current state (e.g., step description, goal)
     * @param stepNumber The current step number in the navigation sequence
     * @param totalSteps The total number of steps in the navigation sequence
     * @return The action to execute (e.g., "press.1", "wait", "press.last_4_ssn", etc.)
     */
    String resolveAction(String prompt, String context, int stepNumber, int totalSteps);
    
    /**
     * Get a human-readable name for this action resolver implementation.
     * 
     * @return The name of this resolver (e.g., "Simulation", "AI-Driven", etc.)
     */
    String getResolverName();
    
    /**
     * Check if this resolver can handle the given prompt and context.
     * This allows for fallback mechanisms when one resolver cannot handle a situation.
     * 
     * @param prompt The prompt from the IVR system
     * @param context Additional context about the current state
     * @return true if this resolver can handle the prompt, false otherwise
     */
    default boolean canHandle(String prompt, String context) {
        return true; // Default implementation accepts all prompts
    }
}
