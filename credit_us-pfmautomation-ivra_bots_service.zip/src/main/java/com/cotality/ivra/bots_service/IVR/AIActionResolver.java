package com.cotality.ivra.bots_service.IVR;

import com.cotality.ivra.bots_service.AI.AiController;
import com.cotality.ivra.bots_service.MenuLoader;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * AI-based action resolver that will use artificial intelligence
 * to determine the appropriate action for IVR prompts.
 * Extends BaseActionResolver to reuse common menu navigation logic.
 * Falls back to simulation logic when AI is not available.
 */
@Component
public class AIActionResolver extends BaseActionResolver {

    @Autowired
    private AiController aiController;

    @Autowired
    private MenuLoader menuLoader;

    @Override
    public String resolveAction(String prompt, String context) {
        return resolveAction(prompt, context, null);
    }

    @Override
    public String resolveAction(String prompt, String context, String targetGoal) {
        try {
            // Try AI-based resolution first
            String aiAction = resolveUsingAI(prompt, context, targetGoal);
            if (aiAction != null && !aiAction.trim().isEmpty()) {
                return aiAction.trim();
            }
        } catch (Exception e) {
            // If AI fails, fall back to base resolver
            System.err.println("AI resolution failed: " + e.getMessage());
        }

        // Fallback to base resolver
        return resolveActionCore(prompt, context, targetGoal);
    }

    /**
     * Use AI to resolve the action based on the prompt and goal
     */
    public String resolveUsingAI(String prompt, String context, String targetGoal) throws IOException {
        // Load the prompt template from resources
        String promptTemplate;
        try {
            // Load the template as text from resources (loadJsonFromResources actually
            // loads any text file)
            promptTemplate = menuLoader.loadJsonFromResources("prompt_template.txt");
        } catch (Exception e) {
            // Fallback to file system path
            String templatePath = "src/main/java/com/cotality/ivra/bots_service/IVR/prompt_template.txt";
            promptTemplate = new String(Files.readAllBytes(Paths.get(templatePath)));
        }

        // Get goal description from goals.json
        String goalDescription = getGoalDescription(targetGoal);
        // Replace template variables
        String aiPrompt = promptTemplate
                .replace("{IVR_PROMPT}", prompt != null ? prompt : "")
                .replace("{GOAL_DESCRIPTION}", goalDescription);
        // Call AI service through AiController to store in history
        var messageHistory = aiController.sendMessage(aiPrompt);

        // Get the last AI response from the history
        String aiResponse = null;
        if (messageHistory != null && !messageHistory.isEmpty()) {
            // Find the last AI message in the history
            for (int i = messageHistory.size() - 1; i >= 0; i--) {
                var message = messageHistory.get(i);
                if ("ai".equals(message.role)) {
                    aiResponse = message.content;
                    break;
                }
            }
        } 
        // Parse the response - should be a single action like "press.1" or "wait"
        // Log the prompt and AI response for debugging
        System.out.println("--- AI DECISION PROCESS ---");
        System.out.println("IVR Prompt: " + prompt);
        System.out.println("Goal: " + targetGoal);
        System.out.println("AI Response: " + aiResponse);
        System.out.println("-------------------------");

        return aiResponse;
    }

    /**
     * Get goal description from goals.json
     */
    private String getGoalDescription(String targetGoal) {
        if (targetGoal == null || targetGoal.trim().isEmpty()) {
            return "Unknown goal";
        }

        try {
            String goalsContent = menuLoader.loadJsonFromResources("goals.json");
            Gson gson = new Gson();
            JsonObject goalsJson = gson.fromJson(goalsContent, JsonObject.class);

            if (goalsJson.has(targetGoal)) {
                return goalsJson.get(targetGoal).getAsString();
            }
        } catch (Exception e) {
            System.err.println("Failed to load goal description: " + e.getMessage());
        }

        return targetGoal.replace("_", " ");
    }

    @Override
    public String getResolverName() {
        return "AIActionResolver";
    }
}
