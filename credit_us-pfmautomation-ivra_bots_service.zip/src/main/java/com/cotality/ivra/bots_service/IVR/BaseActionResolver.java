package com.cotality.ivra.bots_service.IVR;

import com.cotality.ivra.bots_service.MenuLoader;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Base abstract class containing shared action resolution logic.
 * Provides menu loading, prompt mapping, and goal-aware navigation functionality
 * that can be reused by different ActionResolver implementations.
 */
public abstract class BaseActionResolver implements ActionResolver {
    
    @Autowired
    private MenuLoader menuLoader;
    
    @Autowired
    private IvrNavigationService navigationService;
    
    @Value("${bofa_ivr_menu_actual}")
    private String actualMenuFileName;
    
    protected Map<String, String> promptToActionMap = new HashMap<>();
    protected JsonObject actualMenuData;
    
    @PostConstruct
    public void initialize() {
        try {
            loadActualMenuData();
            buildPromptToActionMap();
        } catch (IOException e) {
            throw new RuntimeException("Failed to initialize BaseActionResolver: " + e.getMessage(), e);
        }
    }
    
    private void loadActualMenuData() throws IOException {
        String actualMenuContent = menuLoader.loadJsonFromResources(actualMenuFileName);
        // Use Gson directly since parseJsonFromString doesn't exist in MenuLoader
        com.google.gson.Gson gson = new com.google.gson.Gson();
        actualMenuData = gson.fromJson(actualMenuContent, JsonObject.class);
    }
    
    private void buildPromptToActionMap() {
        if (actualMenuData == null) return;
        
        JsonObject ivrSystem = actualMenuData.getAsJsonObject("ivrSystem");
        if (ivrSystem == null) return;
        
        // Extract step definitions
        JsonObject stepDefinitions = ivrSystem.getAsJsonObject("stepDefinitions");
        if (stepDefinitions != null) {
            for (String stepId : stepDefinitions.keySet()) {
                JsonObject stepDef = stepDefinitions.getAsJsonObject(stepId);
                if (stepDef.has("prompt") && stepDef.has("action")) {
                    String prompt = stepDef.get("prompt").getAsString();
                    String action = stepDef.get("action").getAsString();
                    promptToActionMap.put(prompt.toLowerCase(), action);
                }
            }
        }
        
        // Extract from main menu structure
        JsonObject mainMenu = ivrSystem.getAsJsonObject("stepDefinitions").getAsJsonObject("mainMenu");
        if (mainMenu != null && mainMenu.has("options")) {
            extractActionsFromMenuOptions(mainMenu.getAsJsonObject("options"));
        }
    }
      private void extractActionsFromMenuOptions(JsonObject options) {
        for (String key : options.keySet()) {
            JsonElement element = options.get(key);
            if (element.isJsonObject()) {
                JsonObject option = element.getAsJsonObject();
                
                // Extract prompt and action from this option
                if (option.has("prompt")) {
                    String prompt = option.get("prompt").getAsString();
                    String action;
                    
                    if (option.has("action")) {
                        action = option.get("action").getAsString();
                    } else {
                        // If no explicit action, default to "wait" for menu items with subOptions
                        action = "wait";
                    }
                    
                    promptToActionMap.put(prompt.toLowerCase(), action);
                }
                
                // Recursively process subMenu
                if (option.has("subMenu")) {
                    extractActionsFromMenuOptions(option.getAsJsonObject("subMenu"));
                }
                
                // Recursively process subOptions
                if (option.has("subOptions")) {
                    extractActionsFromSubOptions(option.getAsJsonObject("subOptions"));
                }
            }
        }
    }
      private void extractActionsFromSubOptions(JsonObject subOptions) {
        for (String key : subOptions.keySet()) {
            JsonElement element = subOptions.get(key);
            if (element.isJsonObject()) {
                JsonObject subOption = element.getAsJsonObject();
                
                // Extract action from goal-based sub-options
                if (subOption.has("action") && subOption.has("description")) {
                    String description = subOption.get("description").getAsString();
                    String action = subOption.get("action").getAsString();
                    promptToActionMap.put(description.toLowerCase(), action);
                    
                    // Also map description to navigation action (press.key)
                    promptToActionMap.put(description.toLowerCase() + "_nav", "press." + key);
                }
                
                // If this sub-option has its own prompt, map it too
                if (subOption.has("prompt") && subOption.has("action")) {
                    String prompt = subOption.get("prompt").getAsString();
                    String action = subOption.get("action").getAsString();
                    promptToActionMap.put(prompt.toLowerCase(), action);
                }
            }
        }
    }    /**
     * Core action resolution logic that can be used by subclasses.
     * Handles exact matching, partial matching, and goal-aware navigation.
     */    protected String resolveActionCore(String prompt, String context, String targetGoal) {
        if (prompt == null || prompt.trim().isEmpty()) {
            throw new RuntimeException("Cannot resolve action for null or empty prompt");
        }
        
        String lowerPrompt = prompt.toLowerCase();

        // PRIORITIZE GOAL-AWARE NAVIGATION when we have a target goal
        // This ensures we use the correct actions from the navigation path generation
        if (targetGoal != null && actualMenuData != null) {
            String dynamicAction = resolveGoalAwareActionUsingService(prompt, context, targetGoal);
            if (dynamicAction != null) {
                return dynamicAction;
            }
        }        // Special handling for navigation context - when context suggests we're navigating TO an option
        if (context != null && (context.contains("menu") || context.contains("main"))) {
            // Try navigation action first
            String navAction = promptToActionMap.get(lowerPrompt + "_nav");
            if (navAction != null) {
                return navAction;
            }
        }

        // Try exact match with loaded prompts (fallback)
        String exactAction = promptToActionMap.get(lowerPrompt);
        if (exactAction != null) {
            return exactAction;
        }

        // Try partial matching for dynamic prompts
        for (Map.Entry<String, String> entry : promptToActionMap.entrySet()) {
            String storedPrompt = entry.getKey();
            String action = entry.getValue();
            // Skip navigation entries for partial matching
            if (storedPrompt.endsWith("_nav")) continue;
            if (lowerPrompt.contains(storedPrompt) || storedPrompt.contains(lowerPrompt)) {
                return action;
            }
        }        throw new RuntimeException("Could not resolve action for prompt: '" + prompt + "' with context: '" + context + "'. No matching action found in menu structure.");
    }/**
     * Resolve action using IvrNavigationService for goal-aware navigation.
     * This method finds the correct menu step and determines the appropriate action.
     */
    private String resolveGoalAwareActionUsingService(String prompt, String context, String targetGoal) {
        try {
            // Use the new unified action resolution method from navigationService
            if (navigationService != null) {
                String resolvedAction = navigationService.resolveActionForPromptAndGoal(prompt, context, targetGoal);
                if (resolvedAction != null) {
                    return resolvedAction;
                }
            }
            
            // Fallback to the old logic if the new method doesn't work
            if (navigationService != null && actualMenuData != null) {
                JsonObject ivrSystem = actualMenuData.getAsJsonObject("ivrSystem");
                if (ivrSystem != null && ivrSystem.has("stepDefinitions")) {
                    JsonObject stepDefinitions = ivrSystem.getAsJsonObject("stepDefinitions");
                    for (String stepId : stepDefinitions.keySet()) {
                        JsonObject stepDef = stepDefinitions.getAsJsonObject(stepId);
                        if (stepDef.has("prompt") && prompt.equals(stepDef.get("prompt").getAsString())) {
                            // If this is a navigation menu (no explicit action), use navigationService
                            if (!stepDef.has("action") && stepDef.has("options")) {
                                return navigationService.findNavigationActionForGoal(stepDef, targetGoal);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            // If service fails, return null to try other resolution methods
            return null;
        }
        return null;
    }
}
