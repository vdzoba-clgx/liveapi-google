package com.cotality.ivra.bots_service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import com.twilio.twiml.VoiceResponse;
import com.twilio.twiml.voice.Gather;
import com.twilio.twiml.voice.Say;
import com.twilio.twiml.voice.Redirect;
import com.twilio.twiml.voice.Dial;

/**
 * Controller for handling Twilio webhook requests
 */
@RestController
@RequestMapping("/twiml")
public class HandleUserResponseController {

    private static final Logger logger = LoggerFactory.getLogger(HandleUserResponseController.class);

    @Autowired
    private TwiMLGeneratorService twiMLGeneratorService;

    /**
     * Handles incoming calls that should be directed to the IVR system
     */
    @PostMapping(value = "/ivr-main-menu", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleIvrCall() {
        logger.info("Received incoming IVR call webhook");
        try {
            // Redirect to the IVR speech menu
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/ivr-speech-menu</Redirect></Response>";
        } catch (Exception e) {
            logger.error("Error handling IVR call: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles the speech input from user
     * 
     * @param speechResult The transcribed speech result from Twilio
     */
    @PostMapping(value = "/handle-speech", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleSpeechInput(@RequestParam(value = "SpeechResult", required = false) String speechResult) {
        logger.info("Received speech input: {}", speechResult);
        try {
            // Redirect to IVR speech menu instead of echo response
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/ivr-speech-menu</Redirect></Response>";
        } catch (Exception e) {
            logger.error("Error generating TwiML: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles call status callbacks
     */
    @PostMapping("/status")
    public void handleStatusCallback(
            @RequestParam("CallStatus") String callStatus,
            @RequestParam("CallSid") String callSid) {
        logger.info("Call status update - SID: {}, Status: {}", callSid, callStatus);
    }

    /**
     * Redirect base /twiml path to the main menu
     */
    @GetMapping(produces = MediaType.APPLICATION_XML_VALUE)
    public String redirectToMainMenu() {
        logger.info("Received request to base /twiml path, redirecting to main flow");
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/main-menu</Redirect></Response>";
    }

    /**
     * Handles GET request for the main menu (useful for Twilio webhook validation)
     */
    @GetMapping(value = "/main-menu", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleMainMenuGet() {
        logger.info("Received GET request to main-menu");
        try {
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/ivr-main-menu</Redirect></Response>";
        } catch (Exception e) {
            logger.error("Error generating TwiML for GET request: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles POST request for the main menu
     * This is the entry point for all inbound calls and should follow the sequence:
     * welcome -> language -> authentication -> main menu
     */
    @PostMapping(value = "/main-menu", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleMainMenuPost() {
        logger.info("Received POST request to main-menu - Starting full call flow");
        try {
            // Return the welcome message and begin the proper sequence
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .say(new Say.Builder(
                            "Thank you for calling Bank of America. Your call may be monitored or recorded for quality assurance purposes.")
                            .voice(Say.Voice.POLLY_JOANNA)
                            .build())
                    .pause(new com.twilio.twiml.voice.Pause.Builder().length(1).build())
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(5)
                            .action("/twiml/language")
                            .say(new Say.Builder(
                                    "Para continuar en español, presione 2. To continue in English, stay on the line.")
                                    .voice(Say.Voice.POLLY_JOANNA)
                                    .build())
                            .build())
                    .redirect(new Redirect.Builder("/twiml/authentication").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error generating TwiML for main menu: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles language selection
     */
    @PostMapping(value = "/language", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleLanguageSelection(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Received language selection: {}", digits);
        try {
            // For now, we'll just redirect to authentication regardless of selection
            // In a real system, you might set a language preference here
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/authentication</Redirect></Response>";
        } catch (Exception e) {
            logger.error("Error handling language selection: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles authentication step
     */
    @PostMapping(value = "/authentication", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleAuthentication() {
        logger.info("Handling authentication step");
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(new Gather.Builder()
                            .numDigits(4)
                            .timeout(10)
                            .action("/twiml/authenticate")
                            .say(new Say.Builder(
                                    "Please enter the last 4 digits of your Social Security Number")
                                    .voice(Say.Voice.POLLY_JOANNA)
                                    .build())
                            .build())
                    .say(new Say.Builder("I'm sorry, I didn't receive your input.")
                            .voice(Say.Voice.POLLY_JOANNA)
                            .build())
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(5)
                            .action("/twiml/alt-auth")
                            .say(new Say.Builder(
                                    "If you don't have your Social Security Number available, press the star key to enter your 16-digit debit or credit card number.")
                                    .voice(Say.Voice.POLLY_JOANNA)
                                    .build())
                            .build())
                    .say(new Say.Builder("If you don't have this information, press 0 to speak with a representative.")
                            .voice(Say.Voice.POLLY_JOANNA)
                            .build())
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(5)
                            .action("/twiml/connect-rep")
                            .build())
                    .redirect(new Redirect.Builder("/twiml/connect-rep").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error handling authentication step: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles SSN authentication verification
     */
    @PostMapping(value = "/authenticate", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleAuthenticationVerification(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Received authentication input: {}", digits != null ? "****" : "null");
        try {
            // In a real system, you would verify the credentials
            // For this demo, we'll just redirect to the actual main menu after
            // authentication
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/actual-main-menu</Redirect></Response>";
        } catch (Exception e) {
            logger.error("Error handling authentication verification: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles alternative authentication
     */
    @PostMapping(value = "/alt-auth", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleAlternativeAuthentication(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Handling alternative authentication with input: {}", digits != null ? "****" : "null");
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(new Gather.Builder()
                            .numDigits(16)
                            .timeout(15)
                            .action("/twiml/authenticate")
                            .say(new Say.Builder(
                                    "Please enter your 16-digit debit or credit card number.")
                                    .voice(Say.Voice.POLLY_JOANNA)
                                    .build())
                            .build())
                    .redirect(new Redirect.Builder("/twiml/connect-rep").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error handling alternative authentication: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles main menu
     */
    @PostMapping(value = "/process-main-menu", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleProcessMainMenu(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing main menu selection: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/account-balances</Redirect></Response>";
            } else if ("2".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/credit-card-services</Redirect></Response>";
            } else if ("0".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/connect-rep</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.")
                                .voice(Say.Voice.POLLY_JOANNA)
                                .build())
                        .redirect(new Redirect.Builder("/twiml/actual-main-menu").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error processing main menu: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles account services menu
     */
    @PostMapping(value = "/account-services", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleAccountServices() {
        logger.info("Handling account services menu");
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(10)
                            .action("/twiml/account-services-handler").say(new Say.Builder(
                                    "Account services. Press 1 for account balances. Press 2 for recent transactions. Press 3 for account status. Press 9 to return to the main menu.")
                                    .voice(Say.Voice.POLLY_JOANNA)
                                    .build())
                            .build())
                    .say(new Say.Builder("I didn't receive your selection.")
                            .voice(Say.Voice.POLLY_JOANNA)
                            .build())
                    .redirect(new Redirect.Builder("/twiml/account-services").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error handling account services: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles account services menu selection
     */
    @PostMapping(value = "/account-services-handler", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleAccountServicesSelection(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing account services selection: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/account-balances</Redirect></Response>";
            } else if ("2".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/recent-transactions</Redirect></Response>";
            } else if ("3".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/account-status</Redirect></Response>";
            } else if ("9".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/actual-main-menu</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.")
                                .voice(Say.Voice.POLLY_JOANNA)
                                .build())
                        .redirect(new Redirect.Builder("/twiml/account-services").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error processing account services selection: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles connect to representative
     */
    @PostMapping(value = "/connect-rep", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleConnectRepresentative() {
        logger.info("Connecting to a representative");
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .say(new Say.Builder("Please hold while we connect you to a representative.")
                            .voice(Say.Voice.POLLY_JOANNA)
                            .build())
                    .dial(new Dial.Builder("+18005551234").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error connecting to representative: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Credit card services menu
     */
    @PostMapping(value = "/credit-card-services", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleCreditCardServices() {
        logger.info("Handling credit card services menu");
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(10)
                            .action("/twiml/credit-card-services-handler").say(new Say.Builder(
                                    "Credit card services. Press 1 for account information. Press 2 for payment services. Press 3 for credit information. Press 9 to return to the main menu.")
                                    .voice(Say.Voice.POLLY_JOANNA)
                                    .build())
                            .build())
                    .say(new Say.Builder("I didn't receive your selection.")
                            .voice(Say.Voice.POLLY_JOANNA)
                            .build())
                    .redirect(new Redirect.Builder("/twiml/credit-card-services").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error handling credit card services: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles credit card services menu selection
     */
    @PostMapping(value = "/credit-card-services-handler", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleCreditCardServicesSelection(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing credit card services selection: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/credit-card-account-info</Redirect></Response>";
            } else if ("2".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/payment-services</Redirect></Response>";
            } else if ("3".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/credit-information</Redirect></Response>";
            } else if ("9".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/actual-main-menu</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.")
                                .voice(Say.Voice.POLLY_JOANNA)
                                .build())
                        .redirect(new Redirect.Builder("/twiml/credit-card-services").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error processing credit card services selection: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles account balances menu
     */
    @PostMapping(value = "/account-balances", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleAccountBalances() {
        logger.info("Handling account balances menu");
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(10)
                            .action("/twiml/account-balances-handler")
                            .say(new Say.Builder(
                                    "Account balances. Press 1 for current account balance. Press 2 for statement balance. Press 9 to return to account services.")
                                    .build())
                            .build())
                    .say(new Say.Builder("I didn't receive your selection.").build())
                    .redirect(new Redirect.Builder("/twiml/account-balances").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error handling account balances: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles account balances selection
     */
    @PostMapping(value = "/account-balances-handler", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleAccountBalancesSelection(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing account balances selection: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/current-account-balance</Redirect></Response>";
            } else if ("2".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/statement-balance</Redirect></Response>";
            } else if ("9".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/account-services</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.").build())
                        .redirect(new Redirect.Builder("/twiml/account-balances").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error processing account balances selection: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles current account balance
     */
    @PostMapping(value = "/current-account-balance", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleCurrentAccountBalance() {
        logger.info("Handling current account balance");
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(10)
                            .action("/twiml/account-balance-options")
                            .say(new Say.Builder(
                                    "Your account balance is $100.15. Press 1 to hear the current balance again. Press 2 for statement balance information. Press 9 to return to account services.")
                                    .build())
                            .build())
                    .say(new Say.Builder("I didn't receive your selection.").build())
                    .redirect(new Redirect.Builder("/twiml/current-account-balance").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error handling current account balance: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles account balance options
     */
    @PostMapping(value = "/account-balance-options", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleAccountBalanceOptions(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing account balance options: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/current-account-balance</Redirect></Response>";
            } else if ("2".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/statement-balance</Redirect></Response>";
            } else if ("9".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/account-services</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.").build())
                        .redirect(new Redirect.Builder("/twiml/current-account-balance").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error processing account balance options: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles statement balance
     */
    @PostMapping(value = "/statement-balance", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleStatementBalance() {
        logger.info("Handling statement balance");
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(10)
                            .action("/twiml/statement-balance-options")
                            .say(new Say.Builder(
                                    "Your statement balance information is $567.87. Press 1 to hear the statement balance again. Press 9 to return to account services.")
                                    .build())
                            .build())
                    .say(new Say.Builder("I didn't receive your selection.").build())
                    .redirect(new Redirect.Builder("/twiml/statement-balance").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error handling statement balance: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles statement balance options
     */
    @PostMapping(value = "/statement-balance-options", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleStatementBalanceOptions(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing statement balance options: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/statement-balance</Redirect></Response>";
            } else if ("9".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/account-services</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.").build())
                        .redirect(new Redirect.Builder("/twiml/statement-balance").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error processing statement balance options: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles account status menu
     */
    @PostMapping(value = "/account-status-handler", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleAccountStatusSelection(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing account status selection: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/account-status-check</Redirect></Response>";
            } else if ("2".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/autopay-status</Redirect></Response>";
            } else if ("9".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/account-services</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.").build())
                        .redirect(new Redirect.Builder("/twiml/account-status").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error processing account status selection: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles account status check
     */
    @PostMapping(value = "/account-status-check", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleAccountStatusCheck() {
        logger.info("Handling account status check");
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(10)
                            .action("/twiml/account-status-options")
                            .say(new Say.Builder(
                                    "The account is past due by 30 days. Press 1 to hear the account status again. Press 2 for autopay status. Press 9 to return to account services.")
                                    .build())
                            .build())
                    .say(new Say.Builder("I didn't receive your selection.").build())
                    .redirect(new Redirect.Builder("/twiml/account-status-check").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error handling account status check: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles account status options
     */
    @PostMapping(value = "/account-status-options", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleAccountStatusOptions(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing account status options: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/account-status-check</Redirect></Response>";
            } else if ("2".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/autopay-status</Redirect></Response>";
            } else if ("9".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/account-services</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.").build())
                        .redirect(new Redirect.Builder("/twiml/account-status-check").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error processing account status options: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles credit card account info handler
     */
    @PostMapping(value = "/credit-card-account-info-handler", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleCreditCardAccountInfoSelection(
            @RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing credit card account info selection: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/current-balance</Redirect></Response>";
            } else if ("2".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/available-credit</Redirect></Response>";
            } else if ("3".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/recent-transactions</Redirect></Response>";
            } else if ("4".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/payment-info</Redirect></Response>";
            } else if ("5".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/rewards-balance</Redirect></Response>";
            } else if ("9".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/credit-card-services</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.").build())
                        .redirect(new Redirect.Builder("/twiml/credit-card-account-info").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error processing credit card account info selection: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles available credit
     */
    @PostMapping(value = "/available-credit", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleAvailableCredit() {
        logger.info("Handling available credit");
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(10)
                            .action("/twiml/available-credit-options")
                            .say(new Say.Builder(
                                    "Available credit limit is 12,000 dollars. Press 1 to hear the available credit again. Press 9 to return to credit card services.")
                                    .build())
                            .build())
                    .say(new Say.Builder("I didn't receive your selection.").build())
                    .redirect(new Redirect.Builder("/twiml/available-credit").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error handling available credit: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles available credit options
     */
    @PostMapping(value = "/available-credit-options", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleAvailableCreditOptions(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing available credit options: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/available-credit</Redirect></Response>";
            } else if ("9".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/credit-card-services</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.").build())
                        .redirect(new Redirect.Builder("/twiml/available-credit").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error handling available credit options: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles payment services handler
     */
    @PostMapping(value = "/payment-services-handler", produces = MediaType.APPLICATION_XML_VALUE)
    public String handlePaymentServicesSelection(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing payment services selection: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/minimum-payment-due</Redirect></Response>";
            } else if ("2".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/payment-processing</Redirect></Response>";
            } else if ("3".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/last-payment-date</Redirect></Response>";
            } else if ("4".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/payment-amount-verification</Redirect></Response>";
            } else if ("9".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/credit-card-services</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.").build())
                        .redirect(new Redirect.Builder("/twiml/payment-services").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error processing payment services selection: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles minimum payment due
     */
    @PostMapping(value = "/minimum-payment-due", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleMinimumPaymentDue() {
        logger.info("Handling minimum payment due");
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(10)
                            .action("/twiml/minimum-payment-due-options")
                            .say(new Say.Builder(
                                    "Minimum payment amount is 1500 dollars. Press 1 to hear the minimum payment again. Press 9 to return to payment services.")
                                    .build())
                            .build())
                    .say(new Say.Builder("I didn't receive your selection.").build())
                    .redirect(new Redirect.Builder("/twiml/minimum-payment-due").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error handling minimum payment due: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles minimum payment due options
     */
    @PostMapping(value = "/minimum-payment-due-options", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleMinimumPaymentDueOptions(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing minimum payment due options: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/minimum-payment-due</Redirect></Response>";
            } else if ("9".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/payment-services</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.").build())
                        .redirect(new Redirect.Builder("/twiml/minimum-payment-due").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error handling minimum payment due options: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles last payment date
     */
    @PostMapping(value = "/last-payment-date", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleLastPaymentDate() {
        logger.info("Handling last payment date");
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(10)
                            .action("/twiml/last-payment-date-options")
                            .say(new Say.Builder(
                                    "Date of the most recent payment made on the account is June 6 2025. Press 1 to hear the last payment date again. Press 9 to return to payment services.")
                                    .build())
                            .build())
                    .say(new Say.Builder("I didn't receive your selection.").build())
                    .redirect(new Redirect.Builder("/twiml/last-payment-date").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error handling last payment date: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles last payment date options
     */
    @PostMapping(value = "/last-payment-date-options", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleLastPaymentDateOptions(@RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing last payment date options: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/last-payment-date</Redirect></Response>";
            } else if ("9".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/payment-services</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.").build())
                        .redirect(new Redirect.Builder("/twiml/last-payment-date").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error handling last payment date options: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles payment amount verification
     */
    @PostMapping(value = "/payment-amount-verification", produces = MediaType.APPLICATION_XML_VALUE)
    public String handlePaymentAmountVerification() {
        logger.info("Handling payment amount verification");
        try {
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(10)
                            .action("/twiml/payment-amount-verification-options")
                            .say(new Say.Builder(
                                    "The most recent payment amount was $50.00. Press 1 to hear the payment amount again. Press 9 to return to payment services.")
                                    .build())
                            .build())
                    .say(new Say.Builder("I didn't receive your selection.").build())
                    .redirect(new Redirect.Builder("/twiml/payment-amount-verification").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error handling payment amount verification: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles payment amount verification options
     */
    @PostMapping(value = "/payment-amount-verification-options", produces = MediaType.APPLICATION_XML_VALUE)
    public String handlePaymentAmountVerificationOptions(
            @RequestParam(value = "Digits", required = false) String digits) {
        logger.info("Processing payment amount verification options: {}", digits);
        try {
            if ("1".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/payment-amount-verification</Redirect></Response>";
            } else if ("9".equals(digits)) {
                return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response><Redirect>/twiml/payment-services</Redirect></Response>";
            } else {
                VoiceResponse voiceResponse = new VoiceResponse.Builder()
                        .say(new Say.Builder("Invalid selection.").build())
                        .redirect(new Redirect.Builder("/twiml/payment-amount-verification").build())
                        .build();

                return voiceResponse.toXml();
            }
        } catch (Exception e) {
            logger.error("Error handling payment amount verification options: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

    /**
     * Handles the actual main menu options after authentication
     */
    @PostMapping(value = "/actual-main-menu", produces = MediaType.APPLICATION_XML_VALUE)
    public String handleActualMainMenu() {
        logger.info("Handling actual main menu options after authentication");
        try {
            // Return the main menu options based on bofa_ivr_menu.json structure
            VoiceResponse voiceResponse = new VoiceResponse.Builder()
                    .gather(new Gather.Builder()
                            .numDigits(1)
                            .timeout(10)
                            .action("/twiml/process-main-menu")
                            .say(new Say.Builder(
                                    "Main menu. Please listen carefully as our options have changed. Press 1 for account balance, account status and statement balance. Press 2 for credit card and payment services. Press 0 to speak with a representative immediately.")
                                    .build())
                            .build())
                    .say(new Say.Builder("I didn't receive your selection.").build())
                    .redirect(new Redirect.Builder("/twiml/actual-main-menu").build())
                    .build();

            return voiceResponse.toXml();
        } catch (Exception e) {
            logger.error("Error generating TwiML for actual main menu: {}", e.getMessage(), e);
            return twiMLGeneratorService.generateErrorTwiML();
        }
    }

}