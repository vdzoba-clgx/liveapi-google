package com.cotality.ivra.bots_service.stt;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.core.io.ByteArrayResource;

import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.Map;

@Service
public class PythonSTTService {
    private static final Logger logger = Logger.getLogger(PythonSTTService.class.getName());

    @Value("${python.stt.service.url:http://localhost:5000}")
    private String pythonSTTServiceUrl;

    @Value("${python.stt.service.enabled:true}")
    private boolean enabled;

    @Value("${python.stt.service.timeout:30000}")
    private int timeoutMs;

    private final RestTemplate restTemplate;

    public PythonSTTService() {
        this.restTemplate = new RestTemplate();
    }

    public TranscriptionResult transcribeAudio(byte[] audioData) {
        if (!enabled) {
            return new TranscriptionResult("", 0, 0, false, "Python STT service is disabled");
        }

        long startTime = System.currentTimeMillis();

        try {
            // Prepare multipart request
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);

            MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
            ByteArrayResource audioResource = new ByteArrayResource(audioData) {
                @Override
                public String getFilename() {
                    return "audio.wav";
                }
            };
            body.add("audio", audioResource);

            HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);

            // Make request to Python service
            String transcribeUrl = pythonSTTServiceUrl + "/transcribe";
            logger.info("Sending audio to Python STT service: " + transcribeUrl);

            ResponseEntity<Map> response = restTemplate.exchange(
                    transcribeUrl,
                    HttpMethod.POST,
                    requestEntity,
                    Map.class);

            long processingTime = System.currentTimeMillis() - startTime;

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                Map<String, Object> responseBody = response.getBody();

                String transcription = (String) responseBody.get("transcription");
                Boolean success = (Boolean) responseBody.get("success");
                Double audioDuration = responseBody.get("duration") != null
                        ? ((Number) responseBody.get("duration")).doubleValue()
                        : 0.0;

                if (success != null && success) {
                    logger.info(String.format("Python STT transcription successful in %dms: '%s'",
                            processingTime, transcription));
                    return new TranscriptionResult(transcription, processingTime, audioDuration, true);
                } else {
                    String error = (String) responseBody.get("error");
                    logger.warning("Python STT transcription failed: " + error);
                    return new TranscriptionResult("", processingTime, audioDuration, false, error);
                }
            } else {
                String error = "Python STT service returned status: " + response.getStatusCode();
                logger.warning(error);
                return new TranscriptionResult("", processingTime, 0, false, error);
            }

        } catch (ResourceAccessException e) {
            long processingTime = System.currentTimeMillis() - startTime;
            String error = "Python STT service unavailable: " + e.getMessage();
            logger.log(Level.SEVERE, error, e);
            return new TranscriptionResult("", processingTime, 0, false, error);
        } catch (Exception e) {
            long processingTime = System.currentTimeMillis() - startTime;
            String error = "Python STT service error: " + e.getMessage();
            logger.log(Level.SEVERE, error, e);
            return new TranscriptionResult("", processingTime, 0, false, error);
        }
    }

    public boolean isServiceAvailable() {
        if (!enabled) {
            return false;
        }

        try {
            String healthUrl = pythonSTTServiceUrl + "/health";
            ResponseEntity<Map> response = restTemplate.getForEntity(healthUrl, Map.class);
            return response.getStatusCode() == HttpStatus.OK;
        } catch (Exception e) {
            logger.log(Level.WARNING, "Python STT service health check failed", e);
            return false;
        }
    }

    public String getServiceUrl() {
        return pythonSTTServiceUrl;
    }

    public boolean isEnabled() {
        return enabled;
    }
}
