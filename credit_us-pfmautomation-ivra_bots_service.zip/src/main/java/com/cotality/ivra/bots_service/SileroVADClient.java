package com.cotality.ivra.bots_service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.time.Duration;
import java.util.Base64;
import java.util.concurrent.CompletableFuture;

/**
 * Client for Silero VAD Service
 * Integrates with the Python-based VAD service to replace in-house energy-based VAD
 */
@Component
public class SileroVADClient {
    
    private static final Logger logger = LoggerFactory.getLogger(SileroVADClient.class);
    private final HttpClient httpClient;
    private final Gson gson;
    private final String vadServiceUrl;
    
    public SileroVADClient() {
        this("http://localhost:8765");
    }
    
    public SileroVADClient(String vadServiceUrl) {
        this.vadServiceUrl = vadServiceUrl;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(5))
                .build();
        this.gson = new Gson();
    }
    
    /**
     * Check if VAD service is healthy
     */
    public CompletableFuture<Boolean> isServiceHealthy() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(vadServiceUrl + "/vad/status"))
                        .timeout(Duration.ofSeconds(5))
                        .GET()
                        .build();
                
                HttpResponse<String> response = httpClient.send(request, 
                    HttpResponse.BodyHandlers.ofString());
                
                return response.statusCode() == 200;
                
            } catch (Exception e) {
                logger.warn("VAD service health check failed: {}", e.getMessage());
                return false;
            }
        });
    }
    
    /**
     * Detect voice activity in audio chunk
     * 
     * @param audioData PCM audio data
     * @param sessionId Session identifier
     * @return VAD result or null if error
     */
    public CompletableFuture<VADResult> detectVoiceActivity(byte[] audioData, String sessionId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                // Encode audio as base64
                String audioBase64 = Base64.getEncoder().encodeToString(audioData);
                
                // Create request
                JsonObject requestJson = new JsonObject();
                requestJson.addProperty("audio_data", audioBase64);
                requestJson.addProperty("audio_format", "pcm16");
                requestJson.addProperty("sample_rate", 8000);  // Twilio default
                requestJson.addProperty("session_id", sessionId);
                
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(vadServiceUrl + "/vad/detect"))
                        .timeout(Duration.ofSeconds(3))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(requestJson)))
                        .build();
                
                HttpResponse<String> response = httpClient.send(request, 
                    HttpResponse.BodyHandlers.ofString());
                
                if (response.statusCode() == 200) {
                    JsonObject responseJson = gson.fromJson(response.body(), JsonObject.class);
                    return parseVADResult(responseJson);
                } else {
                    logger.warn("VAD service returned status {}: {}", 
                        response.statusCode(), response.body());
                    return null;
                }
                
            } catch (Exception e) {
                logger.error("Error calling VAD service: {}", e.getMessage());
                return null;
            }
        });
    }
    
    /**
     * Process streaming audio with state management
     */
    public CompletableFuture<VADResult> processStreamingAudio(byte[] audioData, String sessionId, boolean resetState) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String audioBase64 = Base64.getEncoder().encodeToString(audioData);
                
                JsonObject requestJson = new JsonObject();
                requestJson.addProperty("audio_data", audioBase64);
                requestJson.addProperty("audio_format", "pcm16");
                requestJson.addProperty("sample_rate", 8000);
                requestJson.addProperty("session_id", sessionId);
                requestJson.addProperty("reset_state", resetState);
                
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(vadServiceUrl + "/vad/stream"))
                        .timeout(Duration.ofSeconds(3))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(requestJson)))
                        .build();
                
                HttpResponse<String> response = httpClient.send(request, 
                    HttpResponse.BodyHandlers.ofString());
                
                if (response.statusCode() == 200) {
                    JsonObject responseJson = gson.fromJson(response.body(), JsonObject.class);
                    return parseVADResult(responseJson);
                } else {
                    logger.warn("VAD streaming service returned status {}: {}", 
                        response.statusCode(), response.body());
                    return null;
                }
                
            } catch (Exception e) {
                logger.error("Error calling VAD streaming service: {}", e.getMessage());
                return null;
            }
        });
    }
    
    private VADResult parseVADResult(JsonObject responseJson) {
        JsonObject vadResult = responseJson.getAsJsonObject("vad_result");
        
        return new VADResult(
            vadResult.get("is_speech").getAsBoolean(),
            vadResult.get("confidence").getAsFloat(),
            vadResult.get("is_speaking_state").getAsBoolean(),
            vadResult.get("time_since_last_speech").getAsFloat(),
            vadResult.get("timestamp").getAsLong()
        );
    }
    
    /**
     * VAD Result container
     */
    public static class VADResult {
        public final boolean isSpeech;
        public final float confidence;
        public final boolean isSpeakingState;
        public final float timeSinceLastSpeech;
        public final long timestamp;
        
        public VADResult(boolean isSpeech, float confidence, boolean isSpeakingState, 
                        float timeSinceLastSpeech, long timestamp) {
            this.isSpeech = isSpeech;
            this.confidence = confidence;
            this.isSpeakingState = isSpeakingState;
            this.timeSinceLastSpeech = timeSinceLastSpeech;
            this.timestamp = timestamp;
        }
        
        @Override
        public String toString() {
            return String.format("VADResult{speech=%s, confidence=%.3f, speaking=%s, silence=%.1fs}", 
                isSpeech, confidence, isSpeakingState, timeSinceLastSpeech);
        }
    }
}
