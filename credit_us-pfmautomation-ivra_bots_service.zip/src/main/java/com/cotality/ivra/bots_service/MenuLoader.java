package com.cotality.ivra.bots_service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import org.springframework.stereotype.Service;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

/**
 * Handles loading and parsing of JSON resources for the IVR system.
 */
@Service
public class MenuLoader {
    private static final Gson gson = new Gson();
      /**
     * Load JSON content from a resource file
     * @param fileName the name of the resource file
     * @return the JSON content as a string
     * @throws IOException if the file cannot be found or read
     */
    public String loadJsonFromResources(String fileName) throws IOException {
        ClassLoader classLoader = MenuLoader.class.getClassLoader();
        InputStream inputStream = classLoader.getResourceAsStream(fileName);
        
        if (inputStream == null) {
            throw new IOException("Resource file not found: " + fileName);
        }
        
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append(System.lineSeparator());
            }
        }
        
        return content.toString();
    }
      /**
     * Load the IVR menu structure from the JSON resource file
     * @return JsonObject representing the IVR menu structure
     * @throws IOException if the file cannot be loaded or parsed
     */
    public JsonObject loadIvrMenu() throws IOException {
        String ivrContent = loadJsonFromResources("bofa_ivr_menu.json");
        return gson.fromJson(ivrContent, JsonObject.class);
    }
    
    /**
     * Load the available goals from the JSON resource file
     * @return JsonObject representing the available goals
     * @throws IOException if the file cannot be loaded or parsed
     */
    public JsonObject loadGoals() throws IOException {
        String goalsContent = loadJsonFromResources("goals.json");
        return gson.fromJson(goalsContent, JsonObject.class);
    }
}
