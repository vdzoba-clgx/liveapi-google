package com.cotality.ivra.bots_service.IVR;

import org.springframework.stereotype.Component;

/**
 * Simulation-based action resolver that uses file-based lookup
 * from bofa_ivr_menu_actual.json to determine actions based on IVR prompts.
 * Extends BaseActionResolver to reuse common menu navigation logic.
 */
@Component
public class SimulationActionResolver extends BaseActionResolver {
    
    @Override
    public String resolveAction(String prompt, String context) {
        return resolveAction(prompt, context, null);
    }
    
    @Override
    public String resolveAction(String prompt, String context, String targetGoal) {
        return resolveActionCore(prompt, context, targetGoal);
    }
    
    @Override
    public String getResolverName() {
        return "SimulationActionResolver";
    }
}
